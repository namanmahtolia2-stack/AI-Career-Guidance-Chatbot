"""
data_store.py - loads the JSON knowledge files from /data once and caches them.

All AI modules read their facts from here, so editing a JSON file in /data
(and restarting the server) changes the whole system. Nothing is hard-coded.
"""
import json
import os
from functools import lru_cache

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR = os.path.join(BASE_DIR, "data")


def _load(filename):
    with open(os.path.join(DATA_DIR, filename), encoding="utf-8") as f:
        return json.load(f)


@lru_cache(maxsize=None)
def get_skills():
    """dict: skill_id -> skill record (keeps file order)."""
    return {s["id"]: s for s in _load("skills.json")}


@lru_cache(maxsize=None)
def get_careers():
    """dict: career_id -> career record."""
    return {c["id"]: c for c in _load("careers.json")}


@lru_cache(maxsize=None)
def get_resources():
    return _load("learning_resources.json")


@lru_cache(maxsize=None)
def get_kb():
    return _load("knowledge_base.json")


@lru_cache(maxsize=None)
def get_rules():
    return _load("agent_rules.json")


@lru_cache(maxsize=None)
def get_sample_assessment():
    return _load("sample_assessment.json")


def get_vocab():
    return get_kb()["vocab"]


def reload_all():
    """Clear caches so edited JSON files are re-read (used by tests / admin)."""
    for fn in (get_skills, get_careers, get_resources, get_kb, get_rules, get_sample_assessment):
        fn.cache_clear()


def resources_for_skill(skill_id):
    return [r for r in get_resources() if skill_id in r.get("covers", [])]


def validate_data():
    """Return a list of human-readable problems found in the data files."""
    problems = []
    skills, careers = get_skills(), get_careers()
    vocab = get_vocab()
    for s in skills.values():
        for p in s["prerequisites"]:
            if p not in skills:
                problems.append(f"skill {s['id']} has unknown prerequisite {p}")
    for c in careers.values():
        for s in c["required_skills"]:
            if s not in skills:
                problems.append(f"career {c['id']} needs unknown skill {s}")
        for i in c["interests"]:
            if i not in vocab["interests"]:
                problems.append(f"career {c['id']} uses unknown interest {i}")
    for r in get_resources():
        for s in r.get("covers", []):
            if s not in skills:
                problems.append(f"resource {r['id']} covers unknown skill {s}")
    return problems
