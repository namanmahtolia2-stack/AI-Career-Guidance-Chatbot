"""
agent.py - INTELLIGENT AGENT

PERCEPTION : read the student's assessment
STATE      : keep a structured model of the student (profile + known skills)
GOAL       : find suitable careers and achievable learning milestones
REASONING  : apply IF-THEN rules (data/agent_rules.json), skill matching, A* search
ACTION     : recommend careers, ask a follow-up question, or update the roadmap
FEEDBACK   : when the student completes a skill, the state changes and we reason again
"""
import time

from . import data_store as ds
from .knowledge_graph import KnowledgeGraph
from .recommender import Recommender
from .roadmap import build_roadmap
from .state_space import PIPELINE_STAGES


class CareerAgent:
    def __init__(self):
        self.kg = KnowledgeGraph()
        self.recommender = Recommender()
        self.rules = ds.get_rules()

    # ---------- PERCEPTION + STATE ----------
    def perceive(self, assessment, completed_skills=None):
        skills = dict(assessment.get("skills", {}))
        for s in completed_skills or []:          # FEEDBACK: finished roadmap skills count as learned
            skills[s] = max(skills.get(s, 0), 2)
        return {
            "interests": list(assessment.get("interests", [])),
            "subjects": list(assessment.get("subjects", [])),
            "skills": skills,
            "work_style": assessment.get("work_style", ""),
            "problem_style": assessment.get("problem_style", ""),
            "goals": assessment.get("goals", ""),
            "study_hours": int(assessment.get("study_hours", 5)),
            "education": assessment.get("education", ""),
            "learning_format": assessment.get("learning_format", ""),
        }

    # ---------- REASONING: IF-THEN RULES ----------
    @staticmethod
    def _rule_matches(cond, st):
        known = {s for s, lvl in st["skills"].items() if lvl >= 1}
        checks = [
            ("interests_all", lambda v: set(v) <= set(st["interests"])),
            ("interests_any", lambda v: not v or bool(set(v) & set(st["interests"]))),
            ("subjects_any", lambda v: not v or bool(set(v) & set(st["subjects"]))),
            ("skills_any", lambda v: not v or bool(set(v) & known)),
            ("work_styles_any", lambda v: not v or st["work_style"] in v),
            ("problem_styles_any", lambda v: not v or st["problem_style"] in v),
            ("max_study_hours", lambda v: st["study_hours"] <= v),
            ("min_study_hours", lambda v: st["study_hours"] >= v),
        ]
        return all(fn(cond[key]) for key, fn in checks if key in cond)

    def reason(self, st):
        fired, boosts, notes = [], {}, []
        for rule in self.rules:
            if self._rule_matches(rule["if"], st):
                fired.append({"id": rule["id"], "name": rule["name"], "explanation": rule["explanation"],
                              "considers": [self.kg.label(c) for c in rule["then"].get("consider", [])]})
                for cid in rule["then"].get("consider", []):
                    boosts[cid] = boosts.get(cid, 0) + rule["then"].get("boost", 0)
                if rule["then"].get("note"):
                    notes.append(rule["then"]["note"])
        return fired, boosts, notes

    # ---------- ACTION ----------
    def follow_up_question(self, st):
        if not st["goals"].strip():
            return "What kind of work would you like to be doing in five years? A sentence is enough."
        if not st["skills"]:
            return "Have you tried any programming, design or other tools yet? Even a small attempt helps me adjust the roadmap."
        if st["study_hours"] < 5:
            return "You have limited weekly time. Would a slower plan with one skill at a time suit you?"
        if len(st["interests"]) < 2:
            return "Is there a second area you are curious about? Careers often combine two interests."
        return None

    # ---------- RUN THE WHOLE AGENT LOOP ----------
    def run(self, assessment, completed_skills=None):
        stages, t0 = [], time.perf_counter()

        def stage(name, detail, started):
            stages.append({"name": name, "detail": detail, "ms": round((time.perf_counter() - started) * 1000, 1)})

        t = time.perf_counter()
        st = self.perceive(assessment, completed_skills)
        fired, boosts, notes = self.reason(st)
        stage("Analysing interests", f"{len(st['interests'])} interests and {len(st['subjects'])} subjects read; "
                                     f"{len(fired)} of {len(self.rules)} rules fired.", t)

        t = time.perf_counter()
        ranked = self.recommender.rank(st, boosts)
        known = [s for s, lvl in st["skills"].items() if lvl >= 1]
        stage("Matching existing skills", f"{len(known)} known skills compared against {len(ranked)} careers.", t)

        t = time.perf_counter()
        candidates = set()
        for i in st["interests"]:
            candidates |= set(self.kg.careers_for_interest(i))
        top_ids = [r["career_id"] for r in ranked[:3]]
        explore_also = []
        for cid in top_ids:
            for rel in self.kg.related_careers(cid):
                if rel not in top_ids and rel not in explore_also:
                    explore_also.append(rel)
        stage("Exploring the career knowledge graph",
              f"{len(candidates)} careers reachable from your interests; {len(explore_also)} related careers found.", t)

        t = time.perf_counter()
        for r in ranked[:3]:
            plan = build_roadmap(r["career_id"], known, st["study_hours"])
            r["estimated_hours"] = plan["total_hours"]
            r["estimated_weeks"] = plan["total_weeks"]
            r["search"] = {"expanded": plan["search"]["states_expanded"], "cost": plan["search"]["path_cost_hours"]}
        stage("Evaluating possible learning paths",
              "A* search ran for the top 3 careers: " +
              ", ".join(f"{r['career_name']} ≈ {r['estimated_hours']} h" for r in ranked[:3]) + ".", t)

        t = time.perf_counter()
        question = self.follow_up_question(st)
        actions = [{"type": "recommend", "careers": top_ids}]
        if question:
            actions.append({"type": "ask_followup", "question": question})
        actions.append({"type": "update_roadmap", "career_id": top_ids[0]})
        stage("Preparing personalized recommendations", f"{len(actions)} agent actions chosen.", t)

        return {
            "state": st, "rules_fired": fired, "notes": notes, "recommendations": ranked,
            "top3": ranked[:3], "explore_also": [{"id": c, "name": self.kg.label(c)} for c in explore_also],
            "actions": actions, "follow_up": question, "stages": stages,
            "pipeline": PIPELINE_STAGES,
            "total_ms": round((time.perf_counter() - t0) * 1000, 1),
            "model": {"available": self.recommender.model_available,
                      "meta": self.recommender.meta},
            "disclaimer": "Match scores are indicative recommendations from a small demonstration knowledge base, "
                          "not scientifically validated probabilities of career success.",
        }
