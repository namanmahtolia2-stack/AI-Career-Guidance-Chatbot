"""
search_algorithms.py - BFS and A* executed for real on the LearningSpace.

BFS  : explores level by level, ignores cost, finds the path with the FEWEST steps.
A*   : explores the state with the lowest f(n) = g(n) + h(n) first.
       g(n) = hours already spent on the path so far
       h(n) = 0.8 x hours of the skills still missing (heuristic estimate)

Both return: explored states, chosen path, path cost and a reasoning text.
"""
import heapq
from collections import deque
from .state_space import LearningSpace

MAX_EXPANSIONS = 4000


def _build_path(parents, end_state):
    steps = []
    state = end_state
    while parents[state][0] is not None:
        prev, action = parents[state]
        steps.append(action)
        state = prev
    steps.reverse()
    return steps


def _result(name, space, steps, explored, expanded, truncated, frontier_max, weight=None):
    total = sum(space.cost(s) for s in steps) if steps is not None else None
    res = {
        "algorithm": name,
        "found": steps is not None,
        "path": [{"skill": s, "name": space.skills[s]["name"], "cost": space.cost(s)} for s in (steps or [])],
        "path_length": len(steps) if steps is not None else None,
        "path_cost_hours": total,
        "states_expanded": expanded,
        "frontier_max": frontier_max,
        "truncated": truncated,
        "explored": explored[:80],          # first 80 expansions are enough for the animation
        "explored_total": len(explored),
        "needed_skills": sorted(space.needed),
    }
    res["reasoning"] = explain(res, weight)
    return res


def bfs(space: LearningSpace, max_expansions=MAX_EXPANSIONS):
    """Breadth-First Search over the unweighted learning-state graph."""
    start = space.start
    parents = {start: (None, None)}
    queue, explored, expanded, frontier_max = deque([start]), [], 0, 1
    while queue:
        state = queue.popleft()
        expanded += 1
        explored.append({"order": expanded, "action": parents[state][1], "known_count": len(state.known),
                         "g": sum(space.cost(s) for s in state.known & space.needed)})
        if space.is_goal(state):
            return _result("BFS", space, _build_path(parents, state), explored, expanded, False, frontier_max)
        if expanded >= max_expansions:
            return _result("BFS", space, None, explored, expanded, True, frontier_max)
        for action, nxt, _cost in space.successors(state):
            if nxt not in parents:
                parents[nxt] = (state, action)
                queue.append(nxt)
        frontier_max = max(frontier_max, len(queue))
    return _result("BFS", space, None, explored, expanded, False, frontier_max)


def astar(space: LearningSpace, weight=0.8, max_expansions=20000):
    """A* search: always expand the state with the smallest f = g + h."""
    start = space.start
    g_cost = {start: 0}
    parents = {start: (None, None)}
    counter = 0  # tie-breaker so heapq never has to compare states
    h0 = space.heuristic(start, weight)
    heap = [(h0, -0, counter, start)]
    closed, explored, expanded, frontier_max = set(), [], 0, 1
    while heap:
        f, _tb, _c, state = heapq.heappop(heap)
        if state in closed:
            continue
        closed.add(state)
        expanded += 1
        g = g_cost[state]
        h = space.heuristic(state, weight)
        explored.append({"order": expanded, "action": parents[state][1], "known_count": len(state.known),
                         "g": round(g, 1), "h": round(h, 1), "f": round(g + h, 1)})
        if space.is_goal(state):
            return _result("A*", space, _build_path(parents, state), explored, expanded, False, frontier_max, weight)
        if expanded >= max_expansions:
            return _result("A*", space, None, explored, expanded, True, frontier_max, weight)
        for action, nxt, step in space.successors(state):
            new_g = g + step
            if nxt not in g_cost or new_g < g_cost[nxt]:
                g_cost[nxt] = new_g
                parents[nxt] = (state, action)
                counter += 1
                # tie-break: prefer states that already learned more (go deeper first)
                heapq.heappush(heap, (new_g + space.heuristic(nxt, weight), -len(nxt.known), counter, nxt))
        frontier_max = max(frontier_max, len(heap))
    return _result("A*", space, None, explored, expanded, False, frontier_max, weight)


def explain(res, weight=None):
    if res["truncated"]:
        return (f"{res['algorithm']} stopped after {res['states_expanded']} expanded states without reaching the goal. "
                "The number of possible learning states grows exponentially with the number of skills, "
                "which is why blind search can become impractical and a guided search is useful.")
    if not res["found"]:
        return f"{res['algorithm']} found no path. The goal may already be reached or the data may be inconsistent."
    base = (f"{res['algorithm']} expanded {res['states_expanded']} states and found a {res['path_length']}-step path "
            f"costing about {res['path_cost_hours']} hours. ")
    if res["algorithm"] == "BFS":
        return base + ("BFS explores every state at each depth before going deeper. It guarantees the fewest steps, "
                       "but it does not look at effort, so it may explore many unnecessary states.")
    return base + (f"A* ranked states by f(n) = g(n) + h(n), where h(n) = {weight} x remaining effort hours. "
                   "Because h never over-estimates the real remaining effort, the path is optimal in cost. "
                   "Limitation: effort values are rough estimates, and h assumes every missing skill must be learned.")


def compare(skills, goal_skills, known_skills):
    """Run both algorithms on the same problem (used by /api/search-path)."""
    space = LearningSpace(skills, goal_skills, known_skills)
    return space, bfs(space), astar(space)
