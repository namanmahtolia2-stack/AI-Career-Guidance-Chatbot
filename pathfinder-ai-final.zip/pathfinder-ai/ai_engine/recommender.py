"""
recommender.py - RANKING careers for one student.

RANKING FORMULA (each part is a number from 0 to 1):
    score = 100 x ( 0.30 x skill_overlap
                  + 0.25 x interest_match
                  + 0.25 x model_signal
                  + 0.10 x prereq_readiness
                  + 0.10 x rule_boost )
If the ML model cannot be loaded, model_signal is dropped and the other weights
are re-balanced (0.35 / 0.30 / 0.15 / 0.20).

The result is an INDICATIVE match score, not a probability of career success.
"""
from . import data_store as ds
from . import train_model

WEIGHTS = {"skill": 0.30, "interest": 0.25, "model": 0.25, "readiness": 0.10, "rules": 0.10}
WEIGHTS_NO_MODEL = {"skill": 0.35, "interest": 0.30, "model": 0.0, "readiness": 0.15, "rules": 0.20}
LEVEL_WEIGHT = {0: 0.0, 1: 0.4, 2: 0.75, 3: 1.0}
MAX_RULE_BOOST = 0.15


def band(score):
    if score >= 65:
        return "Strong match"
    if score >= 45:
        return "Good match"
    return "Exploratory match"


class Recommender:
    def __init__(self):
        self.model, self.meta = train_model.load_model()
        self.skills = ds.get_skills()
        self.careers = ds.get_careers()

    @property
    def model_available(self):
        return self.model is not None

    def model_signal(self, state, known):
        """Relative RandomForest vote per career, rescaled so the best one = 1.0 (NOT a probability)."""
        if not self.model_available:
            return {}
        vec = train_model.featurize(state["interests"], state["subjects"], state["work_style"],
                                    state["problem_style"], known)
        probs = self.model.predict_proba([vec])[0]
        top = float(max(probs)) or 1.0
        return {c: float(p) / top for c, p in zip(self.model.classes_, probs)}

    @staticmethod
    def _overlap(student, career_items, cap=3):
        if not career_items:
            return 0.0
        return min(1.0, len(set(student) & set(career_items)) / min(len(career_items), cap))

    def rank(self, state, rule_boosts=None):
        """state = {interests, subjects, skills{id:level}, work_style, problem_style, ...}"""
        rule_boosts = rule_boosts or {}
        known = {s for s, lvl in state["skills"].items() if lvl >= 1}
        signal = self.model_signal(state, known)
        w = WEIGHTS if self.model_available else WEIGHTS_NO_MODEL
        vocab = ds.get_vocab()
        out = []
        for cid, c in self.careers.items():
            req = c["required_skills"]
            overlap = sum(LEVEL_WEIGHT[min(3, state["skills"].get(s, 0))] for s in req) / len(req)
            matched_i = [i for i in state["interests"] if i in c["interests"]]
            matched_sub = [s for s in state["subjects"] if s in c["subjects"]]
            interest_match = (0.6 * self._overlap(state["interests"], c["interests"])
                              + 0.2 * self._overlap(state["subjects"], c["subjects"], 2)
                              + 0.1 * (1.0 if state["work_style"] in c["work_styles"] else 0.0)
                              + 0.1 * (1.0 if state["problem_style"] in c["problem_styles"] else 0.0))
            missing = [s for s in req if s not in known]
            missing_info = []
            for s in missing:
                gaps = [p for p in self.skills[s]["prerequisites"] if p not in known]
                missing_info.append({"id": s, "name": self.skills[s]["name"],
                                     "effort_hours": self.skills[s]["effort_hours"],
                                     "missing_prerequisites": [self.skills[p]["name"] for p in gaps],
                                     "ready_to_start": not gaps})
            readiness = 1.0 if not missing else sum(1 for m in missing_info if m["ready_to_start"]) / len(missing)
            boost = min(MAX_RULE_BOOST, rule_boosts.get(cid, 0.0)) / MAX_RULE_BOOST
            parts = {"skill": overlap, "interest": interest_match, "model": signal.get(cid, 0.0),
                     "readiness": readiness, "rules": boost}
            score = round(100 * sum(w[k] * parts[k] for k in parts), 1)
            out.append({
                "career_id": cid, "career_name": c["name"], "category": c["category"], "summary": c["summary"],
                "score": score, "band": band(score),
                "components": {k: round(float(v), 2) for k, v in parts.items()},
                "matched_interests": [vocab["interests"][i] for i in matched_i],
                "matched_subjects": [vocab["subjects"][s] for s in matched_sub],
                "matched_skills": [{"id": s, "name": self.skills[s]["name"], "level": state["skills"][s]}
                                   for s in req if s in known],
                "missing_skills": missing_info,
                "reasons": self._reasons(c, matched_i, matched_sub, req, known, missing_info, vocab),
            })
        out.sort(key=lambda r: -r["score"])
        for r in out:
            r["structured"] = structured_summary(r)
        return out

    @staticmethod
    def _reasons(c, matched_i, matched_sub, req, known, missing_info, vocab):
        reasons = []
        if matched_i:
            reasons.append("Your interests in " + ", ".join(vocab["interests"][i] for i in matched_i) +
                           " appear in this career's profile.")
        if matched_sub:
            reasons.append("Your favourite subjects (" + ", ".join(vocab["subjects"][s] for s in matched_sub) +
                           ") are commonly useful here.")
        have = len([s for s in req if s in known])
        reasons.append(f"You already have {have} of the {len(req)} core skills in the knowledge base for this career.")
        ready = [m["name"] for m in missing_info if m["ready_to_start"]]
        if ready:
            reasons.append("You can start right away with: " + ", ".join(ready[:3]) + ".")
        return reasons


def structured_summary(rec):
    """Same JSON shape the LLM is asked to return (see llm_service.py)."""
    first = [m["name"] for m in rec["missing_skills"] if m["ready_to_start"]][:3]
    return {
        "career_name": rec["career_name"],
        "reasons": rec["reasons"],
        "matched_skills": [s["name"] for s in rec["matched_skills"]],
        "missing_skills": [m["name"] for m in rec["missing_skills"]],
        "next_steps": ([f"Start with {n}." for n in first] or ["Build a portfolio project that uses your skills."]),
        "confidence_notes": "Indicative score from a small demonstration knowledge base; not a prediction of career success.",
    }
