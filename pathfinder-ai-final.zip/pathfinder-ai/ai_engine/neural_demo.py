"""
neural_demo.py - DEEP LEARNING CONCEPTS (educational demo, NumPy only)

This is a TINY neural network (6 inputs -> 5 hidden ReLU units -> 4 outputs with softmax).
It is trained for real (gradient descent, back-propagation) but ONLY on a small SYNTHETIC set
made from our own career-family profiles. It is a teaching demonstration of a forward pass.
It is NOT the main recommendation engine and is NOT trained on real student data.
"""
import numpy as np

INPUTS = ["Maths", "Programming", "Design", "Security", "Business", "Hands-on"]
OUTPUTS = ["Data / AI", "Software / Web", "Security / Cloud", "Design / Business"]
_cache = {}


def _dataset(seed=7, per_class=40):
    rng = np.random.default_rng(seed)
    centers = np.array([
        [0.9, 0.8, 0.1, 0.2, 0.3, 0.2],   # Data / AI
        [0.5, 0.9, 0.4, 0.2, 0.2, 0.3],   # Software / Web
        [0.4, 0.6, 0.1, 0.9, 0.2, 0.6],   # Security / Cloud
        [0.2, 0.2, 0.9, 0.1, 0.8, 0.2],   # Design / Business
    ])
    X = np.vstack([np.clip(c + rng.normal(0, 0.15, (per_class, 6)), 0, 1) for c in centers])
    y = np.repeat(np.arange(4), per_class)
    return X, y


def _softmax(z):
    e = np.exp(z - z.max(axis=-1, keepdims=True))
    return e / e.sum(axis=-1, keepdims=True)


def train(epochs=400, lr=0.1, seed=3):
    X, y = _dataset()
    rng = np.random.default_rng(seed)
    W1, b1 = rng.normal(0, 0.5, (6, 5)), np.zeros(5)
    W2, b2 = rng.normal(0, 0.5, (5, 4)), np.zeros(4)
    Y, losses = np.eye(4)[y], []
    for ep in range(epochs):
        h_pre = X @ W1 + b1
        h = np.maximum(0, h_pre)                 # ReLU activation
        p = _softmax(h @ W2 + b2)
        loss = -np.mean(np.log(p[np.arange(len(y)), y] + 1e-9))
        d2 = (p - Y) / len(y)                    # back-propagation
        dW2, db2 = h.T @ d2, d2.sum(0)
        d1 = (d2 @ W2.T) * (h_pre > 0)
        dW1, db1 = X.T @ d1, d1.sum(0)
        W1 -= lr * dW1; b1 -= lr * db1; W2 -= lr * dW2; b2 -= lr * db2
        if ep % 20 == 0:
            losses.append(round(float(loss), 4))
    acc = float((np.argmax(_softmax(np.maximum(0, X @ W1 + b1) @ W2 + b2), 1) == y).mean())
    return {"W1": W1, "b1": b1, "W2": W2, "b2": b2, "losses": losses, "train_accuracy": round(acc, 3), "epochs": epochs}


def forward(values):
    """Real forward pass for 6 numbers between 0 and 1."""
    if "net" not in _cache:
        _cache["net"] = train()
    n = _cache["net"]
    x = np.array(values, dtype=float)
    hidden_pre = x @ n["W1"] + n["b1"]
    hidden = np.maximum(0, hidden_pre)
    logits = hidden @ n["W2"] + n["b2"]
    probs = _softmax(logits)
    return {
        "inputs": dict(zip(INPUTS, [round(float(v), 2) for v in x])),
        "hidden_pre_activation": [round(float(v), 3) for v in hidden_pre],
        "hidden_after_relu": [round(float(v), 3) for v in hidden],
        "output_scores": dict(zip(OUTPUTS, [round(float(v), 3) for v in probs])),
        "predicted_family": OUTPUTS[int(np.argmax(probs))],
        "loss_curve": n["losses"], "train_accuracy": n["train_accuracy"], "epochs": n["epochs"],
        "architecture": "6 inputs -> 5 hidden units (ReLU) -> 4 outputs (softmax)",
        "disclaimer": "Educational demo trained on 160 synthetic points. Separate from the main recommendation engine; "
                      "softmax outputs are not real-world probabilities.",
    }
