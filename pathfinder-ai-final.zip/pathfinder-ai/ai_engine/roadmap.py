"""
roadmap.py - turns an A* learning path into an ordered roadmap with milestones.
"""
from . import data_store as ds
from .search_algorithms import astar, bfs
from .state_space import LearningSpace


def _topological(skills, needed, known):
    """Fallback ordering if A* is truncated: simple prerequisite order."""
    order, done = [], set(known)
    while len(order) < len(needed):
        progressed = False
        for s in sorted(needed - done):
            if all(p in done for p in skills[s]["prerequisites"]):
                order.append(s); done.add(s); progressed = True
        if not progressed:
            break
    return order


def build_roadmap(career_id, known_skills, study_hours=5, completed=None):
    skills, careers = ds.get_skills(), ds.get_careers()
    career = careers[career_id]
    known = set(known_skills)
    space = LearningSpace(skills, career["required_skills"], known)
    result = astar(space, weight=1.0)           # exact-ish heuristic keeps roadmaps fast
    order = [p["skill"] for p in result["path"]] if result["found"] else _topological(skills, space.needed, known)
    completed = set(completed or [])
    steps, hours_per_week = [], max(1, int(study_hours))
    for idx, sid in enumerate(order, 1):
        sk = skills[sid]
        h = sk["effort_hours"]
        steps.append({
            "order": idx, "id": sid, "type": "skill", "name": sk["name"], "description": sk["description"],
            "hours": h, "hours_range": [round(h * 0.8), round(h * 1.3)],
            "weeks": round(h / hours_per_week, 1),
            "prerequisites": [{"id": p, "name": skills[p]["name"], "in_roadmap": p in space.needed}
                              for p in sk["prerequisites"]],
            "is_core": sid in career["required_skills"],
            "resources": [{"title": r["title"], "url": r["url"]} for r in ds.resources_for_skill(sid)[:3]],
            "done": sid in completed,
        })
    project = {"order": len(steps) + 1, "id": "portfolio_project", "type": "project",
               "name": "Portfolio Project", "description": "Build and publish one project that uses your new skills: "
               + career["beginner_projects"][0] + ".",
               "hours": 30, "hours_range": [24, 40], "weeks": round(30 / hours_per_week, 1),
               "prerequisites": [], "is_core": True, "resources": [], "done": "portfolio_project" in completed}
    steps.append(project)
    # milestones: group every 3 steps
    for i, s in enumerate(steps):
        s["milestone"] = f"Milestone {i // 3 + 1}"
    total = sum(s["hours"] for s in steps)
    return {
        "career_id": career_id, "career_name": career["name"], "steps": steps,
        "total_hours": total, "total_hours_range": [round(total * 0.8), round(total * 1.3)],
        "total_weeks": round(total / hours_per_week, 1), "hours_per_week": hours_per_week,
        "search": {k: result[k] for k in ("algorithm", "states_expanded", "path_cost_hours", "reasoning")},
        "already_known": [skills[s]["name"] for s in career["required_skills"] if s in known],
        "note": "Time ranges are rough estimates for a beginner, not guarantees.",
    }


def progress_summary(plan):
    done = sum(1 for s in plan["steps"] if s["done"])
    total = len(plan["steps"])
    return {"done": done, "total": total, "percent": round(100 * done / total) if total else 0}


def weekly_plan(plan, weeks=4):
    """Spread the next unfinished steps across the next few weeks."""
    budget = plan["hours_per_week"]
    todo = [dict(s, left=s["hours"]) for s in plan["steps"] if not s["done"]]
    out, i = [], 0
    for w in range(1, weeks + 1):
        items, free = [], budget
        while free > 0 and i < len(todo):
            take = min(free, todo[i]["left"])
            items.append({"skill": todo[i]["name"], "hours": take})
            todo[i]["left"] -= take
            free -= take
            if todo[i]["left"] <= 0:
                i += 1
        if items:
            out.append({"week": w, "items": items})
    return out
