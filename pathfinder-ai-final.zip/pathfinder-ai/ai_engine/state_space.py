"""
state_space.py - STATE-SPACE REPRESENTATION

A STATE  = the set of skills the student has learned so far (+ a stage label).
An ACTION = learn one new skill whose prerequisites are already known.
COST     = estimated learning effort in hours (from skills.json).
GOAL     = every goal skill is inside the state's known-set.

The search algorithms in search_algorithms.py walk this space.
"""
from dataclasses import dataclass

# The high-level exploration pipeline described in the project brief.
# The agent walks through these stages for every assessment (see agent.py).
PIPELINE_STAGES = [
    "Start State",
    "Interest Analysis",
    "Skill Assessment",
    "Career Candidates",
    "Prerequisite Validation",
    "Ranked Career Paths",
    "Learning Roadmap",
]


@dataclass(frozen=True)
class LearningState:
    known: frozenset          # skills learned so far
    stage: str = "learning"   # current learning stage label


class LearningSpace:
    def __init__(self, skills, goal_skills, known_skills):
        self.skills = skills
        self.goal = frozenset(goal_skills)
        known = set(known_skills)
        # "needed" = unknown skills that must be learned to reach the goal.
        # We walk down the prerequisite tree and stop at skills already known.
        self.needed, stack = set(), [g for g in self.goal if g not in known]
        while stack:
            s = stack.pop()
            if s in self.needed:
                continue
            self.needed.add(s)
            stack.extend(p for p in skills[s]["prerequisites"] if p not in known)
        self.start = LearningState(frozenset(known), "start")

    def is_goal(self, state):
        return self.goal <= state.known

    def cost(self, skill_id):
        return self.skills[skill_id]["effort_hours"]

    def successors(self, state):
        """Yield (action, next_state, step_cost). Only skills whose prerequisites are known."""
        for sid in sorted(self.needed - state.known):
            if all(p in state.known for p in self.skills[sid]["prerequisites"]):
                yield sid, LearningState(state.known | {sid}, "learning"), self.cost(sid)

    def remaining_effort(self, state):
        return sum(self.cost(s) for s in self.needed - state.known)

    def heuristic(self, state, weight=0.8):
        """h(n): estimated hours left = weight x (effort of skills still missing).
        weight <= 1 keeps h from over-estimating, which keeps A* optimal."""
        return weight * self.remaining_effort(state)
