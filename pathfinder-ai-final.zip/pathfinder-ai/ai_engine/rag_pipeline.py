"""
rag_pipeline.py - RETRIEVAL-AUGMENTED GENERATION (RAG)

Pipeline
 1. COLLECT   local documents: careers, skills, learning resources, general guidance (all from /data)
 2. CHUNK     split every document into ~350-character pieces at sentence boundaries
 3. INDEX     convert chunks to TF-IDF vectors (scikit-learn)
 4. RETRIEVE  cosine similarity between the question vector and every chunk vector
 5. FILTER    drop chunks below a minimum relevance score (RAG_MIN_SCORE)
 6. ANSWER    - with an LLM configured: send question + retrieved chunks to the LLM (grounded generation)
              - without an LLM: build an EXTRACTIVE answer from the best matching sentences.
                (This is retrieval + extraction, NOT full generative RAG, and the API says so.)
 7. SOURCES   always return the titles and scores of the chunks used
"""
import os
import re

from . import data_store as ds
from . import llm_service


def _setting(name, default, cast):
    try:
        return cast(os.getenv(name, default))
    except (TypeError, ValueError):
        return cast(default)


def split_sentences(text):
    return [s.strip() for s in re.split(r"(?<=[.!?])\s+", text) if s.strip()]


def chunk_text(text, max_chars):
    """Group whole sentences into chunks of at most max_chars characters."""
    chunks, current = [], ""
    for sent in split_sentences(text):
        if current and len(current) + len(sent) + 1 > max_chars:
            chunks.append(current)
            current = sent
        else:
            current = (current + " " + sent).strip()
    if current:
        chunks.append(current)
    return chunks


def build_documents():
    skills, careers = ds.get_skills(), ds.get_careers()
    docs = []
    for c in careers.values():
        req = ", ".join(skills[s]["name"] for s in c["required_skills"])
        docs.append({"id": f"career_{c['id']}", "title": f"Career: {c['name']}", "text":
                     f"{c['summary']} Required skills for {c['name']}: {req}. Prerequisites: {c['prerequisites']} "
                     f"Beginner projects: {'; '.join(c['beginner_projects'])}. "
                     f"Next steps: {'; '.join(c['next_steps'])}."})
    for s in skills.values():
        pre = ", ".join(skills[p]["name"] for p in s["prerequisites"]) or "none"
        users = ", ".join(c["name"] for c in careers.values() if s["id"] in c["required_skills"]) or "no career in the demo data"
        res = ", ".join(r["title"] for r in ds.resources_for_skill(s["id"])) or "none listed"
        docs.append({"id": f"skill_{s['id']}", "title": f"Skill: {s['name']}", "text":
                     f"{s['name']}: {s['description']} Prerequisites: {pre}. Estimated effort: about {s['effort_hours']} hours. "
                     f"Needed for: {users}. Learning resources: {res}."})
    for r in ds.get_resources():
        cover = ", ".join(skills[s]["name"] for s in r["covers"] if s in skills)
        docs.append({"id": f"res_{r['id']}", "title": f"Resource: {r['title']}", "text":
                     f"{r['title']} is a {r['level']} {r['type']}. {r['description']} Covers: {cover}. Website: {r['url']}"})
    docs.extend(ds.get_kb().get("documents", []))
    return docs


class RAGPipeline:
    def __init__(self):
        self.reload()

    def reload(self):
        from sklearn.feature_extraction.text import TfidfVectorizer
        self.chunk_chars = _setting("RAG_CHUNK_CHARS", "350", int)
        self.chunks = []
        for d in build_documents():
            for i, piece in enumerate(chunk_text(d["text"], self.chunk_chars)):
                self.chunks.append({"doc_id": d["id"], "title": d["title"], "chunk_id": f"{d['id']}#{i}", "text": piece})
        self.vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), sublinear_tf=True)
        self.matrix = self.vectorizer.fit_transform(f"{c['title']}. {c['text']}" for c in self.chunks)

    def retrieve(self, question, top_k=None, min_score=None):
        top_k = top_k or _setting("RAG_TOP_K", "3", int)
        min_score = _setting("RAG_MIN_SCORE", "0.10", float) if min_score is None else min_score
        q = self.vectorizer.transform([question])
        scores = (self.matrix @ q.T).toarray().ravel()
        order = scores.argsort()[::-1][:top_k]
        hits = [{**self.chunks[i], "score": round(float(scores[i]), 3)} for i in order if scores[i] >= min_score]
        return hits, top_k, min_score

    def _extractive_answer(self, question, hits):
        q = self.vectorizer.transform([question])
        cand = []
        for h in hits:
            for s in split_sentences(h["text"]):
                score = float((self.vectorizer.transform([s]) @ q.T).toarray()[0][0])
                cand.append((score, s))
        best = sorted(cand, key=lambda t: -t[0])[:3]
        # keep the original order of retrieval to read naturally
        picked = [s for _, s in best if _ > 0] or [hits[0]["text"]]
        return " ".join(dict.fromkeys(picked))

    def query(self, question, top_k=None, min_score=None, use_llm=True):
        hits, top_k, min_score = self.retrieve(question, top_k, min_score)
        settings = {"top_k": top_k, "min_score": min_score, "chunk_chars": self.chunk_chars,
                    "method": "TF-IDF (1-2 grams) + cosine similarity", "total_chunks": len(self.chunks)}
        if not hits:
            return {"found": False, "mode": "none", "answer":
                    "No sufficiently relevant source was found in the knowledge base for this question, "
                    "so I will not guess. Try mentioning a career, skill or learning topic.",
                    "sources": [], "chunks": [], "settings": settings}
        sources = list(dict.fromkeys(h["title"] for h in hits))
        if use_llm and llm_service.llm_configured():
            text = llm_service.grounded_answer(question, hits)
            if text:
                return {"found": True, "mode": "llm_rag", "answer": text, "sources": sources, "chunks": hits,
                        "settings": settings}
        answer = self._extractive_answer(question, hits)
        return {"found": True, "mode": "extractive", "answer": answer, "sources": sources, "chunks": hits,
                "settings": settings,
                "mode_note": "Extractive answer (retrieval + sentence selection). No generative LLM was used."}
