"""
knowledge_graph.py - KNOWLEDGE REPRESENTATION

Facts are stored as TRIPLES:  (subject, relation, object)
    (python_basics, prerequisite_for, machine_learning)
    (statistics,    required_skill_for, data_analyst)
    (data,          interest_leads_to,  data_analyst)

Triples are built from the JSON files, so the graph is always in sync with
the editable data. `query()` retrieves related facts and `to_graph()` makes
a node/edge structure for the frontend graph.
"""
from . import data_store as ds

RELATION_LABELS = {
    "prerequisite_for": "is a prerequisite for",
    "required_skill_for": "is a required skill for",
    "interest_leads_to": "leads towards",
    "related_to": "is related to",
}


class KnowledgeGraph:
    def __init__(self):
        self.reload()

    def reload(self):
        self.skills = ds.get_skills()
        self.careers = ds.get_careers()
        self.vocab = ds.get_vocab()
        seen, triples = set(), []

        def add(s, r, o):
            if (s, r, o) not in seen:
                seen.add((s, r, o))
                triples.append((s, r, o))

        for sk in self.skills.values():
            for p in sk["prerequisites"]:
                add(p, "prerequisite_for", sk["id"])
        for c in self.careers.values():
            for s in c["required_skills"]:
                add(s, "required_skill_for", c["id"])
            for i in c["interests"]:
                add(i, "interest_leads_to", c["id"])
        for s, r, o in ds.get_kb().get("extra_triples", []):
            add(s, r, o)
        self.triples = triples

    # ---------- helpers ----------
    def node_type(self, node_id):
        if node_id in self.careers:
            return "career"
        if node_id in self.skills:
            return "skill"
        if node_id in self.vocab["interests"]:
            return "interest"
        return "concept"

    def label(self, node_id):
        if node_id in self.careers:
            return self.careers[node_id]["name"]
        if node_id in self.skills:
            return self.skills[node_id]["name"]
        return self.vocab["interests"].get(node_id, node_id)

    # ---------- QUERY FUNCTION ----------
    def query(self, subject=None, relation=None, obj=None):
        """Return all triples matching the given (optional) fields."""
        return [
            {"subject": s, "relation": r, "object": o,
             "text": f"{self.label(s)} {RELATION_LABELS.get(r, r)} {self.label(o)}"}
            for (s, r, o) in self.triples
            if (subject is None or s == subject)
            and (relation is None or r == relation)
            and (obj is None or o == obj)
        ]

    def related(self, node_id):
        out = self.query(subject=node_id)
        inc = self.query(obj=node_id)
        return {"outgoing": out, "incoming": inc}

    def node_info(self, node_id):
        if self.node_type(node_id) == "concept" and not self.related(node_id)["outgoing"] \
                and not self.related(node_id)["incoming"]:
            return None
        info = {"id": node_id, "label": self.label(node_id), "type": self.node_type(node_id),
                "relations": self.related(node_id)}
        if node_id in self.careers:
            c = self.careers[node_id]
            info["summary"] = c["summary"]
            info["required_skills"] = [self.label(s) for s in c["required_skills"]]
        elif node_id in self.skills:
            s = self.skills[node_id]
            info["summary"] = s["description"]
            info["effort_hours"] = s["effort_hours"]
            info["required_skills"] = [self.label(p) for p in s["prerequisites"]]
        return info

    def ancestors(self, skill_id):
        """All skills that must be learned before skill_id (transitive prerequisites)."""
        result, stack = set(), list(self.skills[skill_id]["prerequisites"])
        while stack:
            s = stack.pop()
            if s not in result:
                result.add(s)
                stack.extend(self.skills[s]["prerequisites"])
        return result

    def related_careers(self, career_id):
        return [o for (s, r, o) in self.triples if s == career_id and r == "related_to"] + \
               [s for (s, r, o) in self.triples if o == career_id and r == "related_to"]

    def careers_for_interest(self, interest_id):
        return [o for (s, r, o) in self.triples if s == interest_id and r == "interest_leads_to"]

    # ---------- FRONTEND GRAPH ----------
    def to_graph(self, focus_career=None):
        """Nodes + edges for the frontend. With focus_career, only its neighbourhood."""
        keep = None
        if focus_career and focus_career in self.careers:
            keep = {focus_career}
            for s in self.careers[focus_career]["required_skills"]:
                keep.add(s)
                keep |= self.ancestors(s)
            keep |= set(self.careers[focus_career]["interests"])
            keep |= set(self.related_careers(focus_career))
        nodes, ids = [], set()
        for (s, r, o) in self.triples:
            for n in (s, o):
                if (keep is None or n in keep) and n not in ids:
                    ids.add(n)
                    nodes.append({"id": n, "label": self.label(n), "type": self.node_type(n)})
        edges = [{"source": s, "target": o, "relation": r}
                 for (s, r, o) in self.triples if s in ids and o in ids]
        return {"nodes": nodes, "edges": edges,
                "note": "Demonstration knowledge base, not a complete professional career database."}
