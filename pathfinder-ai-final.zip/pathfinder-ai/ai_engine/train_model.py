"""
train_model.py - MACHINE LEARNING (scikit-learn)

What this file does
1. Builds a SMALL SYNTHETIC training set: for every career we create "prototype students"
   by sampling that career's interests / subjects / skills with random noise.
   -> data/training_data.csv (open it and look: it is fully transparent)
2. ENCODES each student as a vector of 0/1 flags (one-hot / multi-hot encoding).
3. TRAINS a RandomForestClassifier (many decision trees voting together).
4. EVALUATES it with a held-out test split and 5-fold cross-validation.
5. Saves the model + metrics so the app can load them.

HONEST LIMITATIONS
- The data is synthetic and was generated from our own career profiles, so accuracy
  is optimistic (the model partly "learns our own rules back"). It is NOT trained on
  real student outcomes and cannot predict real career success.
- Predicted probabilities are uncalibrated. We use them only as one relative signal
  inside the ranking formula (see recommender.py).
Run manually with:  python -m ai_engine.train_model
"""
import csv
import json
import os
import pickle
import random
from datetime import datetime, timezone

from . import data_store as ds
from .knowledge_graph import KnowledgeGraph

BASE = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE, "model.pkl")
META_PATH = os.path.join(BASE, "model_meta.json")
CSV_PATH = os.path.join(ds.DATA_DIR, "training_data.csv")


# ---------- FEATURE ENCODING ----------
def feature_names():
    v = ds.get_vocab()
    return ([f"interest:{i}" for i in v["interests"]] + [f"subject:{s}" for s in v["subjects"]] +
            [f"work:{w}" for w in v["work_styles"]] + [f"problem:{p}" for p in v["problem_styles"]] +
            [f"skill:{s}" for s in ds.get_skills()])


def featurize(interests, subjects, work_style, problem_style, known_skills):
    """Turn one student into a list of 0/1 numbers in the order of feature_names()."""
    v = ds.get_vocab()
    row = [1 if i in interests else 0 for i in v["interests"]]
    row += [1 if s in subjects else 0 for s in v["subjects"]]
    row += [1 if w == work_style else 0 for w in v["work_styles"]]
    row += [1 if p == problem_style else 0 for p in v["problem_styles"]]
    row += [1 if s in known_skills else 0 for s in ds.get_skills()]
    return row


# ---------- SYNTHETIC DATASET ----------
def generate_dataset(seed=42, per_career=14):
    rng = random.Random(seed)
    v, kg = ds.get_vocab(), KnowledgeGraph()
    X, y = [], []
    for cid, c in ds.get_careers().items():
        pool = set(c["required_skills"])
        for s in c["required_skills"]:
            pool |= kg.ancestors(s)
        for _ in range(per_career):
            interests = {i for i in c["interests"] if rng.random() < 0.8}
            if rng.random() < 0.5:
                interests.add(rng.choice(list(v["interests"])))
            if not interests:
                interests.add(rng.choice(c["interests"]))
            subjects = {s for s in c["subjects"] if rng.random() < 0.7}
            if rng.random() < 0.4:
                subjects.add(rng.choice(list(v["subjects"])))
            work = rng.choice(c["work_styles"]) if rng.random() < 0.7 else rng.choice(list(v["work_styles"]))
            prob = rng.choice(c["problem_styles"]) if rng.random() < 0.7 else rng.choice(list(v["problem_styles"]))
            known = {s for s in pool if rng.random() < 0.35}
            if rng.random() < 0.3:
                known.add(rng.choice(list(ds.get_skills())))
            X.append(featurize(interests, subjects, work, prob, known))
            y.append(cid)
    return X, y


def save_csv(X, y):
    with open(CSV_PATH, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(feature_names() + ["career_label"])
        for row, label in zip(X, y):
            w.writerow(row + [label])


# ---------- TRAINING + EVALUATION ----------
def train(save=True):
    from sklearn.ensemble import RandomForestClassifier
    from sklearn.model_selection import cross_val_score, train_test_split

    X, y = generate_dataset()
    if len(X) < 30:
        raise ValueError("Training set too small to train a meaningful model.")
    save_csv(X, y)
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.25, stratify=y, random_state=42)
    make = lambda: RandomForestClassifier(n_estimators=60, max_depth=8, random_state=42)
    model = make().fit(X_tr, y_tr)
    test_acc = float(model.score(X_te, y_te))
    cv = cross_val_score(make(), X, y, cv=5)
    model = make().fit(X, y)  # final model uses all rows
    names = feature_names()
    imp = sorted(zip(names, model.feature_importances_), key=lambda t: -t[1])[:10]
    meta = {
        "model_type": "RandomForestClassifier (60 trees, max_depth=8)",
        "n_samples": len(X), "n_features": len(names), "n_classes": len(set(y)),
        "test_accuracy": round(test_acc, 3), "cv_mean": round(float(cv.mean()), 3), "cv_std": round(float(cv.std()), 3),
        "top_features": [{"feature": n, "importance": round(float(i), 3)} for n, i in imp],
        "trained_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "limitations": ["Synthetic data generated from our own career profiles, so accuracy is optimistic.",
                        "Not trained on real students or real job outcomes.",
                        "Probabilities are uncalibrated and are used only as one relative signal in ranking."],
    }
    if save:
        with open(MODEL_PATH, "wb") as f:
            pickle.dump({"model": model, "features": names}, f)
        with open(META_PATH, "w", encoding="utf-8") as f:
            json.dump(meta, f, indent=2)
    return model, meta


def load_model():
    """Return (model, meta). Trains on first use. Returns (None, None) if ML is unavailable."""
    try:
        if not os.path.exists(MODEL_PATH):
            return train(save=True)
        with open(MODEL_PATH, "rb") as f:
            bundle = pickle.load(f)
        if bundle.get("features") != feature_names():   # data files changed -> retrain
            return train(save=True)
        with open(META_PATH, encoding="utf-8") as f:
            return bundle["model"], json.load(f)
    except Exception as exc:  # sklearn missing, corrupt file, ...
        print(f"[ML] model unavailable, using rule-based fallback: {exc}")
        return None, None


if __name__ == "__main__":
    _, m = train()
    print(json.dumps(m, indent=2))
