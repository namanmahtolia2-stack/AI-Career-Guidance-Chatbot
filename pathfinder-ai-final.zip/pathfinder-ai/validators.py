"""validators.py - checks and cleans every request before it touches the AI engine or the database."""
import re

from ai_engine import data_store as ds


def _clean(text, limit):
    return re.sub(r"[\x00-\x08\x0b-\x1f\x7f]", " ", str(text or "")).strip()[:limit]


def validate_assessment(payload):
    """Return (clean_dict, errors_dict). errors is empty when the data is valid."""
    errors, vocab, skills = {}, ds.get_vocab(), ds.get_skills()
    if not isinstance(payload, dict):
        return None, {"body": "Expected a JSON object."}

    interests = payload.get("interests")
    if not isinstance(interests, list) or not (1 <= len(interests) <= 10):
        errors["interests"] = "Choose between 1 and 10 interests."
    elif any(i not in vocab["interests"] for i in interests):
        errors["interests"] = "Unknown interest value."

    raw_skills = payload.get("skills", {})
    clean_skills = {}
    if not isinstance(raw_skills, dict) or len(raw_skills) > 40:
        errors["skills"] = "Skills must be an object of skill_id -> level (1-3)."
    else:
        for sid, lvl in raw_skills.items():
            if sid not in skills or not isinstance(lvl, int) or isinstance(lvl, bool) or not 1 <= lvl <= 3:
                errors["skills"] = f"Invalid skill entry: {_clean(sid, 40)}"
                break
            clean_skills[sid] = lvl

    subjects = payload.get("subjects", [])
    if not isinstance(subjects, list) or len(subjects) > 6 or any(s not in vocab["subjects"] for s in subjects):
        errors["subjects"] = "Choose up to 6 valid subjects."

    for field, key in (("work_style", "work_styles"), ("problem_style", "problem_styles"),
                       ("education", "education_levels"), ("learning_format", "learning_formats")):
        if payload.get(field) not in vocab[key]:
            errors[field] = f"Please choose a valid {field.replace('_', ' ')}."

    hours = payload.get("study_hours")
    if not isinstance(hours, int) or isinstance(hours, bool) or not 1 <= hours <= 60:
        errors["study_hours"] = "Study hours per week must be a whole number from 1 to 60."

    goals = payload.get("goals", "")
    if not isinstance(goals, str) or len(goals) > 300:
        errors["goals"] = "Career goals must be text of at most 300 characters."

    if errors:
        return None, errors
    return {"interests": interests, "skills": clean_skills, "subjects": subjects,
            "work_style": payload["work_style"], "problem_style": payload["problem_style"],
            "goals": _clean(goals, 300), "study_hours": hours, "education": payload["education"],
            "learning_format": payload["learning_format"]}, {}
