@echo off
setlocal
title PathFinder AI Server
cd /d "%~dp0"

if not exist app.py if exist pathfinder-ai\app.py cd pathfinder-ai
if not exist app.py goto :noproject
if not exist requirements.txt goto :noproject

rem ---- find a working Python (the Microsoft Store "python" shortcut does not count) ----
set PY=python
%PY% --version >nul 2>&1
if errorlevel 1 set PY=py
%PY% --version >nul 2>&1
if errorlevel 1 goto :nopython
echo Using:
%PY% --version

if not exist venv\Scripts\python.exe (
  echo Creating virtual environment...
  %PY% -m venv venv
  if errorlevel 1 goto :venvfail
)

if not exist venv\.deps_installed (
  echo Installing requirements - first run only, please wait 1-3 minutes...
  venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 goto :pipfail
  echo done> venv\.deps_installed
)

rem ---- pick port 8000, or 8001 if 8000 is busy ----
set PORT=8000
netstat -ano | findstr /R /C:":8000 .*LISTENING" >nul
if not errorlevel 1 set PORT=8001
netstat -ano | findstr /R /C:":%PORT% .*LISTENING" >nul
if not errorlevel 1 goto :portsbusy

set FLASK_DEBUG=0
echo.
echo =====================================================
echo  PathFinder AI is starting on http://localhost:%PORT%
echo  The browser opens automatically when the server is ready.
echo  Keep this window open. Press Ctrl+C to stop.
echo =====================================================
echo.
start "" /min powershell -NoProfile -ExecutionPolicy Bypass -File "%CD%\open_browser.ps1" %PORT%

venv\Scripts\python.exe app.py
echo.
echo The server stopped. If you see an error above, copy it and send it for help.
pause
exit /b

:noproject
echo ERROR: app.py / requirements.txt not found.
echo Extract pathfinder-ai.zip first, then run start_server.bat from INSIDE the pathfinder-ai folder.
pause
exit /b 1

:nopython
echo ERROR: Python was not found. Install Python 3.10-3.12 from python.org and tick "Add python.exe to PATH".
pause
exit /b 1

:venvfail
echo ERROR: Could not create the virtual environment.
pause
exit /b 1

:pipfail
echo ERROR: Installing the requirements failed. Check your internet connection.
echo If the message mentions building scikit-learn or numpy, install Python 3.11 or 3.12 and try again.
pause
exit /b 1

:portsbusy
echo ERROR: Ports 8000 and 8001 are both busy. Close other programs and try again.
pause
exit /b 1
