"""Run with:  python -m pytest tests -q   (or)   python tests/test_app.py"""
import os
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
os.environ["DATABASE_PATH"] = os.path.join(tempfile.mkdtemp(), "test.db")

from app import app  # noqa: E402
from ai_engine import data_store as ds  # noqa: E402
from ai_engine.search_algorithms import astar, bfs  # noqa: E402
from ai_engine.state_space import LearningSpace  # noqa: E402

client = app.test_client()
SAMPLE = ds.get_sample_assessment()


def test_health():
    r = client.get("/api/health").get_json()
    assert r["status"] == "ok" and r["careers"] == 10 and r["ml_model_loaded"]


def test_pages_load():
    for p in ["/", "/assessment", "/analysis", "/dashboard", "/explorer", "/roadmap", "/companion", "/about"]:
        assert client.get(p).status_code == 200, p


def test_careers_and_search():
    assert client.get("/api/careers").get_json()["count"] == 10
    assert client.get("/api/careers?q=python").get_json()["count"] >= 2
    assert client.get("/api/careers/ai_ml_engineer").status_code == 200
    assert client.get("/api/careers/nope").status_code == 404


def test_assessment_validation():
    assert client.post("/api/assessment", json={}).status_code == 400
    bad = dict(SAMPLE, study_hours=500)
    assert client.post("/api/assessment", json=bad).status_code == 400
    assert client.post("/api/assessment", data="not json", content_type="text/plain").status_code == 400
    r = client.post("/api/assessment", json=dict(SAMPLE, interests=["hacking_nasa"]))
    assert r.status_code == 400 and "interests" in r.get_json()["details"]


def test_recommend_requires_assessment():
    fresh = app.test_client()
    assert fresh.post("/api/recommend", json={}).status_code == 404


def test_end_to_end():
    c = app.test_client()
    assert c.post("/api/assessment", json=SAMPLE).status_code == 201
    res = c.post("/api/recommend", json={}).get_json()
    assert res["top3"][0]["career_id"] == "ai_ml_engineer"       # sample student wants ML
    assert len(res["stages"]) == 5 and res["disclaimer"]
    path = c.post("/api/search-path", json={"career_id": "ai_ml_engineer", "algorithm": "both"}).get_json()
    assert path["astar"]["found"] and path["bfs"]["found"]
    assert path["astar"]["path_cost_hours"] == path["bfs"]["path_cost_hours"]
    rm = c.get("/api/roadmap?career_id=ai_ml_engineer").get_json()
    assert rm["progress"]["percent"] == 0
    p = c.post("/api/roadmap/progress", json={"career_id": "ai_ml_engineer", "skill_id": "statistics", "done": True})
    assert p.status_code == 200 and p.get_json()["progress"]["percent"] > 0
    rm2 = c.get("/api/roadmap?career_id=ai_ml_engineer").get_json()
    assert any(s["id"] == "statistics" and s["done"] for s in rm2["steps"])     # saved and reloaded
    assert c.post("/api/roadmap/progress", json={"career_id": "ai_ml_engineer", "skill_id": "zzz", "done": True}).status_code == 400
    assert c.post("/api/saved", json={"career_id": "data_analyst", "action": "save"}).get_json()["saved"]
    assert c.get("/api/compare?a=data_analyst&b=web_developer").status_code == 200
    assert c.get("/api/compare?a=data_analyst&b=data_analyst").status_code == 400


def test_a_star_is_optimal_and_beats_bfs_on_expansions_or_ties():
    sp = LearningSpace(ds.get_skills(), ["machine_learning"], [])
    a, b = astar(sp), bfs(sp)
    assert a["path_cost_hours"] == b["path_cost_hours"] and a["states_expanded"] <= b["states_expanded"]
    sp2 = LearningSpace(ds.get_skills(), ["machine_learning"], ["machine_learning"])
    assert sp2.is_goal(sp2.start)


def test_knowledge_graph():
    q = client.get("/api/knowledge-graph/query?subject=python_basics&relation=prerequisite_for").get_json()
    assert q["count"] >= 2
    assert client.get("/api/knowledge-graph/node/machine_learning").status_code == 200
    assert client.get("/api/knowledge-graph/node/zzz").status_code == 404
    assert len(client.get("/api/knowledge-graph").get_json()["nodes"]) > 40


def test_rag():
    ok = client.post("/api/rag/query", json={"question": "What maths do I need for machine learning?"}).get_json()
    assert ok["found"] and ok["mode"] == "extractive" and ok["sources"]
    none = client.post("/api/rag/query", json={"question": "best pizza recipe in Rome"}).get_json()
    assert not none["found"] and none["sources"] == []
    assert client.post("/api/rag/query", json={"question": ""}).status_code == 400
    assert client.post("/api/rag/query", json={"question": "x", "top_k": 99}).status_code == 400


def test_chat_offline():
    c = app.test_client()
    r = c.post("/api/chat", json={"message": "hello"}).get_json()
    assert r["mode"] == "offline" and r["reply"]
    c.post("/api/assessment", json=SAMPLE)
    r = c.post("/api/chat", json={"message": "Why was my top career recommended?"}).get_json()
    assert "AI/ML Engineer" in r["reply"]
    r = c.post("/api/chat", json={"message": "Compare data analyst vs web developer"}).get_json()
    assert "Shared skills" in r["reply"]
    assert c.post("/api/chat", json={"message": "x" * 600}).status_code == 400
    assert c.post("/api/chat", json={}).status_code == 400


def test_ml_and_neural():
    assert client.get("/api/ml/info").get_json()["meta"]["n_samples"] > 100
    r = client.post("/api/ml/neural-demo", json={"inputs": [0.9, 0.8, 0.1, 0.2, 0.3, 0.2]}).get_json()
    assert r["predicted_family"] == "Data / AI" and abs(sum(r["output_scores"].values()) - 1) < 0.01
    assert client.post("/api/ml/neural-demo", json={"inputs": [2, 0, 0, 0, 0, 0]}).status_code == 400


def test_llm_json_validation():
    from ai_engine.llm_service import validate_structured
    good = {"career_name": "Data Analyst", "reasons": ["a"], "matched_skills": [], "missing_skills": ["SQL"],
            "next_steps": ["x"], "confidence_notes": "n"}
    assert validate_structured(good)[0] is not None
    assert validate_structured(dict(good, career_name="Wizard"))[0] is None
    assert validate_structured(dict(good, reasons="text"))[0] is None
    assert validate_structured("nope")[0] is None


if __name__ == "__main__":
    fails = 0
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            try:
                fn(); print("PASS", name)
            except Exception as e:  # noqa
                fails += 1; print("FAIL", name, repr(e))
    sys.exit(1 if fails else 0)
