# Deploy PathFinder AI

## Option A - Netlify only (recommended, no server needed)
The `dist/` folder is a **standalone build**: the whole backend (BFS/A*, knowledge graph, agent, ranking, RAG, chat,
roadmap) runs inside the browser (`static/js/local_backend.js`). Assessments, saved careers and roadmap progress are
stored in the browser's localStorage (per device/browser).

1. Go to app.netlify.com -> your site -> Deploys.
2. Drag and drop the **dist** folder (the folder itself, with `index.html` inside).
3. Open your site, click "Discover My Future", use "Use sample profile" and submit.

Rebuild after editing anything in `data/`, `templates/` or `static/`:
```bash
python build_dist.py
```

What differs from the Python version: the ML signal uses a Bernoulli Naive Bayes trained in the browser on the same
synthetic dataset (instead of a scikit-learn RandomForest), there is no external LLM (offline assistant only), and
data is stored in localStorage instead of SQLite. Charts load Chart.js from a CDN, so they need internet access.

## Option B - Flask backend (Render) + Netlify frontend
Run `python build_dist.py https://YOUR-BACKEND.onrender.com` (this creates a proxy build that sends `/api/*` to your
Flask server), deploy the repo on Render using `render.yaml`, then drag `dist/` to Netlify.
Render's free plan sleeps when idle and resets SQLite on restart.

## Run locally (Python)
Double-click `start_server.bat` (Windows) or run `python app.py`, then open http://localhost:8000 or http://127.0.0.1:5000.
