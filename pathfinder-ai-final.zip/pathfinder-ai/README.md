# PathFinder AI — Discover Your Future

College AI project: career guidance with **BFS/A\* search, a knowledge graph, a rule-based agent, scikit-learn ML, a NumPy neural-network demo, LLM prompt engineering and RAG**. Runs fully offline; an LLM API key is optional.

## Install & run
```bash
cd pathfinder-ai
python -m venv venv
# Windows: venv\Scripts\activate      macOS/Linux: source venv/bin/activate
pip install -r requirements.txt
python app.py
```
Open **http://127.0.0.1:5000**. The database, ML model and training CSV are created automatically on first run.

## Try this
1. Landing page → **Discover My Future** → on step 6 use **Use sample profile** (or answer the questions).
2. Submit → **AI Analysis** → **Dashboard**: expect **AI/ML Engineer** first (score about 68, "Strong match"), followed by Software Developer and one more career.
3. Dashboard → run **BFS** and **A\*** (same cost, A\* expands fewer or equal states) → click nodes in the knowledge graph.
4. **Companion** page: ask "Why was my top career recommended?" and use the RAG inspector ("What maths do I need for machine learning?"). Ask "best pizza in Rome" → "No relevant source found".
5. **Roadmap**: tick a milestone, reload the page — progress is saved in SQLite.

## Put it online (Netlify)
The `dist/` folder is a ready-made standalone build (the backend runs in the browser). Drag it onto Netlify. See `DEPLOY.md`.

## Optional LLM
Copy `.env.example` to `.env`, set `LLM_API_KEY` (any OpenAI-compatible endpoint via `LLM_API_URL`, `LLM_MODEL`). The key stays on the server. If the call fails the offline assistant answers.

## Tests
`python -m pytest tests -q` or `python tests/test_app.py`

| Test | Expected |
|---|---|
| health | status ok, 10 careers, ML model loaded |
| invalid assessment (study_hours=500, unknown interest, non-JSON) | HTTP 400 with field details |
| recommend without assessment | HTTP 404 |
| sample student end-to-end | top career AI/ML Engineer, 5 stages, disclaimer present |
| BFS vs A* | equal optimal cost; A* expands ≤ BFS |
| roadmap progress | percent rises, survives reload; unknown skill → 400 |
| RAG | relevant question found + sources; "pizza" → not found |
| chat | offline mode, explains top career, compares careers, >500 chars → 400 |
| neural demo | outputs sum to 1; inputs outside 0–1 → 400 |
| LLM JSON validation | rejects unknown career / wrong types |

## Troubleshooting
- `ModuleNotFoundError`: activate the venv and run `pip install -r requirements.txt`.
- Port busy: `PORT=5001 python app.py`.
- Charts empty: Chart.js loads from a CDN; download it to `static/js/` and change the script tag in `templates/dashboard.html` for fully offline use.
- Reset everything: delete `database/pathfinder.db`, `ai_engine/model.pkl`, `data/training_data.csv`.
- ML unavailable: the recommender automatically re-balances weights without the model.

## Honest limitations
Demo knowledge base (10 careers, 47 skills). Training data is synthetic, so accuracy figures are optimistic. Scores are indicative, not probabilities of career success. Resource links are top-level sites and may change. Without an LLM the RAG answer is extractive, not generative.

## Project layout
`app.py` routes · `validators.py` · `database/init_db.py` · `data/*.json` editable knowledge · `ai_engine/` (state_space, search_algorithms, knowledge_graph, agent, recommender, train_model, roadmap, neural_demo, llm_service, rag_pipeline) · `templates/` · `static/`.
