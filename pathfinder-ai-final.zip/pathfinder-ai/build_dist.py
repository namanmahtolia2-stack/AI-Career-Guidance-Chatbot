"""
build_dist.py - creates the static ./dist folder for Netlify.

    python build_dist.py                         -> STANDALONE build (default). Everything runs in the browser,
                                                    no backend or database is needed. Just upload dist to Netlify.
    python build_dist.py https://my-api.onrender.com  -> PROXY build: pages call your deployed Flask backend.
"""
import os
import shutil
import sys
import tempfile

os.environ.setdefault("DATABASE_PATH", os.path.join(tempfile.mkdtemp(), "build.db"))
from app import app  # noqa: E402
from ai_engine import train_model  # noqa: E402

ROOT = os.path.dirname(os.path.abspath(__file__))
DIST = os.path.join(ROOT, "dist")
PAGES = {"/": "index.html", "/assessment": "assessment.html", "/analysis": "analysis.html",
         "/dashboard": "dashboard.html", "/explorer": "explorer.html", "/roadmap": "roadmap.html",
         "/companion": "companion.html", "/about": "about.html"}
MAIN = '<script src="/static/js/main.js"></script>'
LOCAL = '<script src="/static/js/local_backend.js"></script>\n'


def main(backend=None):
    if os.path.isdir(DIST):
        shutil.rmtree(DIST)
    os.makedirs(DIST)
    client = app.test_client()
    pages = dict(PAGES, **{"/does-not-exist": "404.html"})
    for url, name in pages.items():
        html = client.get(url).data.decode("utf-8")
        if not backend:
            assert MAIN in html, name
            html = html.replace(MAIN, LOCAL + MAIN)      # the in-browser backend must load before everything else
        with open(os.path.join(DIST, name), "w", encoding="utf-8") as f:
            f.write(html)
    shutil.copytree(os.path.join(ROOT, "static"), os.path.join(DIST, "static"))
    if not backend:
        train_model.train(save=False)                   # writes data/training_data.csv (synthetic training set)
        data_out = os.path.join(DIST, "static", "data")
        os.makedirs(data_out)
        for f in ("skills", "careers", "learning_resources", "knowledge_base", "agent_rules", "sample_assessment"):
            shutil.copy(os.path.join(ROOT, "data", f + ".json"), data_out)
        shutil.copy(os.path.join(ROOT, "data", "training_data.csv"), data_out)
        rules = "# standalone build: no API proxy needed\n"
    else:
        rules = f"/api/*  {backend.rstrip('/')}/api/:splat  200\n"
    with open(os.path.join(DIST, "_redirects"), "w") as f:
        f.write(rules)
    print("dist ready:", "STANDALONE (in-browser backend)" if not backend else f"API proxied to {backend}")


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else None)
