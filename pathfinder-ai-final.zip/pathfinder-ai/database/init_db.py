"""
database/init_db.py - SQLite setup.

Only anonymous data is stored: a random session id (cookie), the assessment answers,
saved careers and roadmap progress. No names, emails or phone numbers.
Run manually with:  python database/init_db.py
"""
import json
import os
import sqlite3
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def db_path():
    return os.getenv("DATABASE_PATH") or os.path.join(BASE_DIR, "database", "pathfinder.db")


def get_conn():
    conn = sqlite3.connect(db_path())
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


SCHEMA = """
CREATE TABLE IF NOT EXISTS assessments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    data_json TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS idx_assess_session ON assessments(session_id);

CREATE TABLE IF NOT EXISTS saved_roadmaps (
    session_id TEXT NOT NULL,
    career_id TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (session_id, career_id)
);

CREATE TABLE IF NOT EXISTS roadmap_progress (
    session_id TEXT NOT NULL,
    career_id TEXT NOT NULL,
    step_id TEXT NOT NULL,
    done INTEGER NOT NULL DEFAULT 0,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (session_id, career_id, step_id)
);
"""


def init_db(seed=True):
    os.makedirs(os.path.dirname(db_path()), exist_ok=True)
    with get_conn() as conn:
        conn.executescript(SCHEMA)
        if seed and conn.execute("SELECT COUNT(*) FROM assessments").fetchone()[0] == 0:
            from ai_engine import data_store as ds
            conn.execute("INSERT INTO assessments (session_id, data_json) VALUES (?, ?)",
                         ("demo-seed", json.dumps(ds.get_sample_assessment())))
            conn.execute("INSERT OR IGNORE INTO saved_roadmaps (session_id, career_id) VALUES (?, ?)",
                         ("demo-seed", "ai_ml_engineer"))
            conn.execute("INSERT OR IGNORE INTO roadmap_progress (session_id, career_id, step_id, done) VALUES (?,?,?,1)",
                         ("demo-seed", "ai_ml_engineer", "git_version_control"))


if __name__ == "__main__":
    init_db()
    print("Database ready at", db_path())
