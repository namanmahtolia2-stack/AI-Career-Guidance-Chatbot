/* main.js — shared helpers: API calls, toasts, particles, reveal animations, transitions, modal, tips */
(() => {
  const PF = (window.PF = {});
  const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  PF.$ = (s, r = document) => r.querySelector(s);
  PF.$$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  // ALWAYS escape server/user text before putting it into innerHTML
  PF.esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  PF.store = {
    get(k, d = null) { try { const v = localStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* storage blocked */ } },
  };
  PF.session = {
    get(k, d = null) { try { const v = sessionStorage.getItem(k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { sessionStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* ignore */ } },
  };

  PF.api = async (path, opts = {}) => {
    const o = { method: opts.method || "GET", headers: {}, credentials: "same-origin" };
    if (opts.body !== undefined) { o.method = opts.method || "POST"; o.headers["Content-Type"] = "application/json"; o.body = JSON.stringify(opts.body); }
    let res;
    try { res = await fetch(path, o); } catch (e) { throw new Error("Cannot reach the server. Is `python app.py` still running?"); }
    let data = null;
    try { data = await res.json(); } catch (e) { /* not JSON */ }
    if (!res.ok) { const err = new Error((data && data.error) || `Request failed (${res.status})`); err.status = res.status; err.details = data && data.details; throw err; }
    return data;
  };

  PF.toast = (msg, type = "info", ms = 3200) => {
    const box = PF.$("#toasts"); if (!box) return;
    const t = document.createElement("div"); t.className = `toast ${type}`; t.textContent = msg; t.setAttribute("role", "status");
    box.appendChild(t); setTimeout(() => { t.style.opacity = "0"; setTimeout(() => t.remove(), 300); }, ms);
  };

  PF.go = (url) => { const m = PF.$("#main"); if (m && !reduce) m.classList.add("page-out"); setTimeout(() => { window.location.href = url; }, reduce ? 0 : 320); };
  PF.skeleton = (el, n = 3) => { el.innerHTML = Array.from({ length: n }, () => '<div class="skel"></div>').join(""); };
  PF.empty = (el, html) => { el.innerHTML = `<div class="glass card center">${html}</div>`; };
  PF.errorBox = (el, msg, retry) => {
    el.innerHTML = `<div class="glass card center"><p>⚠️ ${PF.esc(msg)}</p>${retry ? '<button class="btn sm" id="retry-btn">Try again</button>' : ""}</div>`;
    if (retry) PF.$("#retry-btn", el).onclick = retry;
  };

  /* ---------- reveal on scroll (IntersectionObserver) ---------- */
  const io = "IntersectionObserver" in window ? new IntersectionObserver((entries) => entries.forEach((e) => { if (e.isIntersecting) { e.target.classList.add("in"); io.unobserve(e.target); } }), { threshold: 0.12 }) : null;
  PF.reveal = (root = document) => PF.$$(".reveal:not(.in)", root).forEach((el, i) => {
    el.style.transitionDelay = `${Math.min(i, 8) * 70}ms`;
    io ? io.observe(el) : el.classList.add("in");
  });

  /* ---------- particles: nodes joined by lines ---------- */
  function particles() {
    const c = PF.$("#particles"); if (!c) return;
    const ctx = c.getContext("2d"); let w, h, pts = [];
    const size = () => { w = c.width = innerWidth; h = c.height = innerHeight; const n = Math.min(70, Math.max(24, Math.floor((w * h) / 22000))); pts = Array.from({ length: n }, () => ({ x: Math.random() * w, y: Math.random() * h, vx: (Math.random() - .5) * .35, vy: (Math.random() - .5) * .35 })); };
    const draw = () => {
      ctx.clearRect(0, 0, w, h);
      pts.forEach((p) => { p.x += p.vx; p.y += p.vy; if (p.x < 0 || p.x > w) p.vx *= -1; if (p.y < 0 || p.y > h) p.vy *= -1; });
      for (let i = 0; i < pts.length; i++) {
        for (let j = i + 1; j < pts.length; j++) {
          const d = Math.hypot(pts[i].x - pts[j].x, pts[i].y - pts[j].y);
          if (d < 130) { ctx.strokeStyle = `rgba(120,150,255,${0.16 * (1 - d / 130)})`; ctx.beginPath(); ctx.moveTo(pts[i].x, pts[i].y); ctx.lineTo(pts[j].x, pts[j].y); ctx.stroke(); }
        }
        ctx.fillStyle = "rgba(34,211,238,.65)"; ctx.beginPath(); ctx.arc(pts[i].x, pts[i].y, 1.6, 0, 6.3); ctx.fill();
      }
      if (!reduce && !document.hidden) requestAnimationFrame(draw); else if (!reduce) setTimeout(() => requestAnimationFrame(draw), 500);
    };
    size(); addEventListener("resize", size); draw();
  }

  /* ---------- modal + tips ---------- */
  PF.tip = (container, id, text) => {
    if (!container || PF.store.get("pf_tip_" + id)) return;
    const d = document.createElement("div"); d.className = "tip"; d.innerHTML = `<span>💡 ${PF.esc(text)}</span><button aria-label="Dismiss tip">✕</button>`;
    d.querySelector("button").onclick = () => { PF.store.set("pf_tip_" + id, 1); d.remove(); };
    container.prepend(d);
  };

  function welcomeModal() {
    const m = PF.$("#welcome-modal"); if (!m) return;
    const close = () => { m.hidden = true; PF.store.set("pf_welcomed", 1); };
    PF.$$("[data-close-modal]", m).forEach((b) => (b.onclick = close));
    m.addEventListener("click", (e) => { if (e.target === m) close(); });
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !m.hidden) close(); });
    if (document.body.dataset.page === "index" && !PF.store.get("pf_welcomed")) setTimeout(() => { m.hidden = false; }, 1400);
  }

  document.addEventListener("DOMContentLoaded", () => {
    particles(); welcomeModal(); PF.reveal();
    const path = location.pathname;
    PF.$$(".nav-links a").forEach((a) => { if (a.getAttribute("href") === path) a.classList.add("active"); });
    const tg = PF.$(".nav-toggle");
    if (tg) tg.onclick = () => { const o = PF.$(".nav-links").classList.toggle("open"); tg.setAttribute("aria-expanded", o); };
    // smooth page transitions for internal links
    document.addEventListener("click", (e) => {
      const a = e.target.closest("a[href^='/']");
      if (!a || a.target === "_blank" || e.metaKey || e.ctrlKey || e.shiftKey || a.hasAttribute("download") || a.getAttribute("href").startsWith("/api/")) return;
      if (a.pathname === location.pathname && a.hash) return;
      e.preventDefault(); PF.go(a.getAttribute("href"));
    });
  });
  addEventListener("pageshow", (e) => { if (e.persisted) { const m = PF.$("#main"); m && m.classList.remove("page-out"); } });
})();
