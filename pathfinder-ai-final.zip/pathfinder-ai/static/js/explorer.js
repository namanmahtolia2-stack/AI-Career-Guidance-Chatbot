/* explorer.js — searchable career cards + detail modal */
(() => {
  const { $, $$, esc } = PF; const list = $("#list"), modal = $("#detail"), card = $("#detail-card");
  let cat = ""; let timer;
  const hashCat = decodeURIComponent((location.hash.match(/cat=([^&]+)/) || [])[1] || ""); if (hashCat) cat = hashCat;

  async function load() {
    PF.skeleton(list, 6);
    try {
      const d = await PF.api(`/api/careers?q=${encodeURIComponent($("#q").value.trim())}&category=${encodeURIComponent(cat)}`);
      $("#cats").innerHTML = ["", ...d.categories].map((c) => `<button class="chip ${cat === c ? "on" : ""}" data-cat="${esc(c)}">${c ? esc(c) : "All"}</button>`).join("");
      $$("[data-cat]").forEach((b) => (b.onclick = () => { cat = b.dataset.cat; load(); }));
      if (!d.careers.length) { PF.empty(list, "<p>No careers match your search. Try a different keyword.</p>"); return; }
      list.innerHTML = d.careers.map((c) => `<article class="glass card hover reveal" tabindex="0" role="button" data-id="${esc(c.id)}" aria-label="Open ${esc(c.name)}">
        <span class="muted small">${esc(c.category)}</span><h3>${esc(c.name)}</h3><p class="muted small">${esc(c.summary)}</p>
        <div class="chips">${c.required_skills.slice(0, 4).map((s) => `<span class="chip static">${esc(s)}</span>`).join("")}${c.required_skills.length > 4 ? `<span class="chip static">+${c.required_skills.length - 4}</span>` : ""}</div></article>`).join("");
      PF.reveal(list);
      $$("[data-id]", list).forEach((a) => { a.onclick = () => open(a.dataset.id); a.onkeydown = (e) => { if (e.key === "Enter") open(a.dataset.id); }; });
    } catch (e) { PF.errorBox(list, e.message, load); }
  }

  async function open(id) {
    modal.hidden = false; PF.skeleton(card, 2); history.replaceState(null, "", "#" + id);
    try {
      const c = await PF.api("/api/careers/" + encodeURIComponent(id));
      const ul = (a) => "<ul>" + a.map((x) => `<li>${esc(x)}</li>`).join("") + "</ul>";
      card.innerHTML = `<div class="row" style="justify-content:space-between"><div><span class="muted small">${esc(c.category)}</span><h2 id="d-title" style="margin:0">${esc(c.name)}</h2></div><button class="btn sm ghost" id="d-close" aria-label="Close">✕</button></div>
        <p>${esc(c.summary)}</p><h3>Required skills</h3><div class="chips">${c.required_skill_details.map((s) => `<span class="chip static">${esc(s.name)} · ${s.effort_hours}h</span>`).join("")}</div>
        <h3 style="margin-top:1rem">Prerequisites</h3><p class="muted">${esc(c.prerequisites)}</p>
        <div class="grid g2"><div><h3>Beginner projects</h3>${ul(c.beginner_projects)}</div><div><h3>Next steps</h3>${ul(c.next_steps)}</div></div>
        <h3>Learning resources</h3><ul>${c.resources.map((r) => `<li><a href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">${esc(r.title)}</a> <span class="muted small">(${esc(r.type)}, ${esc(r.level)})</span></li>`).join("")}</ul>
        <p class="muted small">Links are top-level sites of well-known providers; availability may change.</p>
        ${c.related.length ? `<p class="small">Related: ${c.related.map((r) => `<a href="#${esc(r.id)}" data-rel="${esc(r.id)}">${esc(r.name)}</a>`).join(", ")}</p>` : ""}
        <div class="row" style="margin-top:1rem"><button class="btn primary sm" id="d-save">☆ Save career</button><a class="btn sm" href="/roadmap#${esc(c.id)}">View roadmap</a></div>`;
      $("#d-close").onclick = close; $$("[data-rel]", card).forEach((a) => (a.onclick = (e) => { e.preventDefault(); open(a.dataset.rel); }));
      const saved = (await PF.api("/api/saved")).saved.some((s) => s.career_id === id), sb = $("#d-save"); if (saved) sb.textContent = "★ Saved";
      sb.onclick = async () => { const on = sb.textContent.includes("Saved"); try { await PF.api("/api/saved", { body: { career_id: id, action: on ? "remove" : "save" } }); sb.textContent = on ? "☆ Save career" : "★ Saved"; PF.toast(on ? "Removed" : "Saved!", "success"); } catch (e) { PF.toast(e.message, "error"); } };
    } catch (e) { card.innerHTML = ""; PF.errorBox(card, e.message); if (e.status === 404) history.replaceState(null, "", location.pathname); }
  }
  function close() { modal.hidden = true; history.replaceState(null, "", location.pathname); }
  modal.addEventListener("click", (e) => { if (e.target === modal) close(); });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !modal.hidden) close(); });
  $("#q").oninput = () => { clearTimeout(timer); timer = setTimeout(load, 250); };
  load().then(() => { const h = location.hash.slice(1); if (h && !h.startsWith("cat=")) open(h); });
})();
