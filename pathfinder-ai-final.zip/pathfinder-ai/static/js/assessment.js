/* assessment.js — 6-step questionnaire with chips, validation, back button and animated transitions */
(async () => {
  const { $, $$, esc } = PF;
  const wrap = $("#steps"); let opts;
  try { opts = await PF.api("/api/options"); } catch (e) { PF.errorBox(wrap, e.message, () => location.reload()); return; }

  const blank = () => ({ interests: [], skills: {}, subjects: [], work_style: "", problem_style: "", goals: "", study_hours: 8, education: "", learning_format: "" });
  let data = PF.session.get("pf_draft", null) || blank();
  let cur = 0, dir = 1; const TOTAL = 6;
  const save = () => PF.session.set("pf_draft", data);

  const chips = (items, key, max) => `<div class="chips" data-key="${key}" data-max="${max}">` + Object.entries(items).map(([id, label]) =>
    `<button type="button" class="chip ${data[key].includes(id) ? "on" : ""}" data-id="${esc(id)}" aria-pressed="${data[key].includes(id)}">${esc(label)}</button>`).join("") + "</div>";
  const single = (items, key) => `<div class="opt-cards" data-single="${key}">` + Object.entries(items).map(([id, label]) =>
    `<button type="button" class="opt ${data[key] === id ? "on" : ""}" data-id="${esc(id)}" aria-pressed="${data[key] === id}">${esc(label)}</button>`).join("") + "</div>";

  function skillsUI() {
    const groups = {}; opts.skills.forEach((s) => (groups[s.category] = groups[s.category] || []).push(s));
    return Object.entries(groups).map(([cat, list]) => `<div style="margin-bottom:.9rem"><div class="muted small" style="margin-bottom:.3rem">${esc(cat)}</div><div class="chips">` + list.map((s) => {
      const lvl = data.skills[s.id];
      return `<span class="skill-pick"><button type="button" class="chip ${lvl ? "on" : ""}" data-skill="${esc(s.id)}" aria-pressed="${!!lvl}">${esc(s.name)}</button>` +
        (lvl ? `<span class="lvl" data-lvl="${esc(s.id)}">${[1, 2, 3].map((n) => `<button type="button" class="${lvl === n ? "on" : ""}" data-n="${n}" title="${["Beginner", "Intermediate", "Advanced"][n - 1]}">${["Beg", "Int", "Adv"][n - 1]}</button>`).join("")}</span>` : "") + "</span>";
    }).join("") + "</div></div>").join("");
  }

  function summary() {
    const v = opts, nm = (m, ids) => ids.map((i) => v[m][i] || i).join(", ") || "—";
    const sk = Object.entries(data.skills).map(([id, l]) => `${(opts.skills.find((s) => s.id === id) || {}).name} (${["", "Beginner", "Intermediate", "Advanced"][l]})`).join(", ") || "None yet — that's fine!";
    return `<table><tr><th>Interests</th><td>${esc(nm("interests", data.interests))}</td></tr><tr><th>Skills</th><td>${esc(sk)}</td></tr>
      <tr><th>Subjects</th><td>${esc(nm("subjects", data.subjects))}</td></tr><tr><th>Education</th><td>${esc(v.education_levels[data.education] || "—")}</td></tr>
      <tr><th>Work style</th><td>${esc(v.work_styles[data.work_style] || "—")}</td></tr><tr><th>Problem solving</th><td>${esc(v.problem_styles[data.problem_style] || "—")}</td></tr>
      <tr><th>Goal</th><td>${esc(data.goals || "—")}</td></tr><tr><th>Study time</th><td>${data.study_hours} hours / week</td></tr><tr><th>Learning format</th><td>${esc(v.learning_formats[data.learning_format] || "—")}</td></tr></table>
      <p class="muted small">Only these anonymous answers are stored. No name, email or phone number is collected.</p>`;
  }

  const titles = ["What are you interested in?", "What can you already do?", "Subjects & education", "How do you like to work?", "Goals, time & learning style", "Review your answers"];
  function stepHTML(i) {
    if (i === 0) return `<h2>${titles[0]}</h2><p class="muted">Pick 1–10 areas that excite you.</p>${chips(opts.interests, "interests", 10)}`;
    if (i === 1) return `<h2>${titles[1]}</h2><p class="muted">Tap the skills you have and rate your level. Skip this if you are a complete beginner.</p>${skillsUI()}`;
    if (i === 2) return `<h2>${titles[2]}</h2><label class="lbl">Favourite subjects (up to 6)</label>${chips(opts.subjects, "subjects", 6)}<label class="lbl">Current education level</label>${single(opts.education_levels, "education")}`;
    if (i === 3) return `<h2>${titles[3]}</h2><label class="lbl">Preferred work style</label>${single(opts.work_styles, "work_style")}<label class="lbl">Problem-solving preference</label>${single(opts.problem_styles, "problem_style")}`;
    if (i === 4) return `<h2>${titles[4]}</h2><label class="lbl" for="goals">Career goal (optional, max 300 characters)</label><textarea id="goals" rows="3" maxlength="300" placeholder="e.g. I want to build machine learning projects">${esc(data.goals)}</textarea>
      <label class="lbl" for="hours">Study time per week: <b id="hours-out">${data.study_hours}</b> hours</label><input id="hours" type="range" min="1" max="40" value="${data.study_hours}">
      <label class="lbl">Preferred learning format</label>${single(opts.learning_formats, "learning_format")}`;
    return `<h2>${titles[5]}</h2>${summary()}`;
  }

  function show(animate = true) {
    wrap.innerHTML = `<div class="step active ${animate ? (dir < 0 ? "back" : "") : "noanim"}">${stepHTML(cur)}</div>`;
    $("#step-label").textContent = `Step ${cur + 1} of ${TOTAL}`; $("#pfill").style.width = `${((cur + 1) / TOTAL) * 100}%`;
    $("#pbar").setAttribute("aria-valuenow", Math.round(((cur + 1) / TOTAL) * 100));
    $("#back-btn").style.visibility = cur === 0 ? "hidden" : "visible"; $("#next-btn").textContent = cur === TOTAL - 1 ? "Get my recommendations ✨" : "Next →";
    $("#step-err").textContent = "";
    $$(".chips[data-key] .chip", wrap).forEach((c) => (c.onclick = () => {
      const g = c.parentElement, key = g.dataset.key, max = +g.dataset.max, id = c.dataset.id, arr = data[key];
      if (arr.includes(id)) data[key] = arr.filter((x) => x !== id); else if (arr.length >= max) { PF.toast(`You can choose up to ${max}.`, "info"); return; } else arr.push(id);
      c.classList.toggle("on"); c.setAttribute("aria-pressed", data[key].includes(id)); save();
    }));
    $$("[data-single] .opt", wrap).forEach((b) => (b.onclick = () => { data[b.parentElement.dataset.single] = b.dataset.id; $$(".opt", b.parentElement).forEach((o) => { o.classList.remove("on"); o.setAttribute("aria-pressed", "false"); }); b.classList.add("on"); b.setAttribute("aria-pressed", "true"); save(); }));
    $$("[data-skill]", wrap).forEach((b) => (b.onclick = () => { const id = b.dataset.skill; if (data.skills[id]) delete data.skills[id]; else data.skills[id] = 1; save(); const y = scrollY; show(false); scrollTo(0, y); }));
    $$("[data-lvl] button", wrap).forEach((b) => (b.onclick = () => { data.skills[b.parentElement.dataset.lvl] = +b.dataset.n; save(); const y = scrollY; show(false); scrollTo(0, y); }));
    const g = $("#goals"), h = $("#hours");
    if (g) g.oninput = () => { data.goals = g.value; save(); };
    if (h) h.oninput = () => { data.study_hours = +h.value; $("#hours-out").textContent = h.value; save(); };
  }

  function validate(i) {
    if (i === 0 && !data.interests.length) return "Please choose at least one interest.";
    if (i === 2 && !data.education) return "Please choose your education level.";
    if (i === 3 && !data.work_style) return "Please choose a preferred work style.";
    if (i === 3 && !data.problem_style) return "Please choose a problem-solving preference.";
    if (i === 4 && !data.learning_format) return "Please choose a preferred learning format.";
    if (i === 4 && data.goals.length > 300) return "Your goal is longer than 300 characters.";
    return "";
  }
  function fixLoaded(d) { return Object.assign(blank(), d); }

  $("#back-btn").onclick = () => { if (cur > 0) { cur--; dir = -1; show(); } };
  $("#next-btn").onclick = async () => {
    const msg = validate(cur); if (msg) { $("#step-err").textContent = msg; return; }
    if (cur < TOTAL - 1) { cur++; dir = 1; show(); return; }
    const btn = $("#next-btn"); btn.disabled = true; btn.textContent = "Saving…";
    try {
      const r = await PF.api("/api/assessment", { body: data });
      PF.session.set("pf_draft", null); PF.toast("Assessment saved!", "success"); PF.go("/analysis");
    } catch (e) {
      const det = e.details ? Object.values(e.details).join(" ") : ""; $("#step-err").textContent = `${e.message} ${det}`; PF.toast("Could not save: " + (det || e.message), "error");
      btn.disabled = false; btn.textContent = "Get my recommendations ✨";
    }
  };
  $("#sample-btn").onclick = async () => {
    try { data = fixLoaded(await PF.api("/api/demo")); save(); cur = TOTAL - 1; dir = 1; show(); PF.toast("Sample profile loaded — review and submit.", "success"); }
    catch (e) { PF.toast(e.message, "error"); }
  };
  PF.tip($(".wizard"), "assess", "There are no wrong answers. You can change anything with the Back button.");
  show();
})();
