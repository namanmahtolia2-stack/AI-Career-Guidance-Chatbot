/* about.js — live demos for every AI concept (educational page) */
(() => {
  const { $, $$, esc } = PF; const loaded = {};
  const loaders = { search: initSearch, kb: initKB, agent: initAgent, ml: initML, llm: initLLM };
  function show(p) {
    $$(".tab").forEach((t) => t.classList.toggle("on", t.dataset.p === p)); $$(".panel").forEach((x) => x.classList.toggle("on", x.id === "p-" + p));
    if (loaders[p] && !loaded[p]) { loaded[p] = true; loaders[p](); }
  }
  $$(".tab").forEach((t) => (t.onclick = () => { show(t.dataset.p); history.replaceState(null, "", "#" + t.dataset.p); }));
  const h = location.hash.slice(1); if (h && $("#p-" + h)) show(h);

  async function initSearch() {
    const careers = (await PF.api("/api/careers")).careers; $("#s-career").innerHTML = careers.map((c) => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join("");
    $("#s-run").onclick = async () => {
      const out = $("#s-out"); PF.skeleton(out, 1);
      try {
        const d = await PF.api("/api/search-path", { body: { career_id: $("#s-career").value, algorithm: "both", target: $("#s-target").value, known_skills: [] } });
        const row = (r) => `<tr><td>${esc(r.algorithm)}</td><td>${r.states_expanded}</td><td>${r.path_length ?? "—"}</td><td>${r.path_cost_hours ?? "—"} h</td><td>${r.truncated ? "stopped at safety limit" : r.found ? "path found" : "no path"}</td></tr>`;
        out.innerHTML = `<table><tr><th>Algorithm</th><th>States expanded</th><th>Steps</th><th>Cost</th><th>Result</th></tr>${row(d.bfs)}${row(d.astar)}</table><p class="small muted">${esc(d.astar.reasoning)}</p><p class="small muted">${esc(d.heuristic)}</p>`;
        const v = CareerGraph.renderSearch($("#s-graph"), d); await v.play(d.astar);
      } catch (e) { out.innerHTML = ""; PF.errorBox(out, e.message); }
    };
  }
  async function initKB() {
    const g = await PF.api("/api/knowledge-graph"); $("#k-s").innerHTML = '<option value="">any subject</option>' + g.nodes.map((n) => `<option value="${esc(n.id)}">${esc(n.label)} (${esc(n.type)})</option>`).join("");
    $("#k-s").value = "python_basics";
    $("#k-run").onclick = async () => {
      const out = $("#k-out"); PF.skeleton(out, 1);
      try { const r = await PF.api(`/api/knowledge-graph/query?subject=${encodeURIComponent($("#k-s").value)}&relation=${encodeURIComponent($("#k-r").value)}`);
        out.innerHTML = `<p class="small muted">${r.count} fact(s) found${r.count > 100 ? " (showing 100)" : ""}</p><ul class="small">${r.triples.map((t) => `<li><code>(${esc(t.subject)}, ${esc(t.relation)}, ${esc(t.object)})</code> — ${esc(t.text)}</li>`).join("")}</ul>`;
      } catch (e) { out.innerHTML = ""; PF.errorBox(out, e.message); }
    };
  }
  async function initAgent() {
    try { const r = await PF.api("/api/agent/rules"); $("#a-out").innerHTML = `<table><tr><th>Rule</th><th>Explanation</th></tr>${r.rules.map((x) => `<tr><td><b>${esc(x.name)}</b></td><td class="small">${esc(x.explanation)}</td></tr>`).join("")}</table>`; }
    catch (e) { PF.errorBox($("#a-out"), e.message); }
  }
  async function initML() {
    try {
      const r = await PF.api("/api/ml/info"), m = r.meta;
      $("#ml-out").innerHTML = r.available ? `<p class="small">${esc(m.model_type)} · ${m.n_samples} synthetic samples · ${m.n_features} features · ${m.n_classes} careers</p>
        <p class="small">Test accuracy <b>${m.test_accuracy}</b> · 5-fold CV <b>${m.cv_mean} ± ${m.cv_std}</b></p>
        <table><tr><th>Top features</th><th>Importance</th></tr>${m.top_features.map((f) => `<tr><td class="small">${esc(f.feature)}</td><td>${f.importance}</td></tr>`).join("")}</table>
        <p class="small muted">${m.limitations.map(esc).join(" ")}</p><p class="small muted">${esc(r.formula)}</p>` : `<p>Model unavailable. ${esc(r.fallback)}</p>`;
    } catch (e) { PF.errorBox($("#ml-out"), e.message); }
    const names = ["Maths", "Programming", "Design", "Security", "Business", "Hands-on"], vals = [0.9, 0.8, 0.1, 0.2, 0.3, 0.2]; let t;
    $("#nn-sliders").innerHTML = names.map((n, i) => `<label class="small" style="display:block">${n}: <b id="nv${i}">${vals[i]}</b><input type="range" min="0" max="1" step="0.05" value="${vals[i]}" data-i="${i}"></label>`).join("");
    const run = async () => {
      try {
        const r = await PF.api("/api/ml/neural-demo", { body: { inputs: vals } });
        $("#nn-out").innerHTML = `<p class="small"><b>Hidden (after ReLU):</b> [${r.hidden_after_relu.join(", ")}]</p>` + Object.entries(r.output_scores).map(([k, v]) => `<div class="small">${esc(k)} ${v}</div><div class="bar"><i style="width:${v * 100}%"></i></div>`).join("") +
          `<p class="small">Predicted family: <b>${esc(r.predicted_family)}</b></p><p class="muted small">${esc(r.architecture)} · trained ${r.epochs} epochs on synthetic data, train accuracy ${r.train_accuracy}. ${esc(r.disclaimer)}</p>`;
      } catch (e) { PF.errorBox($("#nn-out"), e.message); }
    };
    $$("#nn-sliders input").forEach((s) => (s.oninput = () => { vals[+s.dataset.i] = +s.value; $("#nv" + s.dataset.i).textContent = s.value; clearTimeout(t); t = setTimeout(run, 150); }));
    run();
  }
  async function initLLM() {
    try { const r = await PF.api("/api/chat/prompts"); $("#llm-list").innerHTML = r.design.map((d) => `<li class="small">${esc(d)}</li>`).join("");
      $("#llm-status").textContent = r.llm_configured ? "Status: an LLM API key is configured on the server." : "Status: no API key set — the offline rule-based assistant is active (this is the default)."; }
    catch (e) { PF.errorBox($("#llm-list"), e.message); }
  }

  $("#demo-run").onclick = async () => {
    const out = $("#demo-out"); PF.skeleton(out, 2);
    try {
      const sample = await PF.api("/api/demo"), r = await PF.api("/api/recommend", { body: { assessment: sample } }), t = r.top3[0];
      const path = await PF.api("/api/search-path", { body: { career_id: t.career_id, algorithm: "both", known_skills: Object.keys(sample.skills) } });
      const rag = await PF.api("/api/rag/query", { body: { question: "What maths do I need for machine learning?" } });
      out.innerHTML = `<h3>1. Agent perceived</h3><p class="small">${esc(sample.interests.join(", "))} · ${sample.study_hours} h/week · ${r.rules_fired.length} rules fired</p>
        <h3>2. Ranking (ML + skills + interests + rules)</h3><p class="small">${r.top3.map((x) => `${esc(x.career_name)} <b>${x.score}</b>`).join(" · ")}</p>
        <h3>3. Search for ${esc(t.career_name)}</h3><p class="small">BFS expanded ${path.bfs.states_expanded} states; A* expanded ${path.astar.states_expanded}; cost ${path.astar.path_cost_hours} h. Path: ${esc(path.astar.path.map((p) => p.name).join(" → "))}</p>
        <h3>4. RAG</h3><p class="small">${esc(rag.answer)}<br><span class="muted">Sources: ${rag.sources.map(esc).join(" · ")}</span></p><p class="muted small">Demo mode uses an inline sample and does not overwrite your saved assessment.</p>`;
    } catch (e) { out.innerHTML = ""; PF.errorBox(out, e.message); }
  };
})();
