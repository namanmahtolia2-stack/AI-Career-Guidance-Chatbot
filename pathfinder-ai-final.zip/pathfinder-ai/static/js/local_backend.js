/* local_backend.js — STANDALONE MODE (used on Netlify)
 * A browser port of the Flask backend. It intercepts fetch("/api/...") calls and answers them locally from
 * /static/data/*.json. Progress and assessments are stored in localStorage, so no server or database is needed.
 * Differences from the Python version: the ML signal comes from a Bernoulli Naive Bayes model trained in the
 * browser on the same synthetic dataset (not a RandomForest), and no external LLM is used (offline assistant). */
(() => {
  "use strict";
  const origFetch = window.fetch.bind(window);
  const FILES = ["skills", "careers", "learning_resources", "knowledge_base", "agent_rules", "sample_assessment"];
  let DP = null;
  const SK = {}, CR = {};
  let D, VOC, TRIPLES = [];

  const clean = (t, l) => String(t ?? "").replace(/[\x00-\x08\x0b-\x1f\x7f]/g, " ").trim().slice(0, l);
  const fail = (message, status = 400, details) => { throw { status, body: details ? { error: message, details } : { error: message } }; };
  const r1 = (x) => Math.round(x * 10) / 10, r2 = (x) => Math.round(x * 100) / 100, r3 = (x) => Math.round(x * 1000) / 1000;
  const sum = (a) => a.reduce((s, x) => s + x, 0);
  const sorted = (a) => [...a].sort();

  /* ---------------- storage (replaces SQLite) ---------------- */
  const KEY = "pf_local_v1";
  const getDB = () => { try { return JSON.parse(localStorage.getItem(KEY)) || { assessments: [], saved: [], progress: {}, nextId: 1 }; } catch (e) { return { assessments: [], saved: [], progress: {}, nextId: 1 }; } };
  const setDB = (db) => { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch (e) { /* storage blocked: app still works for this page */ } };
  const latestAssessment = () => { const a = getDB().assessments; return a.length ? a[a.length - 1] : null; };
  const completed = (cid) => { const p = getDB().progress; const out = new Set(); (cid ? [cid] : Object.keys(p)).forEach((c) => Object.entries(p[c] || {}).forEach(([s, v]) => v && out.add(s))); return out; };

  /* ---------------- data loading ---------------- */
  function loadData() {
    if (DP) return DP;
    DP = (async () => {
      const o = {};
      for (const f of FILES) { const r = await origFetch(`/static/data/${f}.json`); if (!r.ok) throw new Error("Could not load data file " + f); o[f] = await r.json(); }
      try { const r = await origFetch("/static/data/training_data.csv"); o.csv = r.ok ? await r.text() : null; } catch (e) { o.csv = null; }
      o.skills.forEach((s) => (SK[s.id] = s)); o.careers.forEach((c) => (CR[c.id] = c));
      D = o; VOC = o.knowledge_base.vocab; buildKG(); trainNB(); buildRAG();
      return o;
    })();
    return DP;
  }

  /* ---------------- knowledge graph (triples) ---------------- */
  const REL = { prerequisite_for: "is a prerequisite for", required_skill_for: "is a required skill for", interest_leads_to: "leads towards", related_to: "is related to" };
  function buildKG() {
    const seen = new Set(); TRIPLES = [];
    const add = (s, r, o) => { const k = s + "|" + r + "|" + o; if (!seen.has(k)) { seen.add(k); TRIPLES.push([s, r, o]); } };
    D.skills.forEach((s) => s.prerequisites.forEach((p) => add(p, "prerequisite_for", s.id)));
    D.careers.forEach((c) => { c.required_skills.forEach((s) => add(s, "required_skill_for", c.id)); c.interests.forEach((i) => add(i, "interest_leads_to", c.id)); });
    (D.knowledge_base.extra_triples || []).forEach(([s, r, o]) => add(s, r, o));
  }
  const nodeType = (id) => (CR[id] ? "career" : SK[id] ? "skill" : VOC.interests[id] ? "interest" : "concept");
  const label = (id) => (CR[id] ? CR[id].name : SK[id] ? SK[id].name : VOC.interests[id] || id);
  const kgQuery = (s, r, o) => TRIPLES.filter(([a, b, c]) => (!s || a === s) && (!r || b === r) && (!o || c === o))
    .map(([a, b, c]) => ({ subject: a, relation: b, object: c, text: `${label(a)} ${REL[b] || b} ${label(c)}` }));
  function ancestors(id) { const res = new Set(), st = [...SK[id].prerequisites]; while (st.length) { const s = st.pop(); if (!res.has(s)) { res.add(s); st.push(...SK[s].prerequisites); } } return res; }
  const relatedCareers = (id) => [...TRIPLES.filter(([s, r]) => s === id && r === "related_to").map((t) => t[2]), ...TRIPLES.filter(([s, r, o]) => o === id && r === "related_to").map((t) => t[0])];
  const careersForInterest = (i) => TRIPLES.filter(([s, r]) => s === i && r === "interest_leads_to").map((t) => t[2]);
  function nodeInfo(id) {
    const rel = { outgoing: kgQuery(id), incoming: kgQuery(null, null, id) };
    if (nodeType(id) === "concept" && !rel.outgoing.length && !rel.incoming.length) return null;
    const info = { id, label: label(id), type: nodeType(id), relations: rel };
    if (CR[id]) { info.summary = CR[id].summary; info.required_skills = CR[id].required_skills.map(label); }
    else if (SK[id]) { info.summary = SK[id].description; info.effort_hours = SK[id].effort_hours; info.required_skills = SK[id].prerequisites.map(label); }
    return info;
  }
  function toGraph(focus) {
    let keep = null;
    if (focus && CR[focus]) { keep = new Set([focus]); CR[focus].required_skills.forEach((s) => { keep.add(s); ancestors(s).forEach((a) => keep.add(a)); }); CR[focus].interests.forEach((i) => keep.add(i)); relatedCareers(focus).forEach((c) => keep.add(c)); }
    const nodes = [], ids = new Set();
    TRIPLES.forEach(([s, , o]) => [s, o].forEach((n) => { if ((!keep || keep.has(n)) && !ids.has(n)) { ids.add(n); nodes.push({ id: n, label: label(n), type: nodeType(n) }); } }));
    return { nodes, edges: TRIPLES.filter(([s, , o]) => ids.has(s) && ids.has(o)).map(([s, r, o]) => ({ source: s, target: o, relation: r })), note: "Demonstration knowledge base, not a complete professional career database." };
  }

  /* ---------------- state-space search: BFS and A* ---------------- */
  function makeSpace(goal, known) {
    const needed = new Set(), stack = goal.filter((g) => !known.has(g));
    while (stack.length) { const s = stack.pop(); if (needed.has(s)) continue; needed.add(s); SK[s].prerequisites.forEach((p) => { if (!known.has(p)) stack.push(p); }); }
    return { goal, needed, neededSorted: sorted(needed), known0: known };
  }
  const isGoal = (sp, learned) => { const L = new Set(learned); return sp.goal.every((g) => sp.known0.has(g) || L.has(g)); };
  const hCost = (sp, learned, w) => { const L = new Set(learned); return w * sum(sp.neededSorted.filter((s) => !L.has(s)).map((s) => SK[s].effort_hours)); };
  function successors(sp, learned) {
    const L = new Set(learned), out = [];
    for (const sid of sp.neededSorted) if (!L.has(sid) && SK[sid].prerequisites.every((p) => sp.known0.has(p) || L.has(p))) out.push([sid, sorted([...learned, sid])]);
    return out;
  }
  function explain(res, weight) {
    if (res.truncated) return `${res.algorithm} stopped after ${res.states_expanded} expanded states without reaching the goal. The number of possible learning states grows exponentially with the number of skills, which is why blind search can become impractical and a guided search is useful.`;
    if (!res.found) return `${res.algorithm} found no path. The goal may already be reached or the data may be inconsistent.`;
    const base = `${res.algorithm} expanded ${res.states_expanded} states and found a ${res.path_length}-step path costing about ${res.path_cost_hours} hours. `;
    return res.algorithm === "BFS" ? base + "BFS explores every state at each depth before going deeper. It guarantees the fewest steps, but it does not look at effort, so it may explore many unnecessary states."
      : base + `A* ranked states by f(n) = g(n) + h(n), where h(n) = ${weight} x remaining effort hours. Because h never over-estimates the real remaining effort, the path is optimal in cost. Limitation: effort values are rough estimates, and h assumes every missing skill must be learned.`;
  }
  function result(name, sp, steps, explored, expanded, truncated, fmax, weight) {
    const res = { algorithm: name, found: steps !== null, path: (steps || []).map((s) => ({ skill: s, name: SK[s].name, cost: SK[s].effort_hours })), path_length: steps ? steps.length : null,
      path_cost_hours: steps ? sum(steps.map((s) => SK[s].effort_hours)) : null, states_expanded: expanded, frontier_max: fmax, truncated, explored: explored.slice(0, 80), explored_total: explored.length, needed_skills: sp.neededSorted };
    res.reasoning = explain(res, weight); return res;
  }
  const buildPath = (parents, key) => { const steps = []; while (parents.get(key).prev !== null) { steps.push(parents.get(key).action); key = parents.get(key).prev; } return steps.reverse(); };
  function bfs(sp, maxExp = 4000) {
    const startKey = "", parents = new Map([[startKey, { prev: null, action: null }]]), states = new Map([[startKey, []]]);
    const queue = [startKey]; let head = 0, expanded = 0, fmax = 1; const explored = [];
    while (head < queue.length) {
      const key = queue[head++], learned = states.get(key); expanded++;
      explored.push({ order: expanded, action: parents.get(key).action, known_count: sp.known0.size + learned.length, g: sum(learned.map((s) => SK[s].effort_hours)) });
      if (isGoal(sp, learned)) return result("BFS", sp, buildPath(parents, key), explored, expanded, false, fmax);
      if (expanded >= maxExp) return result("BFS", sp, null, explored, expanded, true, fmax);
      for (const [action, next] of successors(sp, learned)) { const nk = next.join("|"); if (!parents.has(nk)) { parents.set(nk, { prev: key, action }); states.set(nk, next); queue.push(nk); } }
      fmax = Math.max(fmax, queue.length - head);
    }
    return result("BFS", sp, null, explored, expanded, false, fmax);
  }
  class Heap { constructor() { this.a = []; } get size() { return this.a.length; }
    less(x, y) { return x[0] !== y[0] ? x[0] < y[0] : x[1] !== y[1] ? x[1] < y[1] : x[2] < y[2]; }
    push(v) { const a = this.a; a.push(v); let i = a.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (this.less(a[i], a[p])) { [a[i], a[p]] = [a[p], a[i]]; i = p; } else break; } }
    pop() { const a = this.a, top = a[0], last = a.pop(); if (a.length) { a[0] = last; let i = 0; for (;;) { let l = 2 * i + 1, r = l + 1, m = i; if (l < a.length && this.less(a[l], a[m])) m = l; if (r < a.length && this.less(a[r], a[m])) m = r; if (m === i) break; [a[i], a[m]] = [a[m], a[i]]; i = m; } } return top; } }
  function astar(sp, weight = 0.8, maxExp = 20000) {
    const startKey = "", gCost = new Map([[startKey, 0]]), parents = new Map([[startKey, { prev: null, action: null }]]), states = new Map([[startKey, []]]);
    const heap = new Heap(), closed = new Set(); let counter = 0, expanded = 0, fmax = 1; const explored = [];
    heap.push([hCost(sp, [], weight), 0, counter, startKey]);
    while (heap.size) {
      const [, , , key] = heap.pop(); if (closed.has(key)) continue; closed.add(key);
      const learned = states.get(key), g = gCost.get(key), h = hCost(sp, learned, weight); expanded++;
      explored.push({ order: expanded, action: parents.get(key).action, known_count: sp.known0.size + learned.length, g: r1(g), h: r1(h), f: r1(g + h) });
      if (isGoal(sp, learned)) return result("A*", sp, buildPath(parents, key), explored, expanded, false, fmax, weight);
      if (expanded >= maxExp) return result("A*", sp, null, explored, expanded, true, fmax, weight);
      for (const [action, next] of successors(sp, learned)) {
        const ng = g + SK[action].effort_hours, nk = next.join("|");
        if (!gCost.has(nk) || ng < gCost.get(nk)) { gCost.set(nk, ng); parents.set(nk, { prev: key, action }); states.set(nk, next); counter++; heap.push([ng + hCost(sp, next, weight), -(sp.known0.size + next.length), counter, nk]); }
      }
      fmax = Math.max(fmax, heap.size);
    }
    return result("A*", sp, null, explored, expanded, false, fmax, weight);
  }

  /* ---------------- machine learning: Bernoulli Naive Bayes trained in the browser ---------------- */
  let NB = null;
  function rng(seed) { let a = seed >>> 0; return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  function normal(rand) { return Math.sqrt(-2 * Math.log(rand() + 1e-12)) * Math.cos(2 * Math.PI * rand()); }
  function fitNB(X, y, classes) {
    const nF = X[0].length, model = { classes, prior: [], theta: [] };
    classes.forEach((c) => { const rows = X.filter((_, i) => y[i] === c), th = new Array(nF).fill(0);
      rows.forEach((r) => r.forEach((v, j) => (th[j] += v))); model.theta.push(th.map((t) => (t + 1) / (rows.length + 2))); model.prior.push(Math.log(rows.length / X.length)); });
    return model;
  }
  function probsNB(model, vec) {
    const T = 8, ll = model.classes.map((_, k) => model.prior[k] + vec.reduce((s, v, j) => s + (v ? Math.log(model.theta[k][j]) : Math.log(1 - model.theta[k][j])), 0));
    const m = Math.max(...ll), e = ll.map((l) => Math.exp((l - m) / T)), z = sum(e); return e.map((x) => x / z);
  }
  function trainNB() {
    if (!D.csv) { NB = null; return; }
    try {
      const lines = D.csv.trim().split(/\r?\n/), header = lines[0].split(","), names = header.slice(0, -1);
      const X = [], y = []; lines.slice(1).forEach((ln) => { const p = ln.split(","); X.push(p.slice(0, -1).map(Number)); y.push(p[p.length - 1]); });
      const classes = sorted([...new Set(y)]), rand = rng(42), idx = X.map((_, i) => i);
      for (let i = idx.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [idx[i], idx[j]] = [idx[j], idx[i]]; }
      const acc = (tr, te) => { const m = fitNB(tr.map((i) => X[i]), tr.map((i) => y[i]), classes); return te.filter((i) => { const p = probsNB(m, X[i]); return classes[p.indexOf(Math.max(...p))] === y[i]; }).length / te.length; };
      const cut = Math.floor(idx.length * 0.25), test = acc(idx.slice(cut), idx.slice(0, cut));
      const folds = [0, 1, 2, 3, 4].map((f) => acc(idx.filter((_, k) => k % 5 !== f), idx.filter((_, k) => k % 5 === f)));
      const cvm = sum(folds) / 5, cvs = Math.sqrt(sum(folds.map((a) => (a - cvm) ** 2)) / 5);
      const model = fitNB(X, y, classes);
      const spread = names.map((n, j) => ({ feature: n, importance: r3(Math.max(...model.theta.map((t) => t[j])) - Math.min(...model.theta.map((t) => t[j]))) })).sort((a, b) => b.importance - a.importance).slice(0, 10);
      NB = { model, names, meta: { model_type: "Bernoulli Naive Bayes (trained in your browser)", n_samples: X.length, n_features: names.length, n_classes: classes.length, test_accuracy: r3(test), cv_mean: r3(cvm), cv_std: r3(cvs),
        top_features: spread, trained_at: new Date().toISOString(),
        limitations: ["Synthetic data generated from our own career profiles, so accuracy is optimistic.", "Not trained on real students or real job outcomes.", "Probabilities are temperature-softened and uncalibrated; they are used only as one relative signal in ranking.", "Importance here = how much a feature's probability differs between careers."] } };
    } catch (e) { NB = null; }
  }
  function featurize(st, known) {
    return NB.names.map((n) => { const [k, ...r] = n.split(":"), id = r.join(":");
      return (k === "interest" ? st.interests.includes(id) : k === "subject" ? st.subjects.includes(id) : k === "work" ? st.work_style === id : k === "problem" ? st.problem_style === id : known.has(id)) ? 1 : 0; });
  }
  function modelSignal(st, known) {
    if (!NB) return {};
    const p = probsNB(NB.model, featurize(st, known)), top = Math.max(...p) || 1, out = {}; NB.model.classes.forEach((c, i) => (out[c] = p[i] / top)); return out;
  }

  /* ---------------- recommender ---------------- */
  const W = { skill: 0.30, interest: 0.25, model: 0.25, readiness: 0.10, rules: 0.10 }, W0 = { skill: 0.35, interest: 0.30, model: 0, readiness: 0.15, rules: 0.20 };
  const LW = { 0: 0, 1: 0.4, 2: 0.75, 3: 1 };
  const band = (s) => (s >= 65 ? "Strong match" : s >= 45 ? "Good match" : "Exploratory match");
  const overlap = (stu, items, cap = 3) => (!items.length ? 0 : Math.min(1, stu.filter((x) => items.includes(x)).length / Math.min(items.length, cap)));
  function structured(r) {
    const first = r.missing_skills.filter((m) => m.ready_to_start).slice(0, 3).map((m) => m.name);
    return { career_name: r.career_name, reasons: r.reasons, matched_skills: r.matched_skills.map((s) => s.name), missing_skills: r.missing_skills.map((m) => m.name),
      next_steps: first.length ? first.map((n) => `Start with ${n}.`) : ["Build a portfolio project that uses your skills."], confidence_notes: "Indicative score from a small demonstration knowledge base; not a prediction of career success." };
  }
  function rank(st, boosts) {
    const known = new Set(Object.entries(st.skills).filter(([, l]) => l >= 1).map(([s]) => s)), sig = modelSignal(st, known), w = NB ? W : W0, out = [];
    for (const c of D.careers) {
      const req = c.required_skills, ov = sum(req.map((s) => LW[Math.min(3, st.skills[s] || 0)])) / req.length;
      const mi = st.interests.filter((i) => c.interests.includes(i)), ms = st.subjects.filter((s) => c.subjects.includes(s));
      const im = 0.6 * overlap(st.interests, c.interests) + 0.2 * overlap(st.subjects, c.subjects, 2) + 0.1 * (c.work_styles.includes(st.work_style) ? 1 : 0) + 0.1 * (c.problem_styles.includes(st.problem_style) ? 1 : 0);
      const missing = req.filter((s) => !known.has(s)), info = missing.map((s) => { const gaps = SK[s].prerequisites.filter((p) => !known.has(p));
        return { id: s, name: SK[s].name, effort_hours: SK[s].effort_hours, missing_prerequisites: gaps.map((p) => SK[p].name), ready_to_start: !gaps.length }; });
      const ready = missing.length ? info.filter((m) => m.ready_to_start).length / missing.length : 1, boost = Math.min(0.15, (boosts[c.id] || 0)) / 0.15;
      const parts = { skill: ov, interest: im, model: sig[c.id] || 0, readiness: ready, rules: boost };
      const score = Math.round(100 * sum(Object.keys(parts).map((k) => w[k] * parts[k])) * 10) / 10;
      const reasons = []; if (mi.length) reasons.push("Your interests in " + mi.map((i) => VOC.interests[i]).join(", ") + " appear in this career's profile.");
      if (ms.length) reasons.push("Your favourite subjects (" + ms.map((s) => VOC.subjects[s]).join(", ") + ") are commonly useful here.");
      reasons.push(`You already have ${req.filter((s) => known.has(s)).length} of the ${req.length} core skills in the knowledge base for this career.`);
      const rd = info.filter((m) => m.ready_to_start).map((m) => m.name); if (rd.length) reasons.push("You can start right away with: " + rd.slice(0, 3).join(", ") + ".");
      const rec = { career_id: c.id, career_name: c.name, category: c.category, summary: c.summary, score, band: band(score), components: Object.fromEntries(Object.entries(parts).map(([k, v]) => [k, r2(v)])),
        matched_interests: mi.map((i) => VOC.interests[i]), matched_subjects: ms.map((s) => VOC.subjects[s]), matched_skills: req.filter((s) => known.has(s)).map((s) => ({ id: s, name: SK[s].name, level: st.skills[s] })), missing_skills: info, reasons };
      rec.structured = structured(rec); out.push(rec);
    }
    return out.sort((a, b) => b.score - a.score);
  }

  /* ---------------- roadmap ---------------- */
  function topo(needed, known) { const order = [], done = new Set(known); while (order.length < needed.size) { let prog = false; for (const s of sorted(needed)) if (!done.has(s) && SK[s].prerequisites.every((p) => done.has(p))) { order.push(s); done.add(s); prog = true; } if (!prog) break; } return order; }
  const resForSkill = (id) => D.learning_resources.filter((r) => (r.covers || []).includes(id));
  function buildRoadmap(cid, known, hours, done) {
    const c = CR[cid], sp = makeSpace(c.required_skills, known), res = astar(sp, 1.0), done2 = done || new Set();
    const order = res.found ? res.path.map((p) => p.skill) : topo(sp.needed, known), hpw = Math.max(1, parseInt(hours) || 5), steps = [];
    order.forEach((sid, i) => { const s = SK[sid], h = s.effort_hours;
      steps.push({ order: i + 1, id: sid, type: "skill", name: s.name, description: s.description, hours: h, hours_range: [Math.round(h * 0.8), Math.round(h * 1.3)], weeks: r1(h / hpw),
        prerequisites: s.prerequisites.map((p) => ({ id: p, name: SK[p].name, in_roadmap: sp.needed.has(p) })), is_core: c.required_skills.includes(sid),
        resources: resForSkill(sid).slice(0, 3).map((r) => ({ title: r.title, url: r.url })), done: done2.has(sid) }); });
    steps.push({ order: steps.length + 1, id: "portfolio_project", type: "project", name: "Portfolio Project", description: "Build and publish one project that uses your new skills: " + c.beginner_projects[0] + ".",
      hours: 30, hours_range: [24, 40], weeks: r1(30 / hpw), prerequisites: [], is_core: true, resources: [], done: done2.has("portfolio_project") });
    steps.forEach((s, i) => (s.milestone = "Milestone " + (Math.floor(i / 3) + 1)));
    const total = sum(steps.map((s) => s.hours));
    return { career_id: cid, career_name: c.name, steps, total_hours: total, total_hours_range: [Math.round(total * 0.8), Math.round(total * 1.3)], total_weeks: r1(total / hpw), hours_per_week: hpw,
      search: { algorithm: res.algorithm, states_expanded: res.states_expanded, path_cost_hours: res.path_cost_hours, reasoning: res.reasoning },
      already_known: c.required_skills.filter((s) => known.has(s)).map((s) => SK[s].name), note: "Time ranges are rough estimates for a beginner, not guarantees." };
  }
  const progressSummary = (p) => { const d = p.steps.filter((s) => s.done).length, t = p.steps.length; return { done: d, total: t, percent: t ? Math.round((100 * d) / t) : 0 }; };
  function weeklyPlan(p, weeks = 4) {
    const todo = p.steps.filter((s) => !s.done).map((s) => ({ ...s, left: s.hours })), out = []; let i = 0;
    for (let w = 1; w <= weeks; w++) { const items = []; let free = p.hours_per_week; while (free > 0 && i < todo.length) { const take = Math.min(free, todo[i].left); items.push({ skill: todo[i].name, hours: take }); todo[i].left -= take; free -= take; if (todo[i].left <= 0) i++; } if (items.length) out.push({ week: w, items }); }
    return out;
  }

  /* ---------------- agent ---------------- */
  const PIPELINE = ["Start State", "Interest Analysis", "Skill Assessment", "Career Candidates", "Prerequisite Validation", "Ranked Career Paths", "Learning Roadmap"];
  function perceive(a, completedSkills) {
    const skills = { ...(a.skills || {}) }; (completedSkills || []).forEach((s) => (skills[s] = Math.max(skills[s] || 0, 2)));
    return { interests: [...(a.interests || [])], subjects: [...(a.subjects || [])], skills, work_style: a.work_style || "", problem_style: a.problem_style || "", goals: a.goals || "", study_hours: parseInt(a.study_hours ?? 5), education: a.education || "", learning_format: a.learning_format || "" };
  }
  function ruleMatches(c, st) {
    const known = new Set(Object.entries(st.skills).filter(([, l]) => l >= 1).map(([s]) => s));
    const chk = { interests_all: (v) => v.every((x) => st.interests.includes(x)), interests_any: (v) => !v.length || v.some((x) => st.interests.includes(x)), subjects_any: (v) => !v.length || v.some((x) => st.subjects.includes(x)),
      skills_any: (v) => !v.length || v.some((x) => known.has(x)), work_styles_any: (v) => !v.length || v.includes(st.work_style), problem_styles_any: (v) => !v.length || v.includes(st.problem_style),
      max_study_hours: (v) => st.study_hours <= v, min_study_hours: (v) => st.study_hours >= v };
    return Object.keys(chk).every((k) => !(k in c) || chk[k](c[k]));
  }
  function followUp(st) {
    if (!st.goals.trim()) return "What kind of work would you like to be doing in five years? A sentence is enough.";
    if (!Object.keys(st.skills).length) return "Have you tried any programming, design or other tools yet? Even a small attempt helps me adjust the roadmap.";
    if (st.study_hours < 5) return "You have limited weekly time. Would a slower plan with one skill at a time suit you?";
    if (st.interests.length < 2) return "Is there a second area you are curious about? Careers often combine two interests.";
    return null;
  }
  function runAgent(assessment, completedSkills) {
    const stages = [], t0 = performance.now(); let t = performance.now();
    const stage = (name, detail) => { stages.push({ name, detail, ms: r1(performance.now() - t) }); t = performance.now(); };
    const st = perceive(assessment, completedSkills), fired = [], boosts = {}, notes = [];
    D.agent_rules.forEach((rule) => { if (ruleMatches(rule.if, st)) { fired.push({ id: rule.id, name: rule.name, explanation: rule.explanation, considers: (rule.then.consider || []).map(label) });
      (rule.then.consider || []).forEach((c) => (boosts[c] = (boosts[c] || 0) + (rule.then.boost || 0))); if (rule.then.note) notes.push(rule.then.note); } });
    stage("Analysing interests", `${st.interests.length} interests and ${st.subjects.length} subjects read; ${fired.length} of ${D.agent_rules.length} rules fired.`);
    const ranked = rank(st, boosts), known = Object.entries(st.skills).filter(([, l]) => l >= 1).map(([s]) => s);
    stage("Matching existing skills", `${known.length} known skills compared against ${ranked.length} careers.`);
    const cand = new Set(); st.interests.forEach((i) => careersForInterest(i).forEach((c) => cand.add(c)));
    const topIds = ranked.slice(0, 3).map((r) => r.career_id), also = []; topIds.forEach((c) => relatedCareers(c).forEach((x) => { if (!topIds.includes(x) && !also.includes(x)) also.push(x); }));
    stage("Exploring the career knowledge graph", `${cand.size} careers reachable from your interests; ${also.length} related careers found.`);
    ranked.slice(0, 3).forEach((r) => { const plan = buildRoadmap(r.career_id, new Set(known), st.study_hours); r.estimated_hours = plan.total_hours; r.estimated_weeks = plan.total_weeks; r.search = { expanded: plan.search.states_expanded, cost: plan.search.path_cost_hours }; });
    stage("Evaluating possible learning paths", "A* search ran for the top 3 careers: " + ranked.slice(0, 3).map((r) => `${r.career_name} ≈ ${r.estimated_hours} h`).join(", ") + ".");
    const q = followUp(st), actions = [{ type: "recommend", careers: topIds }]; if (q) actions.push({ type: "ask_followup", question: q }); actions.push({ type: "update_roadmap", career_id: topIds[0] });
    stage("Preparing personalized recommendations", `${actions.length} agent actions chosen.`);
    return { state: st, rules_fired: fired, notes, recommendations: ranked, top3: ranked.slice(0, 3), explore_also: also.map((c) => ({ id: c, name: label(c) })), actions, follow_up: q, stages, pipeline: PIPELINE, total_ms: r1(performance.now() - t0),
      model: { available: !!NB, meta: NB ? NB.meta : null }, disclaimer: "Match scores are indicative recommendations from a small demonstration knowledge base, not scientifically validated probabilities of career success." };
  }

  /* ---------------- RAG: TF-IDF retrieval over local documents ---------------- */
  const STOP = new Set(("a about above after again against all am an and any are as at be because been before being below between both but by can did do does doing down during each few for from further had has have having he her here hers him his how i if in into is it its just me more most my no nor not now of off on once only or other our out over own same she should so some such than that the their them then there these they this those through to too under until up very was we were what when where which while who whom why will with would you your also may might could shall").split(" "));
  let RAG = null;
  function tokens(text) { const w = (String(text).toLowerCase().match(/\b\w\w+\b/g) || []).filter((x) => !STOP.has(x)), out = [...w]; for (let i = 0; i < w.length - 1; i++) out.push(w[i] + " " + w[i + 1]); return out; }
  function splitSentences(t) { return t.split(/(?<=[.!?])\s+/).map((s) => s.trim()).filter(Boolean); }
  function chunkText(text, max) { const chunks = []; let cur = ""; splitSentences(text).forEach((s) => { if (cur && cur.length + s.length + 1 > max) { chunks.push(cur); cur = s; } else cur = (cur + " " + s).trim(); }); if (cur) chunks.push(cur); return chunks; }
  function buildDocs() {
    const docs = [];
    D.careers.forEach((c) => docs.push({ id: "career_" + c.id, title: "Career: " + c.name, text: `${c.summary} Required skills for ${c.name}: ${c.required_skills.map((s) => SK[s].name).join(", ")}. Prerequisites: ${c.prerequisites} Beginner projects: ${c.beginner_projects.join("; ")}. Next steps: ${c.next_steps.join("; ")}.` }));
    D.skills.forEach((s) => { const pre = s.prerequisites.map((p) => SK[p].name).join(", ") || "none", users = D.careers.filter((c) => c.required_skills.includes(s.id)).map((c) => c.name).join(", ") || "no career in the demo data", res = resForSkill(s.id).map((r) => r.title).join(", ") || "none listed";
      docs.push({ id: "skill_" + s.id, title: "Skill: " + s.name, text: `${s.name}: ${s.description} Prerequisites: ${pre}. Estimated effort: about ${s.effort_hours} hours. Needed for: ${users}. Learning resources: ${res}.` }); });
    D.learning_resources.forEach((r) => docs.push({ id: "res_" + r.id, title: "Resource: " + r.title, text: `${r.title} is a ${r.level} ${r.type}. ${r.description} Covers: ${r.covers.filter((s) => SK[s]).map((s) => SK[s].name).join(", ")}. Website: ${r.url}` }));
    (D.knowledge_base.documents || []).forEach((d) => docs.push(d)); return docs;
  }
  function vec(text, idf) { const tf = new Map(); tokens(text).forEach((t) => { if (idf.has(t)) tf.set(t, (tf.get(t) || 0) + 1); }); const v = new Map(); let n = 0; tf.forEach((c, t) => { const w = (1 + Math.log(c)) * idf.get(t); v.set(t, w); n += w * w; }); n = Math.sqrt(n) || 1; v.forEach((w, t) => v.set(t, w / n)); return v; }
  const dot = (a, b) => { if (a.size > b.size) [a, b] = [b, a]; let s = 0; a.forEach((w, t) => { const x = b.get(t); if (x) s += w * x; }); return s; };
  function buildRAG() {
    const chunks = []; buildDocs().forEach((d) => chunkText(d.text, 350).forEach((p, i) => chunks.push({ doc_id: d.id, title: d.title, chunk_id: `${d.id}#${i}`, text: p })));
    const df = new Map(); const toks = chunks.map((c) => tokens(`${c.title}. ${c.text}`)); toks.forEach((t) => new Set(t).forEach((x) => df.set(x, (df.get(x) || 0) + 1)));
    const n = chunks.length, idf = new Map(); df.forEach((d, t) => idf.set(t, Math.log((1 + n) / (1 + d)) + 1));
    RAG = { chunks, idf, vecs: chunks.map((c) => vec(`${c.title}. ${c.text}`, idf)) };
  }
  function ragQuery(question, topK = 3, minScore = 0.10) {
    const q = vec(question, RAG.idf), scores = RAG.vecs.map((v) => dot(v, q));
    const hits = scores.map((s, i) => [s, i]).sort((a, b) => b[0] - a[0] || a[1] - b[1]).slice(0, topK).filter(([s]) => s >= minScore).map(([s, i]) => ({ ...RAG.chunks[i], score: r3(s) }));
    const settings = { top_k: topK, min_score: minScore, chunk_chars: 350, method: "TF-IDF (1-2 grams) + cosine similarity, computed in the browser", total_chunks: RAG.chunks.length };
    if (!hits.length) return { found: false, mode: "none", answer: "No sufficiently relevant source was found in the knowledge base for this question, so I will not guess. Try mentioning a career, skill or learning topic.", sources: [], chunks: [], settings };
    const cand = []; hits.forEach((h) => splitSentences(h.text).forEach((s) => cand.push([dot(vec(s, RAG.idf), q), s])));
    const best = cand.sort((a, b) => b[0] - a[0]).slice(0, 3).filter((c) => c[0] > 0).map((c) => c[1]);
    return { found: true, mode: "extractive", answer: [...new Set(best.length ? best : [hits[0].text])].join(" "), sources: [...new Set(hits.map((h) => h.title))], chunks: hits, settings, mode_note: "Extractive answer (retrieval + sentence selection). No generative LLM was used." };
  }

  /* ---------------- offline assistant ---------------- */
  const ALIASES = { ai_ml_engineer: ["ai/ml", "ml engineer", "machine learning", "ai engineer", "artificial intelligence", "data scientist"], software_developer: ["software developer", "software engineer", "programmer", "developer"],
    data_analyst: ["data analyst", "data analysis", "analytics"], cybersecurity_analyst: ["cybersecurity", "cyber security", "security analyst", "hacker", "infosec"], ui_ux_designer: ["ui/ux", "ux designer", "ui designer", "ux", "designer"],
    cloud_engineer: ["cloud engineer", "cloud", "devops"], web_developer: ["web developer", "web development", "frontend", "front-end", "website"], business_analyst: ["business analyst", "business analysis"],
    digital_marketer: ["digital marketer", "digital marketing", "marketer", "marketing", "seo"], robotics_engineer: ["robotics", "robot"] };
  const PROMPTS = ["Why was my top career recommended?", "What skills am I missing?", "Compare my top two careers", "Where can I learn Python?", "What should I do this week?"];
  const esc = (s) => s.replace(/[.*+?^${}()|[\]\\\/]/g, "\\$&");
  function findCareers(text) { const low = text.toLowerCase(), found = [];
    D.careers.forEach((c) => { const pos = [c.name.toLowerCase(), ...(ALIASES[c.id] || [])].filter((n) => new RegExp("(^|\\W)" + esc(n) + "(?=\\W|$)").test(low)).map((n) => low.indexOf(n)).filter((p) => p >= 0); if (pos.length) found.push([Math.min(...pos), c.id]); });
    return found.sort((a, b) => a[0] - b[0]).map((x) => x[1]); }
  function findSkills(text) { const low = text.toLowerCase();
    return D.skills.filter((s) => low.includes(s.name.toLowerCase()) || low.includes(s.id.replace(/_/g, " ")) || (s.id === "python_basics" && low.includes("python")) || (s.id === "sql" && /\bsql\b/.test(low)) || (s.id === "html_css" && /\bhtml\b|\bcss\b/.test(low)) || (s.id === "javascript" && low.includes("javascript"))).map((s) => s.id); }
  const resText = (ids) => ids.map((id) => { const r = resForSkill(id).slice(0, 2); return `${SK[id].name}: ` + (r.length ? r.map((x) => `${x.title} (${x.url})`).join(", ") : "no resource is listed in my knowledge base yet."); }).join("\n");
  function offlineReply(msg, ctx, rag) {
    const low = msg.toLowerCase(), careers = findCareers(msg), skills = findSkills(msg), top = ctx ? ctx.top3 : [];
    if (/\b(hi|hello|hey|namaste)\b/.test(low) && low.length < 30) return { reply: "Hi! I'm your PathFinder career companion. " + (ctx ? "I can explain your recommendations, compare careers, list missing skills or suggest resources." : "Take the quick assessment first and I'll be able to personalise my answers."), sources: [], follow_up: ctx ? null : "Would you like to start the assessment now?" };
    if (/compare|\bvs\b|versus|difference/.test(low)) { const ids = careers.length ? careers.slice(0, 2) : top.slice(0, 2).map((r) => r.career_id);
      if (ids.length === 2) { const [a, b] = ids.map((i) => CR[i]), sa = new Set(a.required_skills), sb = new Set(b.required_skills), nm = (arr) => arr.map((s) => SK[s].name).join(", ") || "none";
        return { reply: `${a.name}: ${a.summary}\n${b.name}: ${b.summary}\nShared skills: ${nm(a.required_skills.filter((s) => sb.has(s)))}.\nOnly ${a.name}: ${nm(a.required_skills.filter((s) => !sb.has(s)))}.\nOnly ${b.name}: ${nm(b.required_skills.filter((s) => !sa.has(s)))}.`, sources: [`Career: ${a.name}`, `Career: ${b.name}`], follow_up: "Which of the two feels closer to what you enjoy?" }; }
      return { reply: 'Tell me two careers to compare, for example "Data Analyst vs Web Developer".', sources: [], follow_up: null }; }
    if (/missing|gap|what.*(skills|need)|need to learn/.test(low) && (top.length || careers.length)) {
      const rec = top.find((r) => careers.includes(r.career_id)) || top[0];
      if (rec) { const names = rec.missing_skills.map((m) => m.name); return { reply: `For ${rec.career_name} you still need: ${names.length ? names.join(", ") : "nothing from the core list - build a project next!"}.`, sources: [`Career: ${rec.career_name}`], follow_up: null }; }
      const c = CR[careers[0]]; return { reply: `Core skills for ${c.name}: ` + c.required_skills.map((s) => SK[s].name).join(", ") + ".", sources: [`Career: ${c.name}`], follow_up: "Take the assessment to see which of these you already have." }; }
    if (/why|explain|reason/.test(low) && top.length) { const rec = top.find((r) => careers.includes(r.career_id)) || top[0];
      return { reply: `${rec.career_name} scored ${rec.score} (${rec.band}). ` + rec.reasons.join(" ") + " Remember: the score is indicative, not a prediction of success.", sources: [`Career: ${rec.career_name}`], follow_up: null }; }
    if (/resource|course|learn|study|tutorial|where/.test(low) && (skills.length || careers.length || top.length)) { let ids = skills.slice(0, 3);
      if (!ids.length) { const c = careers.length ? careers[0] : top[0].career_id, rec = top.find((r) => r.career_id === c); ids = rec ? rec.missing_skills.slice(0, 3).map((m) => m.id) : CR[c].required_skills.slice(0, 3); }
      return { reply: "Here is what my knowledge base lists:\n" + resText(ids), sources: ["Learning resources"], follow_up: null }; }
    if (/week|next step|start|roadmap|plan/.test(low) && top.length) { const rec = top[0], ready = rec.missing_skills.filter((m) => m.ready_to_start).slice(0, 2).map((m) => m.name);
      return { reply: `With about ${ctx.state.study_hours} hours a week, start with ${ready.join(" and then ") || "a small portfolio project"} for ${rec.career_name}. Open the Roadmap page to tick off milestones.`, sources: [], follow_up: "Is that amount of time realistic for you?" }; }
    if (rag && rag.found) return { reply: rag.answer, sources: rag.sources, follow_up: null };
    return { reply: "I could not find that in my knowledge base, so I won't guess. I can help with careers, skills, prerequisites, roadmaps and learning resources.", sources: [], follow_up: "Which career or skill would you like to know about?" };
  }

  /* ---------------- neural-network demo (real forward pass + training in the browser) ---------------- */
  const NN_IN = ["Maths", "Programming", "Design", "Security", "Business", "Hands-on"], NN_OUT = ["Data / AI", "Software / Web", "Security / Cloud", "Design / Business"];
  let NET = null;
  function trainNet() {
    const rand = rng(7), centers = [[.9, .8, .1, .2, .3, .2], [.5, .9, .4, .2, .2, .3], [.4, .6, .1, .9, .2, .6], [.2, .2, .9, .1, .8, .2]], X = [], y = [];
    centers.forEach((c, k) => { for (let i = 0; i < 40; i++) { X.push(c.map((v) => Math.min(1, Math.max(0, v + 0.15 * normal(rand))))); y.push(k); } });
    const rr = rng(3);
    let W1 = Array.from({ length: 6 }, () => Array.from({ length: 5 }, () => 0.5 * normal(rr))), b1 = new Array(5).fill(0), W2 = Array.from({ length: 5 }, () => Array.from({ length: 4 }, () => 0.5 * normal(rr))), b2 = new Array(4).fill(0);
    const fwd = (x) => { const hp = b1.map((b, j) => b + sum(x.map((v, i) => v * W1[i][j]))), h = hp.map((v) => Math.max(0, v)), z = b2.map((b, k) => b + sum(h.map((v, j) => v * W2[j][k]))), m = Math.max(...z), e = z.map((v) => Math.exp(v - m)), s = sum(e); return { hp, h, p: e.map((v) => v / s) }; };
    const losses = [], N = X.length, lr = 0.1;
    for (let ep = 0; ep < 400; ep++) {
      const gW1 = W1.map((r) => r.map(() => 0)), gb1 = new Array(5).fill(0), gW2 = W2.map((r) => r.map(() => 0)), gb2 = new Array(4).fill(0); let loss = 0;
      X.forEach((x, n) => { const { hp, h, p } = fwd(x); loss -= Math.log(p[y[n]] + 1e-9); const d2 = p.map((v, k) => (v - (k === y[n] ? 1 : 0)) / N);
        h.forEach((hv, j) => d2.forEach((d, k) => (gW2[j][k] += hv * d))); d2.forEach((d, k) => (gb2[k] += d));
        const d1 = h.map((_, j) => (hp[j] > 0 ? sum(d2.map((d, k) => d * W2[j][k])) : 0)); x.forEach((xv, i) => d1.forEach((d, j) => (gW1[i][j] += xv * d))); d1.forEach((d, j) => (gb1[j] += d)); });
      W1 = W1.map((r, i) => r.map((v, j) => v - lr * gW1[i][j])); b1 = b1.map((v, j) => v - lr * gb1[j]); W2 = W2.map((r, j) => r.map((v, k) => v - lr * gW2[j][k])); b2 = b2.map((v, k) => v - lr * gb2[k]);
      if (ep % 20 === 0) losses.push(r3(loss / N));
    }
    const acc = X.filter((x, n) => { const p = fwd(x).p; return p.indexOf(Math.max(...p)) === y[n]; }).length / N;
    return { fwd, losses, acc: r3(acc), epochs: 400 };
  }
  function neural(vals) {
    if (!NET) NET = trainNet(); const { hp, h, p } = NET.fwd(vals);
    return { inputs: Object.fromEntries(NN_IN.map((n, i) => [n, r2(vals[i])])), hidden_pre_activation: hp.map(r3), hidden_after_relu: h.map(r3), output_scores: Object.fromEntries(NN_OUT.map((n, i) => [n, r3(p[i])])),
      predicted_family: NN_OUT[p.indexOf(Math.max(...p))], loss_curve: NET.losses, train_accuracy: NET.acc, epochs: NET.epochs, architecture: "6 inputs -> 5 hidden units (ReLU) -> 4 outputs (softmax)",
      disclaimer: "Educational demo trained on 160 synthetic points. Separate from the main recommendation engine; softmax outputs are not real-world probabilities." };
  }

  /* ---------------- validation ---------------- */
  function validateAssessment(p) {
    const e = {};
    if (!p || typeof p !== "object" || Array.isArray(p)) return [null, { body: "Expected a JSON object." }];
    const iv = VOC.interests, int = (v) => Number.isInteger(v);
    if (!Array.isArray(p.interests) || p.interests.length < 1 || p.interests.length > 10) e.interests = "Choose between 1 and 10 interests."; else if (p.interests.some((i) => !(i in iv))) e.interests = "Unknown interest value.";
    const raw = p.skills === undefined ? {} : p.skills, cs = {};
    if (!raw || typeof raw !== "object" || Array.isArray(raw) || Object.keys(raw).length > 40) e.skills = "Skills must be an object of skill_id -> level (1-3).";
    else for (const [sid, l] of Object.entries(raw)) { if (!SK[sid] || !int(l) || l < 1 || l > 3) { e.skills = "Invalid skill entry: " + clean(sid, 40); break; } cs[sid] = l; }
    const sub = p.subjects === undefined ? [] : p.subjects; if (!Array.isArray(sub) || sub.length > 6 || sub.some((s) => !(s in VOC.subjects))) e.subjects = "Choose up to 6 valid subjects.";
    [["work_style", "work_styles"], ["problem_style", "problem_styles"], ["education", "education_levels"], ["learning_format", "learning_formats"]].forEach(([f, k]) => { if (!(p[f] in VOC[k])) e[f] = `Please choose a valid ${f.replace("_", " ")}.`; });
    if (!int(p.study_hours) || p.study_hours < 1 || p.study_hours > 60) e.study_hours = "Study hours per week must be a whole number from 1 to 60.";
    const goals = p.goals === undefined ? "" : p.goals; if (typeof goals !== "string" || goals.length > 300) e.goals = "Career goals must be text of at most 300 characters.";
    if (Object.keys(e).length) return [null, e];
    return [{ interests: p.interests, skills: cs, subjects: sub, work_style: p.work_style, problem_style: p.problem_style, goals: clean(goals, 300), study_hours: p.study_hours, education: p.education, learning_format: p.learning_format }, {}];
  }

  /* ---------------- router (mirrors app.py) ---------------- */
  function agentForSession() { const a = latestAssessment(); if (!a) return [null, "none"]; return [runAgent(a.data, [...completed()].filter((s) => SK[s])), null]; }
  function careerDetail(cid) {
    const c = CR[cid], seen = new Set(), resources = [];
    c.required_skills.forEach((s) => resForSkill(s).forEach((r) => { if (!seen.has(r.id)) { seen.add(r.id); resources.push({ title: r.title, url: r.url, type: r.type, level: r.level }); } }));
    return { ...c, required_skill_details: c.required_skills.map((s) => ({ id: s, name: SK[s].name, effort_hours: SK[s].effort_hours })), resources: resources.slice(0, 8), related: relatedCareers(cid).map((r) => ({ id: r, name: label(r) })) };
  }
  function roadmapResponse(cid) {
    const a = latestAssessment(), known = new Set(Object.entries(a ? a.data.skills : {}).filter(([, l]) => l >= 1).map(([s]) => s)), hours = a ? a.data.study_hours : 5;
    const plan = buildRoadmap(cid, known, hours, completed(cid)); plan.progress = progressSummary(plan); plan.weekly_plan = weeklyPlan(plan); plan.saved = getDB().saved.includes(cid); plan.has_assessment = !!a; return plan;
  }
  function route(method, url, body) {
    const path = url.pathname.replace(/\/+$/, "") || "/", q = url.searchParams, b = body && typeof body === "object" && !Array.isArray(body) ? body : null, bo = b || {};
    const is = (m, p) => method === m && path === p;
    if (is("GET", "/api/health")) return { status: "ok", data_problems: [], careers: D.careers.length, skills: D.skills.length, ml_model_loaded: !!NB, llm_configured: false, rag_chunks: RAG.chunks.length, mode: "standalone (runs in the browser)" };
    if (is("GET", "/api/options")) return { ...VOC, skills: D.skills.map((s) => ({ id: s.id, name: s.name, category: s.category })) };
    if (is("GET", "/api/demo")) return D.sample_assessment;
    if (is("GET", "/api/careers")) { const qq = (q.get("q") || "").trim().toLowerCase().slice(0, 60), cat = (q.get("category") || "").trim();
      const list = D.careers.filter((c) => { const hay = [c.name, c.summary, c.category, ...c.required_skills.map((s) => SK[s].name)].join(" ").toLowerCase(); return (!qq || hay.includes(qq)) && (!cat || c.category === cat); })
        .map((c) => ({ id: c.id, name: c.name, category: c.category, summary: c.summary, required_skills: c.required_skills.map((s) => SK[s].name) }));
      return { careers: list, categories: sorted([...new Set(D.careers.map((c) => c.category))]), count: list.length }; }
    let m = path.match(/^\/api\/careers\/([^/]+)$/); if (method === "GET" && m) { if (!CR[m[1]]) fail("Career not found.", 404); return careerDetail(m[1]); }
    if (is("POST", "/api/assessment")) { const [clean_, errs] = validateAssessment(b); if (Object.keys(errs).length) fail("Validation failed.", 400, errs);
      const db = getDB(), id = db.nextId++; db.assessments.push({ id, data: clean_ }); db.assessments = db.assessments.slice(-20); setDB(db); return { __status: 201, assessment_id: id, message: "Assessment saved." }; }
    if (is("GET", "/api/assessment/latest")) { const a = latestAssessment(); if (!a) fail("No assessment found.", 404); return { assessment_id: a.id, assessment: a.data }; }
    if (is("POST", "/api/recommend")) { let res;
      if (bo.assessment) { const [c, errs] = validateAssessment(bo.assessment); if (Object.keys(errs).length) fail("Validation failed.", 400, errs); res = runAgent(c); }
      else { const [r, e] = agentForSession(); if (e) fail("No assessment found. Please complete the assessment first.", 404); res = r; }
      const saved = new Set(getDB().saved); res.recommendations.forEach((r) => (r.saved = saved.has(r.career_id))); return res; }
    if (is("POST", "/api/search-path")) { const cid = bo.career_id; if (!CR[cid]) fail("Unknown career_id.", 400); const algo = bo.algorithm || "both"; if (!["bfs", "astar", "both"].includes(algo)) fail("algorithm must be bfs, astar or both.", 400);
      const a = latestAssessment(); let known = new Set(Object.entries(a ? a.data.skills : {}).filter(([, l]) => l >= 1).map(([s]) => s)); completed().forEach((s) => SK[s] && known.add(s));
      if (Array.isArray(bo.known_skills)) known = new Set(bo.known_skills.filter((s) => SK[s]));
      const target = bo.target || "capstone", rs = CR[cid].required_skills; let goal;
      if (target === "career") goal = rs; else if (target === "capstone") goal = [rs[rs.length - 1] !== "git_version_control" ? rs[rs.length - 1] : rs[rs.length - 2]]; else if (SK[target]) goal = [target]; else fail("target must be capstone, career or a valid skill id.", 400);
      const sp = makeSpace(goal, known), gnodes = new Set([...sp.needed]); sp.needed.forEach((n) => SK[n].prerequisites.forEach((p) => gnodes.add(p)));
      const out = { career_id: cid, goal: goal.map((s) => ({ id: s, name: SK[s].name })), known: sorted([...known].filter((s) => sp.needed.has(s) || goal.includes(s))), needed: sp.neededSorted,
        graph: { nodes: sorted(gnodes).map((s) => ({ id: s, label: SK[s].name, known: known.has(s) })), edges: sp.neededSorted.flatMap((n) => SK[n].prerequisites.map((p) => ({ source: p, target: n }))) },
        heuristic: "h(n) = 0.8 x estimated hours of the skills still missing. It never over-estimates, so A* stays optimal. Limitation: effort hours are rough estimates and every missing skill is assumed necessary." };
      if (goal.every((g) => known.has(g))) out.message = "You already know every skill needed for this goal.";
      if (algo !== "astar") out.bfs = bfs(sp); if (algo !== "bfs") out.astar = astar(sp); return out; }
    if (is("GET", "/api/knowledge-graph")) { const f = q.get("career"); if (f && !CR[f]) fail("Unknown career.", 404); return toGraph(f); }
    m = path.match(/^\/api\/knowledge-graph\/node\/([^/]+)$/); if (method === "GET" && m) { const info = nodeInfo(decodeURIComponent(m[1])); if (!info) fail("Node not found.", 404); return info; }
    if (is("GET", "/api/knowledge-graph/query")) { const r = kgQuery(q.get("subject"), q.get("relation"), q.get("object")); return { count: r.length, triples: r.slice(0, 100) }; }
    if (is("POST", "/api/chat")) { const msg = bo.message; if (typeof msg !== "string" || !msg.trim()) fail("message is required.", 400); if (msg.length > 500) fail("message is too long (max 500 characters).", 400);
      const [ctx] = agentForSession(), rag = ragQuery(msg), out = offlineReply(clean(msg, 500), ctx, rag); out.mode = "offline"; out.has_context = !!ctx; out.prompts = PROMPTS; return out; }
    if (is("GET", "/api/chat/prompts")) return { prompts: PROMPTS, llm_configured: false, design: ["Role: supportive career-learning guide (not a recruiter or fortune teller).", "Grounding: answers must use the student's assessment plus retrieved knowledge-base facts.",
      "Safety: never guarantees jobs or salaries and never invents courses, certificates or links.", "Honesty: says so when the knowledge base has no information.", "Structure: JSON output (career_name, reasons, matched_skills, missing_skills, next_steps, confidence_notes) is validated before display.",
      "Security: API key only on the server; user text is treated as data, escaped in the browser; the system prompt is never exposed. (This Netlify build runs the offline assistant only.)"] };
    if (is("POST", "/api/rag/query")) { const qs = bo.question; if (typeof qs !== "string" || !qs.trim()) fail("question is required.", 400); if (qs.length > 300) fail("question is too long (max 300 characters).", 400);
      const k = bo.top_k, ms = bo.min_score; if (k !== undefined && k !== null && (!Number.isInteger(k) || k < 1 || k > 8)) fail("top_k must be an integer from 1 to 8.", 400);
      if (ms !== undefined && ms !== null && (typeof ms !== "number" || ms < 0 || ms > 1)) fail("min_score must be a number from 0 to 1.", 400); return ragQuery(clean(qs, 300), k || 3, ms === undefined || ms === null ? 0.10 : ms); }
    if (method === "GET" && path === "/api/saved") return { saved: getDB().saved.map((c) => ({ career_id: c, name: label(c) })) };
    if (is("POST", "/api/saved")) { const cid = bo.career_id, act = bo.action || "save"; if (!CR[cid] || !["save", "remove"].includes(act)) fail("Provide a valid career_id and action (save/remove).", 400);
      const db = getDB(); db.saved = db.saved.filter((c) => c !== cid); if (act === "save") db.saved.push(cid); setDB(db); return { career_id: cid, saved: act === "save" }; }
    if (is("GET", "/api/compare")) { const a = q.get("a"), bb = q.get("b"); if (!CR[a] || !CR[bb] || a === bb) fail("Provide two different valid career ids as a and b.", 400);
      const sa = new Set(CR[a].required_skills), sb = new Set(CR[bb].required_skills), nm = (ids) => D.skills.filter((s) => ids.has(s.id)).map((s) => s.name), hrs = (s) => sum([...s].map((x) => SK[x].effort_hours));
      const out = { a: careerDetail(a), b: careerDetail(bb), shared_skills: nm(new Set([...sa].filter((s) => sb.has(s)))), only_a: nm(new Set([...sa].filter((s) => !sb.has(s)))), only_b: nm(new Set([...sb].filter((s) => !sa.has(s)))), hours_a: hrs(sa), hours_b: hrs(sb) };
      const [res] = agentForSession(); if (res) { const sc = Object.fromEntries(res.recommendations.map((r) => [r.career_id, r.score])); out.score_a = sc[a]; out.score_b = sc[bb]; } return out; }
    if (is("GET", "/api/roadmap")) { let cid = q.get("career_id"); if (!cid) { const [res, e] = agentForSession(); if (e) fail("No assessment found. Please complete the assessment first.", 404); cid = res.top3[0].career_id; } if (!CR[cid]) fail("Unknown career_id.", 404); return roadmapResponse(cid); }
    if (is("POST", "/api/roadmap/progress")) { const cid = bo.career_id, step = bo.skill_id, done = bo.done; if (!CR[cid] || typeof done !== "boolean") fail("career_id and boolean done are required.", 400); if (!SK[step] && step !== "portfolio_project") fail("Unknown skill_id.", 400);
      const db = getDB(); db.progress[cid] = db.progress[cid] || {}; db.progress[cid][step] = done; setDB(db); const plan = roadmapResponse(cid);
      return { progress: plan.progress, weekly_plan: plan.weekly_plan, message: "Progress saved. The agent will use this skill in your next recommendation." }; }
    if (is("GET", "/api/agent/rules")) return { rules: D.agent_rules };
    if (is("GET", "/api/ml/info")) return { available: !!NB, meta: NB ? NB.meta : null, formula: "score = 100 x (0.30 skill_overlap + 0.25 interest_match + 0.25 model_signal + 0.10 prereq_readiness + 0.10 rule_boost)", fallback: "If the model cannot load, model_signal is dropped and weights are re-balanced." };
    if (is("POST", "/api/ml/neural-demo")) { const v = bo.inputs; if (!(Array.isArray(v) && v.length === 6 && v.every((x) => typeof x === "number" && x >= 0 && x <= 1))) fail("inputs must be a list of 6 numbers between 0 and 1.", 400); return neural(v); }
    fail("Endpoint not found.", 404);
  }

  window.fetch = async function (input, init = {}) {
    const raw = typeof input === "string" ? input : input.url;
    if (!raw.startsWith("/api/")) return origFetch(input, init);
    const reply = (obj, status = 200) => new Response(JSON.stringify(obj), { status, headers: { "Content-Type": "application/json" } });
    try {
      await loadData();
      let body = null; if (init.body) { try { body = JSON.parse(init.body); } catch (e) { body = null; } }
      const out = route((init.method || "GET").toUpperCase(), new URL(raw, "http://local"), body);
      const status = out && out.__status ? out.__status : 200; if (out && out.__status) delete out.__status; return reply(out, status);
    } catch (e) {
      if (e && e.body) return reply(e.body, e.status);
      console.error("[local backend]", e); return reply({ error: "Internal error in the in-browser backend: " + (e && e.message ? e.message : e) }, 500);
    }
  };
  window.PF_LOCAL_BACKEND = true;
})();
