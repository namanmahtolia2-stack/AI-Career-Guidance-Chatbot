/* roadmap.js — ordered A* roadmap with checkboxes; progress is saved in SQLite via the API */
(async () => {
  const { $, $$, esc } = PF; const tl = $("#timeline"); let cid = null, plan = null;
  let careers;
  try { careers = (await PF.api("/api/careers")).careers; } catch (e) { PF.errorBox(tl, e.message, () => location.reload()); return; }
  const sel = $("#career-sel"); sel.innerHTML = careers.map((c) => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join("");
  cid = location.hash.slice(1) || null;
  if (!cid || !careers.some((c) => c.id === cid)) {
    try { cid = (await PF.api("/api/roadmap")).career_id; } catch (e) { cid = careers[0].id; if (e.status === 404) PF.tip($("#tips"), "rm-noassess", "Take the assessment to personalise this roadmap. Until then, it assumes you are starting from zero."); }
  }
  sel.value = cid; sel.onchange = () => { cid = sel.value; history.replaceState(null, "", "#" + cid); load(); };

  async function load() {
    PF.skeleton(tl, 4);
    try { plan = await PF.api("/api/roadmap?career_id=" + encodeURIComponent(cid)); draw(); }
    catch (e) { PF.errorBox(tl, e.message, load); }
  }

  function draw() {
    const p = plan.progress;
    $("#summary").innerHTML = `<div class="glass card"><div class="row" style="justify-content:space-between"><div><h2 style="margin:0">${esc(plan.career_name)}</h2>
      <span class="muted small">≈ ${plan.total_hours_range[0]}–${plan.total_hours_range[1]} hours · about ${plan.total_weeks} weeks at ${plan.hours_per_week} h/week</span></div>
      <button class="btn sm" id="save-rm">${plan.saved ? "★ Saved" : "☆ Save roadmap"}</button></div>
      <div class="row" style="margin-top:.8rem;flex-wrap:nowrap"><div class="bar" style="flex:1"><i id="pbar" style="width:${p.percent}%"></i></div><b id="ptxt">${p.percent}%</b></div>
      <div class="muted small" id="pdet">${p.done} of ${p.total} milestones complete${plan.already_known.length ? " · already known: " + esc(plan.already_known.join(", ")) : ""}</div></div>`;
    $("#save-rm").onclick = async (e) => { const on = e.target.textContent.includes("Saved"); try { await PF.api("/api/saved", { body: { career_id: cid, action: on ? "remove" : "save" } }); e.target.textContent = on ? "☆ Save roadmap" : "★ Saved"; PF.toast(on ? "Removed from saved" : "Roadmap saved", "success"); } catch (er) { PF.toast(er.message, "error"); } };
    let last = ""; let html = '<div class="tl">';
    plan.steps.forEach((s) => {
      if (s.milestone !== last) { html += `<div class="ms">${esc(s.milestone)}</div>`; last = s.milestone; }
      html += `<div class="tl-item glass card reveal ${s.done ? "done" : ""}" data-id="${esc(s.id)}"><div class="row" style="flex-wrap:nowrap;align-items:flex-start">
        <input type="checkbox" id="cb-${esc(s.id)}" ${s.done ? "checked" : ""} aria-label="Mark ${esc(s.name)} complete" data-step="${esc(s.id)}">
        <div style="flex:1"><label for="cb-${esc(s.id)}" class="tl-title" style="font-weight:600;cursor:pointer">${s.order}. ${esc(s.name)}</label>
        <div class="muted small">${esc(s.description)}</div>
        <div class="small" style="margin:.3rem 0">⏱ ${s.hours_range[0]}–${s.hours_range[1]} h (${s.weeks} weeks)${s.is_core ? "" : " · supporting prerequisite"}</div>
        ${s.prerequisites.length ? `<div class="chips">${s.prerequisites.map((q) => `<span class="chip static ${q.in_roadmap ? "miss" : "good"}" title="${q.in_roadmap ? "Comes earlier in this roadmap" : "You already know this"}">needs ${esc(q.name)}</span>`).join("")}</div>` : ""}
        ${s.resources.length ? `<div class="small" style="margin-top:.4rem">Resources: ${s.resources.map((r) => `<a href="${esc(r.url)}" target="_blank" rel="noopener noreferrer">${esc(r.title)}</a>`).join(" · ")}</div>` : ""}</div></div></div>`;
    });
    tl.innerHTML = html + "</div>"; PF.reveal(tl);
    $$("[data-step]", tl).forEach((cb) => (cb.onchange = () => toggle(cb)));
    drawWeekly(plan.weekly_plan);
    $("#algo").innerHTML = `<h3>How this order was found</h3><p class="small muted">${esc(plan.search.reasoning)}</p><p class="small muted">${esc(plan.note)}</p>`;
    PF.tip($("#tips"), "rm", "Tick a milestone when you finish it. Your progress is saved, and the agent uses completed skills in future recommendations.");
  }
  function drawWeekly(w) {
    $("#weekly").innerHTML = `<h3>This month's suggestions</h3>` + (w.length ? w.map((x) => `<div class="small"><b>Week ${x.week}</b><ul style="margin:.2rem 0 .6rem;padding-left:1.1rem">${x.items.map((i) => `<li>${esc(i.skill)} — ${i.hours} h</li>`).join("")}</ul></div>`).join("") : "<p class='muted small'>Everything is complete. Time for a portfolio showcase! 🎉</p>");
  }
  async function toggle(cb) {
    const done = cb.checked, row = cb.closest(".tl-item"); cb.disabled = true;
    try {
      const r = await PF.api("/api/roadmap/progress", { body: { career_id: cid, skill_id: cb.dataset.step, done } });
      row.classList.toggle("done", done); $("#pbar").style.width = r.progress.percent + "%"; $("#ptxt").textContent = r.progress.percent + "%";
      $("#pdet").textContent = `${r.progress.done} of ${r.progress.total} milestones complete`; drawWeekly(r.weekly_plan);
      PF.toast(done ? "Milestone completed — saved ✔" : "Milestone reopened", "success");
      if (r.progress.percent === 100) PF.toast("🎉 Roadmap complete!", "success", 5000);
    } catch (e) { cb.checked = !done; PF.toast(e.message, "error"); } finally { cb.disabled = false; }
  }
  load();
})();
