/* analysis.js — calls the real /api/recommend and reveals the stages the server actually executed */
(async () => {
  const { $, esc } = PF, box = $("#stages"), after = $("#after");
  const names = ["Analysing interests", "Matching existing skills", "Exploring the career knowledge graph", "Evaluating possible learning paths", "Preparing personalized recommendations"];
  box.innerHTML = names.map((n, i) => `<div class="stage ${i === 0 ? "run" : ""}" data-i="${i}"><span class="dot"></span><div><b>${n}</b><div class="muted small detail">Working…</div></div></div>`).join("");
  try {
    const r = await PF.api("/api/recommend", { body: {} });
    const rows = $(".stage", box) && Array.from(box.querySelectorAll(".stage"));
    for (let i = 0; i < r.stages.length; i++) {            // short stagger only so the stages are readable
      const s = r.stages[i], row = rows[i]; row.classList.remove("run"); row.classList.add("done");
      row.querySelector(".dot").textContent = "✓"; row.querySelector(".detail").textContent = `${s.detail} (${s.ms} ms on the server)`;
      if (rows[i + 1]) rows[i + 1].classList.add("run");
      await new Promise((ok) => setTimeout(ok, matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 160));
    }
    PF.session.set("pf_top", r.top3.map((x) => x.career_id));
    after.innerHTML = `<p>Finished in <b>${r.total_ms} ms</b>. Your top match: <b>${esc(r.top3[0].career_name)}</b>.</p><a class="btn primary" href="/dashboard">View my dashboard →</a>`;
    PF.toast("Analysis complete", "success");
  } catch (e) {
    box.innerHTML = ""; PF.errorBox(box, e.message + (e.status === 404 ? " — redirecting to the assessment…" : ""), e.status === 404 ? null : () => location.reload());
    if (e.status === 404) setTimeout(() => PF.go("/assessment"), 1800);
  }
})();
