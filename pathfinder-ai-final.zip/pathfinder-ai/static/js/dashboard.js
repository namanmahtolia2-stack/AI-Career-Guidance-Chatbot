/* dashboard.js — recommendations, compare, charts, BFS/A* visualisation and knowledge graph */
(() => {
  const { $, $$, esc } = PF;
  const top = $("#top3"); let data = null, picks = [];
  const bandCls = (b) => (b.startsWith("Strong") ? "strong" : b.startsWith("Good") ? "good" : "expl");
  const dlabels = { skill: "Skill overlap", interest: "Interest match", model: "ML signal", readiness: "Prereq readiness", rules: "Rule boost" };

  async function load() {
    PF.skeleton(top, 3);
    try {
      data = await PF.api("/api/recommend", { body: {} });
      render(); charts(); searchSetup(); PF.tip($("#tips"), "dash", "Click “Compare” on two cards, or click a node in the career graph to see how it connects.");
      if (data.follow_up) PF.toast("Companion question: " + data.follow_up, "info", 6000);
    } catch (e) {
      if (e.status === 404) PF.empty(top, `<p>No assessment found yet.</p><a class="btn primary" href="/assessment">Take the assessment</a>`);
      else PF.errorBox(top, e.message, load);
      $("#legend").classList.add("hidden"); return;
    }
  }

  function render() {
    top.innerHTML = data.top3.map((r, i) => `
      <article class="glass card hover reveal" data-id="${esc(r.career_id)}">
        <div class="row" style="justify-content:space-between;flex-wrap:nowrap"><div><span class="muted small">#${i + 1} · ${esc(r.category)}</span><h3 style="margin:.2rem 0">${esc(r.career_name)}</h3><span class="band ${bandCls(r.band)}">${esc(r.band)}</span></div>
        <div class="ring" style="--p:${r.score}" role="img" aria-label="Match score ${r.score} out of 100"><b>${Math.round(r.score)}</b></div></div>
        <p class="muted small">${esc(r.summary)}</p>
        <div class="small"><b>Matched interests</b></div><div class="chips" style="margin:.3rem 0 .6rem">${r.matched_interests.map((x) => `<span class="chip static good">${esc(x)}</span>`).join("") || '<span class="muted small">none yet</span>'}</div>
        <div class="small"><b>Matched skills</b></div><div class="chips" style="margin:.3rem 0 .6rem">${r.matched_skills.map((x) => `<span class="chip static good">${esc(x.name)}</span>`).join("") || '<span class="muted small">none yet — start with the basics</span>'}</div>
        <div class="small"><b>Missing skills & prerequisites</b></div><div class="chips" style="margin:.3rem 0 .6rem">${r.missing_skills.map((m) => `<span class="chip static miss" title="${m.ready_to_start ? "Ready to start" : "Needs: " + esc(m.missing_prerequisites.join(", "))}">${esc(m.name)}${m.ready_to_start ? "" : " 🔒"}</span>`).join("") || '<span class="muted small">none — you have all core skills!</span>'}</div>
        <p class="small muted">Estimated roadmap: ~<b>${r.estimated_hours} h</b> (≈ ${r.estimated_weeks} weeks at ${data.state.study_hours} h/week)</p>
        <ul class="small muted" style="padding-left:1.1rem;margin:.3rem 0">${r.reasons.slice(0, 3).map((x) => `<li>${esc(x)}</li>`).join("")}</ul>
        <div class="row" style="margin-top:.8rem"><a class="btn sm" href="/explorer#${esc(r.career_id)}">Explore</a><button class="btn sm" data-save="${esc(r.career_id)}">${r.saved ? "★ Saved" : "☆ Save"}</button>
        <label class="btn sm ghost" style="cursor:pointer"><input type="checkbox" data-cmp="${esc(r.career_id)}" style="accent-color:#8b5cf6"> Compare</label></div>
      </article>`).join("");
    PF.reveal(top);
    $$("[data-save]", top).forEach((b) => (b.onclick = async () => {
      const id = b.dataset.save, saved = b.textContent.includes("Saved");
      try { await PF.api("/api/saved", { body: { career_id: id, action: saved ? "remove" : "save" } }); b.textContent = saved ? "☆ Save" : "★ Saved"; PF.toast(saved ? "Removed from saved" : "Saved to your roadmaps", "success"); }
      catch (e) { PF.toast(e.message, "error"); }
    }));
    $$("[data-cmp]", top).forEach((c) => (c.onchange = () => {
      picks = picks.filter((x) => x !== c.dataset.cmp); if (c.checked) picks.push(c.dataset.cmp);
      if (picks.length > 2) { const old = picks.shift(); $(`[data-cmp="${old}"]`).checked = false; }
      if (picks.length === 2) compare(); else $("#compare-box").classList.add("hidden");
    }));
    const a = data.rules_fired, ex = data.explore_also;
    $("#agent-box").innerHTML = `<div class="glass card"><h3>🤖 What the agent did</h3>
      <p class="small muted">Perceive → update state → reason (rules + ranking + A*) → act. ${data.notes.map(esc).join(" ")}</p>
      ${a.length ? "<ul class='small'>" + a.map((r) => `<li><b>${esc(r.name)}:</b> ${esc(r.explanation)}</li>`).join("") + "</ul>" : "<p class='small muted'>No IF-THEN rule fired, so the ranking relied on skills, interests and the ML signal.</p>"}
      ${data.follow_up ? `<p class="small">❓ <b>Follow-up question:</b> ${esc(data.follow_up)}</p>` : ""}
      ${ex.length ? `<p class="small muted">Related careers worth a look: ${ex.map((x) => `<a href="/explorer#${esc(x.id)}">${esc(x.name)}</a>`).join(", ")}</p>` : ""}</div>`;
  }

  async function compare() {
    const box = $("#compare-box"); box.classList.remove("hidden"); PF.skeleton(box, 1);
    try {
      const c = await PF.api(`/api/compare?a=${picks[0]}&b=${picks[1]}`);
      box.innerHTML = `<h3>Compare careers</h3><table><tr><th></th><th>${esc(c.a.name)}</th><th>${esc(c.b.name)}</th></tr>
        <tr><th>Match score</th><td>${c.score_a ?? "—"}</td><td>${c.score_b ?? "—"}</td></tr><tr><th>Core skill hours</th><td>${c.hours_a} h</td><td>${c.hours_b} h</td></tr>
        <tr><th>Only needed here</th><td>${esc(c.only_a.join(", ") || "—")}</td><td>${esc(c.only_b.join(", ") || "—")}</td></tr></table>
        <p class="small"><b>Shared skills:</b> ${esc(c.shared_skills.join(", ") || "none")}</p><p class="muted small">Shared skills are a safe place to start while you decide.</p>`;
    } catch (e) { box.innerHTML = ""; PF.errorBox(box, e.message); }
  }

  function charts() {
    const note = $("#chart-note");
    const go = () => {
      if (!window.Chart) { note.textContent = "Charts need Chart.js from the internet (CDN). The scores above are still complete. See README to host Chart.js locally."; return; }
      const grid = { color: "rgba(255,255,255,.1)" }, tick = { color: "#9aa3c7" };
      const r0 = data.top3[0];
      new Chart($("#chart-radar"), { type: "radar", data: { labels: Object.values(dlabels), datasets: [{ label: r0.career_name, data: Object.keys(dlabels).map((k) => r0.components[k]), backgroundColor: "rgba(139,92,246,.3)", borderColor: "#22d3ee" }] },
        options: { scales: { r: { min: 0, max: 1, grid, angleLines: grid, pointLabels: { color: "#cdd3f5" }, ticks: { display: false } } }, plugins: { legend: { labels: { color: "#cdd3f5" } } } } });
      const top6 = data.recommendations.slice(0, 6);
      new Chart($("#chart-bars"), { type: "bar", data: { labels: top6.map((r) => r.career_name), datasets: [{ label: "Indicative match score", data: top6.map((r) => r.score), backgroundColor: "rgba(34,211,238,.6)" }] },
        options: { indexAxis: "y", scales: { x: { min: 0, max: 100, grid, ticks: tick }, y: { grid, ticks: tick } }, plugins: { legend: { labels: { color: "#cdd3f5" } } } } });
      note.textContent = "Radar = how the top career's score is built. Weights: skills 30%, interests 25%, ML signal 25%, prerequisite readiness 10%, rules 10%.";
    };
    if (window.Chart) go(); else addEventListener("load", go);
  }

  /* ---- BFS / A* ---- */
  let viz = null;
  function searchSetup() {
    const sel = $("#sp-career"); sel.innerHTML = data.recommendations.map((r) => `<option value="${esc(r.career_id)}">${esc(r.career_name)}</option>`).join("");
    $$("[data-algo]").forEach((b) => (b.onclick = () => runSearch(b.dataset.algo, b)));
  }
  async function runSearch(algo, btn) {
    const res = $("#sp-result"); $$("[data-algo]").forEach((b) => (b.disabled = true));
    try {
      const d = await PF.api("/api/search-path", { body: { career_id: $("#sp-career").value, algorithm: algo, target: $("#sp-target").value } });
      if (d.message) { res.textContent = d.message; return; }
      viz = CareerGraph.renderSearch($("#sp-graph"), d); const r = d[algo];
      res.innerHTML = `<b>Goal:</b> ${esc(d.goal.map((g) => g.name).join(", "))} · <b>${esc(r.algorithm)}</b>: ${r.found ? `${r.states_expanded} states expanded, ${r.path_length} steps, ${r.path_cost_hours} hours` : "no path within the safety limit"}<br><span class="muted small">${esc(r.reasoning)}</span><br><span class="muted small">${esc(d.heuristic)}</span>`;
      $("#sp-steps").innerHTML = r.found ? `<div class="flow">${r.path.map((p, i) => `${i ? '<span class="a">→</span>' : ""}<span class="n">${esc(p.name)} <span class="muted small">${p.cost}h</span></span>`).join("")}</div>` : "";
      await viz.play(r);
    } catch (e) { res.textContent = ""; PF.toast(e.message, "error"); } finally { $$("[data-algo]").forEach((b) => (b.disabled = false)); }
  }

  /* ---- knowledge graph ---- */
  async function knowledge() {
    const box = $("#kg"), info = $("#kg-info");
    try {
      const g = await PF.api("/api/knowledge-graph");
      CareerGraph.renderKnowledge(box, g, { onSelect: async (id) => {
        info.innerHTML = '<div class="skel" style="min-height:80px"></div>';
        try {
          const n = await PF.api("/api/knowledge-graph/node/" + encodeURIComponent(id));
          const rel = (list) => list.slice(0, 12).map((t) => `<li>${esc(t.text)}</li>`).join("") || "<li class='muted'>none</li>";
          info.innerHTML = `<h3>${esc(n.label)} <span class="band good">${esc(n.type)}</span></h3><p class="small muted">${esc(n.summary || "")}</p>${n.effort_hours ? `<p class="small">Estimated effort: ${n.effort_hours} h</p>` : ""}
            <b class="small">Outgoing facts</b><ul class="small">${rel(n.relations.outgoing)}</ul><b class="small">Incoming facts</b><ul class="small">${rel(n.relations.incoming)}</ul>
            ${n.type === "career" ? `<a class="btn sm" href="/explorer#${esc(n.id)}">Open career card</a>` : ""}`;
        } catch (e) { info.innerHTML = ""; PF.errorBox(info, e.message); }
      } });
    } catch (e) { PF.errorBox(box, e.message, knowledge); }
  }
  load(); knowledge();
})();
