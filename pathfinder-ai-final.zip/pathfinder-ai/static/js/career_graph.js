/* career_graph.js — SVG graphs: (1) force-directed knowledge graph, (2) layered search graph for BFS / A* */
window.CareerGraph = (() => {
  const NS = "http://www.w3.org/2000/svg";
  const el = (name, attrs = {}, parent) => { const e = document.createElementNS(NS, name); Object.entries(attrs).forEach(([k, v]) => e.setAttribute(k, v)); if (parent) parent.appendChild(e); return e; };
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const sleep = (ms) => new Promise((r) => setTimeout(r, reduce ? 0 : ms));

  /* simple Fruchterman-Reingold layout, computed once then drawn statically */
  function layout(nodes, edges, W, H) {
    const idx = {}; nodes.forEach((n, i) => { idx[n.id] = i; const a = (i / nodes.length) * 6.283; n.x = W / 2 + Math.cos(a) * W * 0.3; n.y = H / 2 + Math.sin(a) * H * 0.3; });
    const k = Math.sqrt((W * H) / nodes.length) * 0.75; let t = W / 8;
    for (let it = 0; it < 220; it++) {
      nodes.forEach((n) => { n.dx = 0; n.dy = 0; });
      for (let i = 0; i < nodes.length; i++) for (let j = i + 1; j < nodes.length; j++) {
        let dx = nodes[i].x - nodes[j].x, dy = nodes[i].y - nodes[j].y; const d = Math.max(Math.hypot(dx, dy), 0.5), f = (k * k) / d;
        dx = (dx / d) * f; dy = (dy / d) * f; nodes[i].dx += dx; nodes[i].dy += dy; nodes[j].dx -= dx; nodes[j].dy -= dy;
      }
      edges.forEach((e) => {
        const a = nodes[idx[e.source]], b = nodes[idx[e.target]]; if (!a || !b) return;
        const dx = a.x - b.x, dy = a.y - b.y, d = Math.max(Math.hypot(dx, dy), 0.5), f = (d * d) / k;
        a.dx -= (dx / d) * f; a.dy -= (dy / d) * f; b.dx += (dx / d) * f; b.dy += (dy / d) * f;
      });
      nodes.forEach((n) => {
        n.dx += (W / 2 - n.x) * 0.02; n.dy += (H / 2 - n.y) * 0.02;
        const d = Math.max(Math.hypot(n.dx, n.dy), 0.1); n.x += (n.dx / d) * Math.min(d, t); n.y += (n.dy / d) * Math.min(d, t);
        n.x = Math.min(W - 40, Math.max(40, n.x)); n.y = Math.min(H - 20, Math.max(20, n.y));
      });
      t *= 0.985;
    }
    return idx;
  }

  /* ---------- knowledge graph ---------- */
  function renderKnowledge(container, data, opts = {}) {
    const W = 960, H = 640, nodes = data.nodes.map((n) => ({ ...n })), edges = data.edges;
    const idx = layout(nodes, edges, W, H);
    container.innerHTML = "";
    const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Knowledge graph of careers, skills and interests" }, container);
    const gE = el("g", {}, svg), gN = el("g", {}, svg), lines = {}, groups = {};
    edges.forEach((e) => { const a = nodes[idx[e.source]], b = nodes[idx[e.target]]; if (!a || !b) return;
      lines[e.source + ">" + e.target] = el("line", { class: "gedge", x1: a.x, y1: a.y, x2: b.x, y2: b.y }, gE); });
    nodes.forEach((n) => {
      const g = el("g", { class: `gnode ${n.type}`, tabindex: 0, role: "button", "aria-label": n.label }, gN);
      el("circle", { cx: n.x, cy: n.y, r: n.type === "career" ? 11 : n.type === "interest" ? 8 : 6 }, g);
      const t = el("text", { x: n.x + 10, y: n.y + 3 }, g); t.textContent = n.label; groups[n.id] = g;
      g.addEventListener("click", () => select(n.id)); g.addEventListener("keydown", (e) => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); select(n.id); } });
    });
    function select(id) {
      Object.values(lines).forEach((l) => l.classList.remove("hl"));
      Object.values(groups).forEach((g) => { g.classList.remove("lit"); g.style.opacity = 0.35; });
      const near = new Set([id]);
      edges.forEach((e) => { if (e.source === id || e.target === id) { near.add(e.source); near.add(e.target); lines[e.source + ">" + e.target]?.classList.add("hl"); } });
      near.forEach((n) => { if (groups[n]) groups[n].style.opacity = 1; }); groups[id]?.classList.add("lit");
      opts.onSelect && opts.onSelect(id);
    }
    function reset() { Object.values(groups).forEach((g) => { g.style.opacity = 1; g.classList.remove("lit"); }); Object.values(lines).forEach((l) => l.classList.remove("hl")); }
    const legend = document.createElement("div"); legend.className = "legend";
    legend.innerHTML = '<span><i style="background:var(--purple)"></i>Career</span><span><i style="background:var(--blue)"></i>Skill</span><span><i style="background:var(--cyan)"></i>Interest</span><span>Click a node to see its relationships</span>';
    container.appendChild(legend);
    return { select, reset };
  }

  /* ---------- search visualisation (layered prerequisite graph) ---------- */
  function renderSearch(container, data) {
    const nodes = data.graph.nodes.map((n) => ({ ...n })), edges = data.graph.edges, byId = Object.fromEntries(nodes.map((n) => [n.id, n]));
    const pre = {}; nodes.forEach((n) => (pre[n.id] = [])); edges.forEach((e) => { if (pre[e.target]) pre[e.target].push(e.source); });
    const level = {}; const lv = (id) => (level[id] !== undefined ? level[id] : (level[id] = pre[id].length ? 1 + Math.max(...pre[id].map(lv)) : 0));
    nodes.forEach((n) => lv(n.id));
    const cols = {}; nodes.forEach((n) => (cols[level[n.id]] = cols[level[n.id]] || []).push(n));
    const maxL = Math.max(...Object.keys(cols).map(Number)), maxN = Math.max(...Object.values(cols).map((c) => c.length));
    const GX = 175, GY = 58, W = (maxL + 1) * GX + 60, H = maxN * GY + 50;
    Object.entries(cols).forEach(([l, arr]) => arr.forEach((n, i) => { n.x = 40 + l * GX; n.y = 30 + i * GY + (maxN - arr.length) * GY / 2; }));
    container.innerHTML = "";
    const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": "Learning path search graph" }, container);
    const gE = el("g", {}, svg), gN = el("g", {}, svg), lines = {}, groups = {};
    edges.forEach((e) => { const a = byId[e.source], b = byId[e.target]; if (a && b) lines[e.source + ">" + e.target] = el("line", { class: "gedge", x1: a.x + 6, y1: a.y, x2: b.x - 6, y2: b.y }, gE); });
    nodes.forEach((n) => {
      const g = el("g", { class: `gnode skill ${n.known ? "known" : ""}` }, gN);
      el("circle", { cx: n.x, cy: n.y, r: 8 }, g); const t = el("text", { x: n.x - 4, y: n.y - 12 }, g); t.textContent = n.label; groups[n.id] = g;
    });
    const legend = document.createElement("div"); legend.className = "legend";
    legend.innerHTML = '<span><i style="background:var(--good)"></i>Already known</span><span><i style="background:var(--blue)"></i>Still to learn</span><span><i style="background:var(--warn)"></i>Explored by the search</span><span><i style="background:var(--cyan)"></i>Chosen path</span>';
    container.appendChild(legend);
    function clear() { Object.values(groups).forEach((g) => g.classList.remove("lit", "path")); Object.values(lines).forEach((l) => l.classList.remove("hl")); }
    // light up nodes in the order the algorithm expanded them, then show the chosen path
    async function play(result, speed = 130) {
      clear();
      for (const step of result.explored) { if (step.action && groups[step.action]) { const g = groups[step.action]; g.classList.remove("lit"); void g.getBoundingClientRect(); g.classList.add("lit"); await sleep(speed); } }
      await sleep(300);
      result.path.forEach((p, i) => { const g = groups[p.skill]; if (g) { g.classList.remove("lit"); g.classList.add("path"); }
        const prev = result.path[i - 1]; (prev ? edges.filter((e) => e.source === prev.skill && e.target === p.skill) : []).forEach((e) => lines[e.source + ">" + e.target]?.classList.add("hl")); });
    }
    return { play, clear };
  }
  return { renderKnowledge, renderSearch };
})();
