/* chatbot.js — floating AI Career Companion (also embedded on /companion) */
(() => {
  const { $, esc } = PF;
  const KEY = "pf_chat_v1";
  const HINTS = {
    dashboard: "Want me to explain why your top career was recommended?",
    roadmap: "Stuck on a milestone? Ask me for learning resources.",
    explorer: "Need help comparing two careers? Just ask.",
    assessment: "Not sure what to pick? Choose what sounds fun — you can retake it anytime.",
  };

  function create(root, embedded) {
    root.innerHTML = `
      <div class="chat-head"><div><b>PathFinder Companion</b><div class="muted small" data-mode>Offline rule-based assistant</div></div>
        <button class="btn sm ghost" data-clear title="Clear conversation">Clear</button>${embedded ? "" : '<button class="btn sm ghost" data-min aria-label="Close chat">✕</button>'}</div>
      <div class="chat-log" role="log" aria-live="polite"></div>
      <div class="chat-sugg"></div>
      <form class="chat-form" autocomplete="off"><input type="text" maxlength="500" placeholder="Ask about careers, skills, resources…" aria-label="Message"><button class="btn primary sm" type="submit">Send</button></form>`;
    const log = $(".chat-log", root), sugg = $(".chat-sugg", root), input = $("input", root);
    let history = PF.session.get(KEY, []);
    let busy = false;
    const fmt = (t) => new Date(t).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    function add(role, content, sources, save = true) {
      const m = { role, content, time: Date.now(), sources: sources || [] };
      draw(m); if (save) { history.push(m); PF.session.set(KEY, history.slice(-40)); }
    }
    function draw(m) {
      const d = document.createElement("div"); d.className = `msg ${m.role === "user" ? "user" : "bot"}`;
      const p = document.createElement("span"); p.textContent = m.content; d.appendChild(p);   // textContent = safe against HTML injection
      if (m.sources && m.sources.length) { const s = document.createElement("div"); s.className = "src"; s.textContent = "Sources: " + m.sources.join(" · "); d.appendChild(s); }
      const t = document.createElement("time"); t.textContent = fmt(m.time); d.appendChild(t);
      log.appendChild(d); log.scrollTop = log.scrollHeight;
    }
    function typing(on) {
      let t = $(".typing-row", log);
      if (on && !t) { t = document.createElement("div"); t.className = "msg bot typing-row"; t.innerHTML = '<span class="typing"><span></span><span></span><span></span></span>'; log.appendChild(t); log.scrollTop = log.scrollHeight; }
      if (!on && t) t.remove();
    }
    function prompts(list) {
      sugg.innerHTML = ""; (list || []).slice(0, 4).forEach((p) => { const b = document.createElement("button"); b.type = "button"; b.className = "chip"; b.textContent = p; b.onclick = () => send(p); sugg.appendChild(b); });
    }
    async function send(text) {
      text = (text || "").trim(); if (!text || busy) return;
      busy = true; input.value = ""; add("user", text); typing(true);
      try {
        const r = await PF.api("/api/chat", { body: { message: text, history: history.slice(-7, -1).map(({ role, content }) => ({ role, content })) } });
        typing(false); add("bot", r.reply + (r.follow_up ? "\n\n❓ " + r.follow_up : ""), r.sources);
        $("[data-mode]", root).textContent = r.mode === "llm" ? "LLM-powered (API configured)" : "Offline rule-based assistant";
        prompts(r.prompts);
      } catch (e) { typing(false); add("bot", "Sorry, I couldn't answer: " + e.message, [], false); PF.toast(e.message, "error"); }
      busy = false; input.focus();
    }
    function welcome() {
      add("bot", "Hi! I'm your career companion 👋 I can explain your recommendations, compare careers, list missing skills and suggest learning resources from my knowledge base. I never guarantee jobs or salaries.", [], false);
    }
    history.forEach(draw);
    if (!history.length) { welcome(); history = []; }
    prompts(["Why was my top career recommended?", "What skills am I missing?", "Compare data analyst vs web developer", "Where can I learn Python?"]);
    $(".chat-form", root).onsubmit = (e) => { e.preventDefault(); send(input.value); };
    $("[data-clear]", root).onclick = () => { history = []; PF.session.set(KEY, []); log.innerHTML = ""; welcome(); PF.toast("Conversation cleared", "info"); };
    return { send, input };
  }

  document.addEventListener("DOMContentLoaded", () => {
    const embed = $("#chat-embed");
    if (embed) { embed.classList.add("glass", "chat-embed"); window.PFChat = create(embed, true); return; }

    const fab = document.createElement("button");
    fab.className = "chat-fab"; fab.setAttribute("aria-label", "Open AI career companion");
    fab.innerHTML = '<svg viewBox="0 0 48 48"><circle cx="24" cy="24" r="17" fill="none" stroke="#06102a" stroke-width="3"/><path d="M24 11l5 13-5 13-5-13z" fill="#06102a"/></svg>';
    const win = document.createElement("section"); win.className = "chat-win glass"; win.hidden = true; win.setAttribute("aria-label", "AI Career Companion");
    document.body.append(win, fab);
    let chat = null;
    const open = (prefill) => { win.hidden = false; if (!chat) chat = create(win, false); $("[data-min]", win).onclick = close; if (prefill) chat.send(prefill); else chat.input.focus(); bubble && bubble.remove(); };
    const close = () => { win.hidden = true; fab.focus(); };
    fab.onclick = () => (win.hidden ? open() : close());
    document.addEventListener("keydown", (e) => { if (e.key === "Escape" && !win.hidden) close(); });

    // one contextual pop-up per page per session (never repeated)
    let bubble = null; const page = document.body.dataset.page, hint = HINTS[page];
    if (hint && !PF.session.get("pf_hint_" + page)) {
      setTimeout(() => {
        if (!win.hidden) return; PF.session.set("pf_hint_" + page, 1);
        bubble = document.createElement("div"); bubble.className = "chat-bubble"; bubble.setAttribute("role", "status");
        bubble.innerHTML = `<button aria-label="Dismiss">✕</button><span>${esc(hint)}</span>`;
        bubble.querySelector("button").onclick = () => bubble.remove(); bubble.querySelector("span").onclick = () => open();
        document.body.appendChild(bubble); setTimeout(() => bubble && bubble.remove(), 12000);
      }, 7000);
    }
  });
})();
