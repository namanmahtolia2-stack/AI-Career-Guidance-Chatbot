param([int]$Port = 8000)
# Waits until the Flask server answers, then opens the browser (max 90 seconds).
for ($i = 0; $i -lt 90; $i++) {
  try {
    Invoke-WebRequest -Uri "http://localhost:$Port/api/health" -UseBasicParsing -TimeoutSec 2 | Out-Null
    Start-Process "http://localhost:$Port"
    break
  } catch { Start-Sleep -Seconds 1 }
}
