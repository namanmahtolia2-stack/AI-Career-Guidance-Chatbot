"""
app.py - Flask application for PathFinder AI.
Run:  python app.py      then open  http://127.0.0.1:5000
"""
import json
import os
import uuid

from flask import Flask, g, jsonify, render_template, request

try:                                    # .env is optional
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

from ai_engine import data_store as ds
from ai_engine import llm_service, neural_demo
from ai_engine.agent import CareerAgent
from ai_engine.knowledge_graph import KnowledgeGraph
from ai_engine.rag_pipeline import RAGPipeline
from ai_engine.roadmap import build_roadmap, progress_summary, weekly_plan
from ai_engine.search_algorithms import astar, bfs
from ai_engine.state_space import LearningSpace
from database.init_db import get_conn, init_db
from validators import validate_assessment

app = Flask(__name__)
app.config["SECRET_KEY"] = os.getenv("SECRET_KEY", "dev-only-change-me")
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024      # reject huge request bodies

init_db()
KG = KnowledgeGraph()
AGENT = CareerAgent()
RAG = RAGPipeline()
COOKIE = "pf_sid"


# ---------------------------------------------------------------- helpers
def error(message, status=400, details=None):
    body = {"error": message}
    if details:
        body["details"] = details
    return jsonify(body), status


def json_body():
    data = request.get_json(silent=True)
    return data if isinstance(data, dict) else None


@app.before_request
def identify_session():
    sid = request.cookies.get(COOKIE, "")
    g.new_cookie = not (len(sid) == 32 and sid.isalnum())
    g.sid = uuid.uuid4().hex if g.new_cookie else sid


@app.after_request
def set_cookie(resp):
    if g.get("new_cookie"):
        resp.set_cookie(COOKIE, g.sid, max_age=60 * 60 * 24 * 90, httponly=True, samesite="Lax")
    resp.headers["X-Content-Type-Options"] = "nosniff"
    return resp


def latest_assessment():
    with get_conn() as c:
        row = c.execute("SELECT id, data_json FROM assessments WHERE session_id=? ORDER BY id DESC LIMIT 1",
                        (g.sid,)).fetchone()
    return (row["id"], json.loads(row["data_json"])) if row else (None, None)


def completed_steps(career_id=None):
    with get_conn() as c:
        if career_id:
            rows = c.execute("SELECT step_id FROM roadmap_progress WHERE session_id=? AND career_id=? AND done=1",
                             (g.sid, career_id)).fetchall()
        else:
            rows = c.execute("SELECT DISTINCT step_id FROM roadmap_progress WHERE session_id=? AND done=1",
                             (g.sid,)).fetchall()
    return {r["step_id"] for r in rows}


def run_agent():
    """Run the agent for the current session. Returns (result, None) or (None, error_response)."""
    _id, assessment = latest_assessment()
    if not assessment:
        return None, error("No assessment found. Please complete the assessment first.", 404)
    done = [s for s in completed_steps() if s in ds.get_skills()]
    return AGENT.run(assessment, done), None


def career_detail(cid):
    c = ds.get_careers()[cid]
    skills = ds.get_skills()
    seen, resources = set(), []
    for sid in c["required_skills"]:
        for r in ds.resources_for_skill(sid):
            if r["id"] not in seen:
                seen.add(r["id"])
                resources.append({"title": r["title"], "url": r["url"], "type": r["type"], "level": r["level"]})
    return {**c, "required_skill_details": [{"id": s, "name": skills[s]["name"], "effort_hours": skills[s]["effort_hours"]}
                                            for s in c["required_skills"]],
            "resources": resources[:8], "related": [{"id": r, "name": KG.label(r)} for r in KG.related_careers(cid)]}


# ---------------------------------------------------------------- pages
PAGES = {"/": "index.html", "/assessment": "assessment.html", "/analysis": "analysis.html",
         "/dashboard": "dashboard.html", "/explorer": "career_explorer.html", "/roadmap": "roadmap.html",
         "/companion": "ai_companion.html", "/about": "about_ai.html"}


def _make_page(template):
    def view():
        return render_template(template)
    return view


for _path, _tpl in PAGES.items():
    app.add_url_rule(_path, endpoint=_tpl.replace(".html", ""), view_func=_make_page(_tpl))


# ---------------------------------------------------------------- API
@app.get("/api/health")
def health():
    problems = ds.validate_data()
    return jsonify({"status": "ok" if not problems else "degraded", "data_problems": problems,
                    "careers": len(ds.get_careers()), "skills": len(ds.get_skills()),
                    "ml_model_loaded": AGENT.recommender.model_available,
                    "llm_configured": llm_service.llm_configured(),
                    "rag_chunks": len(RAG.chunks)})


@app.get("/api/options")
def options():
    v = ds.get_vocab()
    return jsonify({**v, "skills": [{"id": s["id"], "name": s["name"], "category": s["category"]}
                                    for s in ds.get_skills().values()]})


@app.get("/api/demo")
def demo_assessment():
    return jsonify(ds.get_sample_assessment())


@app.get("/api/careers")
def list_careers():
    q = request.args.get("q", "").strip().lower()[:60]
    cat = request.args.get("category", "").strip()
    skills = ds.get_skills()
    out = []
    for c in ds.get_careers().values():
        hay = " ".join([c["name"], c["summary"], c["category"]] + [skills[s]["name"] for s in c["required_skills"]]).lower()
        if (not q or q in hay) and (not cat or c["category"] == cat):
            out.append({"id": c["id"], "name": c["name"], "category": c["category"], "summary": c["summary"],
                        "required_skills": [skills[s]["name"] for s in c["required_skills"]]})
    cats = sorted({c["category"] for c in ds.get_careers().values()})
    return jsonify({"careers": out, "categories": cats, "count": len(out)})


@app.get("/api/careers/<career_id>")
def get_career(career_id):
    if career_id not in ds.get_careers():
        return error("Career not found.", 404)
    return jsonify(career_detail(career_id))


@app.post("/api/assessment")
def post_assessment():
    clean, errors = validate_assessment(json_body())
    if errors:
        return error("Validation failed.", 400, errors)
    with get_conn() as c:
        cur = c.execute("INSERT INTO assessments (session_id, data_json) VALUES (?, ?)", (g.sid, json.dumps(clean)))
    return jsonify({"assessment_id": cur.lastrowid, "message": "Assessment saved."}), 201


@app.get("/api/assessment/latest")
def get_latest_assessment():
    aid, data = latest_assessment()
    if not data:
        return error("No assessment found.", 404)
    return jsonify({"assessment_id": aid, "assessment": data})


@app.post("/api/recommend")
def recommend():
    body = json_body()
    if body is not None and body.get("assessment"):          # allow one-off inline assessment (demo mode)
        clean, errors = validate_assessment(body["assessment"])
        if errors:
            return error("Validation failed.", 400, errors)
        result = AGENT.run(clean)
    else:
        result, err = run_agent()
        if err:
            return err
    saved = {r["career_id"] for r in get_saved_rows()}
    for r in result["recommendations"]:
        r["saved"] = r["career_id"] in saved
    if llm_service.llm_configured():                           # optional: validated LLM explanation
        top = result["top3"][0]
        better = llm_service.llm_structured(top, {"state": result["state"], "top3": result["top3"]})
        if better:
            top["structured"], top["structured_source"] = better, "llm"
    return jsonify(result)


@app.post("/api/search-path")
def search_path():
    body = json_body() or {}
    cid = body.get("career_id")
    if cid not in ds.get_careers():
        return error("Unknown career_id.", 400)
    algo = body.get("algorithm", "both")
    if algo not in ("bfs", "astar", "both"):
        return error("algorithm must be bfs, astar or both.", 400)
    _id, assessment = latest_assessment()
    known = {s for s, l in (assessment or {}).get("skills", {}).items() if l >= 1}
    known |= {s for s in completed_steps() if s in ds.get_skills()}
    if isinstance(body.get("known_skills"), list):
        known = {s for s in body["known_skills"] if s in ds.get_skills()}
    target = body.get("target", "capstone")
    career = ds.get_careers()[cid]
    if target == "career":
        goal = career["required_skills"]
    elif target == "capstone":
        goal = [career["required_skills"][-1] if career["required_skills"][-1] != "git_version_control"
                else career["required_skills"][-2]]
    elif target in ds.get_skills():
        goal = [target]
    else:
        return error("target must be capstone, career or a valid skill id.", 400)
    space = LearningSpace(ds.get_skills(), goal, known)
    out = {"career_id": cid, "goal": [{"id": s, "name": ds.get_skills()[s]["name"]} for s in goal],
           "known": sorted(known & (space.needed | set(goal))), "needed": sorted(space.needed),
           "graph": {"nodes": [{"id": s, "label": ds.get_skills()[s]["name"],
                                "known": s in known} for s in sorted(space.needed | {p for n in space.needed for p in ds.get_skills()[n]["prerequisites"]})],
                     "edges": [{"source": p, "target": n} for n in space.needed for p in ds.get_skills()[n]["prerequisites"]]},
           "heuristic": "h(n) = 0.8 x estimated hours of the skills still missing. It never over-estimates, so A* stays optimal. "
                        "Limitation: effort hours are rough estimates and every missing skill is assumed necessary."}
    if space.is_goal(space.start):
        out["message"] = "You already know every skill needed for this goal."
    if algo in ("bfs", "both"):
        out["bfs"] = bfs(space)
    if algo in ("astar", "both"):
        out["astar"] = astar(space)
    return jsonify(out)


@app.get("/api/knowledge-graph")
def knowledge_graph():
    focus = request.args.get("career")
    if focus and focus not in ds.get_careers():
        return error("Unknown career.", 404)
    return jsonify(KG.to_graph(focus))


@app.get("/api/knowledge-graph/node/<node_id>")
def kg_node(node_id):
    info = KG.node_info(node_id)
    if not info:
        return error("Node not found.", 404)
    return jsonify(info)


@app.get("/api/knowledge-graph/query")
def kg_query():
    res = KG.query(request.args.get("subject"), request.args.get("relation"), request.args.get("object"))
    return jsonify({"count": len(res), "triples": res[:100]})


@app.post("/api/chat")
def chat():
    body = json_body()
    msg = (body or {}).get("message")
    if not isinstance(msg, str) or not msg.strip():
        return error("message is required.", 400)
    if len(msg) > 500:
        return error("message is too long (max 500 characters).", 400)
    ctx, _err = run_agent()
    rag = RAG.query(msg, use_llm=False)
    history = body.get("history") if isinstance(body.get("history"), list) else []
    out = llm_service.chat(msg, ctx, history, rag)
    out["has_context"] = ctx is not None
    out["prompts"] = llm_service.PROMPTS
    return jsonify(out)


@app.get("/api/chat/prompts")
def chat_prompts():
    return jsonify({"prompts": llm_service.PROMPTS, "design": llm_service.PROMPT_DESIGN_SUMMARY,
                    "llm_configured": llm_service.llm_configured()})


@app.post("/api/rag/query")
def rag_query():
    body = json_body() or {}
    q = body.get("question")
    if not isinstance(q, str) or not q.strip():
        return error("question is required.", 400)
    if len(q) > 300:
        return error("question is too long (max 300 characters).", 400)
    top_k, min_score = body.get("top_k"), body.get("min_score")
    if top_k is not None and (not isinstance(top_k, int) or not 1 <= top_k <= 8):
        return error("top_k must be an integer from 1 to 8.", 400)
    if min_score is not None and (not isinstance(min_score, (int, float)) or not 0 <= min_score <= 1):
        return error("min_score must be a number from 0 to 1.", 400)
    return jsonify(RAG.query(llm_service.clean_text(q, 300), top_k, min_score))


def get_saved_rows():
    with get_conn() as c:
        return c.execute("SELECT career_id FROM saved_roadmaps WHERE session_id=?", (g.sid,)).fetchall()


@app.route("/api/saved", methods=["GET", "POST"])
def saved():
    if request.method == "GET":
        return jsonify({"saved": [{"career_id": r["career_id"], "name": KG.label(r["career_id"])} for r in get_saved_rows()]})
    body = json_body() or {}
    cid, action = body.get("career_id"), body.get("action", "save")
    if cid not in ds.get_careers() or action not in ("save", "remove"):
        return error("Provide a valid career_id and action (save/remove).", 400)
    with get_conn() as c:
        if action == "save":
            c.execute("INSERT OR IGNORE INTO saved_roadmaps (session_id, career_id) VALUES (?, ?)", (g.sid, cid))
        else:
            c.execute("DELETE FROM saved_roadmaps WHERE session_id=? AND career_id=?", (g.sid, cid))
    return jsonify({"career_id": cid, "saved": action == "save"})


@app.get("/api/compare")
def compare():
    a, b = request.args.get("a"), request.args.get("b")
    if a not in ds.get_careers() or b not in ds.get_careers() or a == b:
        return error("Provide two different valid career ids as a and b.", 400)
    sk = ds.get_skills()
    ca, cb = ds.get_careers()[a], ds.get_careers()[b]
    sa, sb = set(ca["required_skills"]), set(cb["required_skills"])
    name = lambda ids: [sk[s]["name"] for s in sk if s in ids]
    result = {"a": career_detail(a), "b": career_detail(b), "shared_skills": name(sa & sb),
              "only_a": name(sa - sb), "only_b": name(sb - sa),
              "hours_a": sum(sk[s]["effort_hours"] for s in sa), "hours_b": sum(sk[s]["effort_hours"] for s in sb)}
    res, _err = run_agent()
    if res:
        scores = {r["career_id"]: r for r in res["recommendations"]}
        result["score_a"], result["score_b"] = scores[a]["score"], scores[b]["score"]
    return jsonify(result)


def roadmap_response(cid):
    _id, assessment = latest_assessment()
    known = {s for s, l in (assessment or {}).get("skills", {}).items() if l >= 1}
    hours = (assessment or {}).get("study_hours", 5)
    done = completed_steps(cid)
    plan = build_roadmap(cid, known, hours, done)   # completed steps stay visible and are ticked
    plan["progress"] = progress_summary(plan)
    plan["weekly_plan"] = weekly_plan(plan)
    plan["saved"] = cid in {r["career_id"] for r in get_saved_rows()}
    plan["has_assessment"] = assessment is not None
    return plan


@app.get("/api/roadmap")
def get_roadmap():
    cid = request.args.get("career_id")
    if not cid:
        res, err = run_agent()
        if err:
            return err
        cid = res["top3"][0]["career_id"]
    if cid not in ds.get_careers():
        return error("Unknown career_id.", 404)
    return jsonify(roadmap_response(cid))


@app.post("/api/roadmap/progress")
def roadmap_progress():
    body = json_body() or {}
    cid, step, done = body.get("career_id"), body.get("skill_id"), body.get("done")
    if cid not in ds.get_careers() or not isinstance(done, bool):
        return error("career_id and boolean done are required.", 400)
    valid = set(ds.get_skills()) | {"portfolio_project"}
    if step not in valid:
        return error("Unknown skill_id.", 400)
    with get_conn() as c:
        c.execute("INSERT INTO roadmap_progress (session_id, career_id, step_id, done, updated_at) "
                  "VALUES (?,?,?,?,CURRENT_TIMESTAMP) ON CONFLICT(session_id, career_id, step_id) "
                  "DO UPDATE SET done=excluded.done, updated_at=CURRENT_TIMESTAMP",
                  (g.sid, cid, step, int(done)))
    plan = roadmap_response(cid)
    return jsonify({"progress": plan["progress"], "weekly_plan": plan["weekly_plan"],
                    "message": "Progress saved. The agent will use this skill in your next recommendation."})


@app.get("/api/agent/rules")
def agent_rules():
    return jsonify({"rules": ds.get_rules()})


@app.get("/api/ml/info")
def ml_info():
    return jsonify({"available": AGENT.recommender.model_available, "meta": AGENT.recommender.meta,
                    "formula": "score = 100 x (0.30 skill_overlap + 0.25 interest_match + 0.25 model_signal + "
                               "0.10 prereq_readiness + 0.10 rule_boost)",
                    "fallback": "If the model cannot load, model_signal is dropped and weights are re-balanced."})


@app.post("/api/ml/neural-demo")
def neural():
    body = json_body() or {}
    vals = body.get("inputs")
    if not (isinstance(vals, list) and len(vals) == 6 and all(isinstance(v, (int, float)) and 0 <= v <= 1 for v in vals)):
        return error("inputs must be a list of 6 numbers between 0 and 1.", 400)
    return jsonify(neural_demo.forward(vals))


# ---------------------------------------------------------------- errors
@app.errorhandler(404)
def not_found(_e):
    if request.path.startswith("/api/"):
        return error("Endpoint not found.", 404)
    return render_template("index.html"), 404


@app.errorhandler(405)
def bad_method(_e):
    return error("Method not allowed.", 405)


@app.errorhandler(413)
def too_large(_e):
    return error("Request too large.", 413)


@app.errorhandler(500)
def server_error(_e):
    return error("Internal server error. Check the server console for details.", 500)


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=os.getenv("FLASK_DEBUG", "1") == "1")
